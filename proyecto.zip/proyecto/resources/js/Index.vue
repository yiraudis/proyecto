<template>
    <div>
        <!-- <chat></chat> -->

        <header class="app-header navbar">
            <button
                class="navbar-toggler sidebar-toggler d-lg-none mr-auto"
                type="button"
                data-toggle="sidebar-show"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
            <router-link tag="a" to="/admin/home" class="navbar-brand">
                <img
                    class="navbar-brand-full"
                    :src="michin.logoapp"
                    width="65"
                    height="55"
                    alt="CoreUI Logo"
                />
                <img
                    class="navbar-brand-minimized"
                    :src="michin.logoapp"
                    width="60"
                    height="50"
                    alt="CoreUI Logo"
                />
            </router-link>
            <button
                class="navbar-toggler sidebar-toggler d-md-down-none"
                type="button"
                data-toggle="sidebar-lg-show"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
            <!--     <ul class="nav navbar-nav d-md-down-none">
        <li class="nav-item px-3">
          <a class="nav-link" href="#">jhjhjh</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="#">sdfdsf</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="#">Settings</a>
        </li>
      </ul> -->
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item d-md-down-none">
                    <a class="nav-link" href="#">
                        <i class="icon-list"></i>
                    </a>
                </li>
                <li class="nav-item d-md-down-none">
                    <a class="nav-link" href="#">
                        <i class="icon-location-pin"></i>
                    </a>
                </li>
                <li class="nav-item dropdown perfil-nav">
                    <a
                        class="nav-link"
                        data-toggle="dropdown"
                        href="#"
                        role="button"
                        aria-haspopup="true"
                        aria-expanded="false"
                    >
                        <div class="avatar">
                            <img
                                class="img-avatar"
                                :src="user.avatar"
                                :alt="user.names"
                                v-if="user.avatar"
                            />
                            <span class="avatar-status badge-danger"></span>
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="dropdown-header text-center">
                            <strong
                                >{{ user.names }} {{ user.surnames }}</strong
                            >
                            <strong>Cargo</strong>
                        </div>
                        <a class="dropdown-item" href="#">
                            Platin - Pendiente
                            <span class="badge badge-info">10</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            Platin - Por aprobar
                            <span class="badge badge-success">42</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <i class="fa fa-tasks"></i> NNA Asignados
                            <span class="badge badge-danger">5</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <i class="fa fa-comments"></i> NNA Sin Ev.
                            <span class="badge badge-warning">8</span>
                        </a>
                        <div class="dropdown-header text-center">
                            <strong>Configuraciones</strong>
                        </div>

                        <router-link
                            tag="a"
                            to="/gateway/perfil"
                            class="dropdown-item"
                        >
                            <i class="fa fa-user"></i> Perfil
                        </router-link>
                        <!--  <a class="dropdown-item" href="#">
              <i class="fa fa-wrench"></i> Settings
            </a>
            <a class="dropdown-item" href="#">
              <i class="fa fa-usd"></i> Payments
              <span class="badge badge-secondary">42</span>
            </a>
            <a class="dropdown-item" href="#">
              <i class="fa fa-file"></i> Projects
              <span class="badge badge-primary">42</span>
            </a> -->
                        <div class="dropdown-divider"></div>
                        <!--          <a class="dropdown-item" href="#">
              <i class="fa fa-shield"></i> Lock Account
            </a> -->
                        <a class="dropdown-item" href="#" @click="logout()">
                            <i class="fa fa-lock"></i> Cerrar sesión
                        </a>
                    </div>
                </li>
            </ul>
            <!--       <button
        class="navbar-toggler aside-menu-toggler d-md-down-none"
        type="button"
        data-toggle="aside-menu-lg-show"
      >
        <span class="navbar-toggler-icon"></span>
      </button> -->
            <button
                class="navbar-toggler aside-menu-toggler d-lg-none"
                type="button"
                data-toggle="aside-menu-show"
            >
                <span class="navbar-toggler-icon"></span>
            </button>
        </header>
        <div class="app-body">
            <div class="sidebar">
                <nav class="sidebar-nav">
                    <ul class="nav">
                        <li class="nav-item">
                            <router-link
                                tag="a"
                                to="/admin/children"
                                class="nav-link"
                            >
                                <i class="nav-icon fas fa-id-badge"></i>
                                Registro NNA
                            </router-link>
                        </li>
                        <li class="nav-item">
                            <router-link
                                tag="a"
                                to="/admin/listado_nna"
                                class="nav-link"
                            >
                                <i class="nav-icon fas fa-list-alt"></i> Listado
                                NNA
                            </router-link>
                        </li>
                        <li class="nav-item nav-dropdown">
                            <a class="nav-link nav-dropdown-toggle" href="#">
                                <i class="nav-icon fas fa-clipboard-check"></i>
                                Evaluaciones Ingreso
                            </a>
                            <ul class="nav-dropdown-items">
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/eva_psi_ingreso_ind"
                                        class="nav-link"
                                    >
                                        <i class="nav-icon fas fa-child"></i>
                                        Psicológica Individual
                                    </router-link>
                                </li>
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/eva_psi_ingreso_familiar"
                                        class="nav-link"
                                    >
                                        <i
                                            class="nav-icon fas fa-user-friends"
                                        ></i>
                                        Psicológica Familiar
                                    </router-link>
                                </li>
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/eva_social_ingreso_ind"
                                        class="nav-link"
                                    >
                                        <i class="nav-icon fas fa-walking"></i>
                                        Social Individual
                                    </router-link>
                                </li>
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/eva_sociofamiliar_ingreso"
                                        class="nav-link"
                                    >
                                        <i class="nav-icon fas fa-users"></i>
                                        Sociofamiliar
                                    </router-link>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-dropdown">
                            <a class="nav-link nav-dropdown-toggle" href="#">
                                <i class="nav-icon fas fa-file-invoice"></i>
                                Informes ICBF
                            </a>
                            <ul class="nav-dropdown-items">
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/listado_platin"
                                        class="nav-link"
                                    >
                                        <i
                                            class="nav-icon fab fa-product-hunt"
                                        ></i>
                                        PLATIN
                                    </router-link>
                                </li>
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/registro_nplatin"
                                        class="nav-link"
                                    >
                                        <i
                                            class="nav-icon far fa-file-excel"
                                        ></i>
                                        PT Mensual
                                    </router-link>
                                </li>
                                <li class="nav-item nav-subm">
                                    <router-link
                                        tag="a"
                                        to="/admin/informe_nna"
                                        class="nav-link"
                                    >
                                        <i
                                            class="nav-icon far fa-file-excel"
                                        ></i>
                                        Informe NNA
                                    </router-link>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <button
                    class="sidebar-minimizer brand-minimizer"
                    type="button"
                ></button>
            </div>
            <main class="main">
                <ol class="breadcrumb">
                    <a class="logo-fundacion-nav" href="#">
                        <img
                            class="navbar-brand-minimized"
                            :src="michin.logo"
                            width="255"
                            height="45"
                            alt="CoreUI Logo"
                        />
                    </a>
                    <li class="breadcrumb-item">
                        <a href="/v1/docs/">Home</a>
                    </li>
                    <li class="breadcrumb-item">Layout</li>
                    <li class="breadcrumb-item active">Layout options</li>
                </ol>

                <div class="container-fluid mt-4">
                    <!-- content -->
                    <transition name="component-fade" mode="out-in">
                        <router-view></router-view>
                    </transition>
                </div>
            </main>
            <aside class="aside-menu">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a
                            class="nav-link active"
                            data-toggle="tab"
                            href="#timeline"
                            role="tab"
                        >
                            <i class="icon-list"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link"
                            data-toggle="tab"
                            href="#messages"
                            role="tab"
                        >
                            <i class="icon-speech"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link"
                            data-toggle="tab"
                            href="#settings"
                            role="tab"
                        >
                            <i class="icon-settings"></i>
                        </a>
                    </li>
                </ul>
                <!-- Tab panes-->
                <div class="tab-content">
                    <div class="tab-pane active" id="timeline" role="tabpanel">
                        <div class="list-group list-group-accent">
                            <div
                                class="list-group-item list-group-item-accent-secondary bg-light text-center font-weight-bold text-muted text-uppercase small"
                            >
                                Today
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-warning list-group-item-divider"
                            >
                                <div class="avatar float-right">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                </div>
                                <div>
                                    Meeting with
                                    <strong>Lucas</strong>
                                </div>
                                <small class="text-muted mr-3">
                                    <i class="icon-calendar"></i> 1 - 3pm
                                </small>
                                <small class="text-muted">
                                    <i class="icon-location-pin"></i> Palo Alto,
                                    CA
                                </small>
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-info"
                            >
                                <div class="avatar float-right">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                </div>
                                <div>
                                    Skype with
                                    <strong>Megan</strong>
                                </div>
                                <small class="text-muted mr-3">
                                    <i class="icon-calendar"></i> 4 - 5pm
                                </small>
                                <small class="text-muted">
                                    <i class="icon-social-skype"></i> On-line
                                </small>
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-secondary bg-light text-center font-weight-bold text-muted text-uppercase small"
                            >
                                Tomorrow
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-danger list-group-item-divider"
                            >
                                <div>
                                    New UI Project -
                                    <strong>deadline</strong>
                                </div>
                                <small class="text-muted mr-3">
                                    <i class="icon-calendar"></i> 10 - 11pm
                                </small>
                                <small class="text-muted">
                                    <i class="icon-home"></i> creativeLabs HQ
                                </small>
                                <div class="avatars-stack mt-2">
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-success list-group-item-divider"
                            >
                                <div>
                                    <strong>#10 Startups.Garden</strong> Meetup
                                </div>
                                <small class="text-muted mr-3">
                                    <i class="icon-calendar"></i> 1 - 3pm
                                </small>
                                <small class="text-muted">
                                    <i class="icon-location-pin"></i> Palo Alto,
                                    CA
                                </small>
                            </div>
                            <div
                                class="list-group-item list-group-item-accent-primary list-group-item-divider"
                            >
                                <div>
                                    <strong>Team meeting</strong>
                                </div>
                                <small class="text-muted mr-3">
                                    <i class="icon-calendar"></i> 4 - 6pm
                                </small>
                                <small class="text-muted">
                                    <i class="icon-home"></i> creativeLabs HQ
                                </small>
                                <div class="avatars-stack mt-2">
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                    <div class="avatar avatar-xs">
                                        <img
                                            class="img-avatar"
                                            :src="user.avatar"
                                            alt="admin@bootstrapmaster.com"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="messages" role="tabpanel">
                        <div class="message">
                            <div class="py-3 pb-5 mr-3 float-left">
                                <div class="avatar">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                    <span
                                        class="avatar-status badge-success"
                                    ></span>
                                </div>
                            </div>
                            <div>
                                <small class="text-muted"
                                    >Lukasz Holeczek</small
                                >
                                <small class="text-muted float-right mt-1"
                                    >1:52 PM</small
                                >
                            </div>
                            <div class="text-truncate font-weight-bold">
                                Lorem ipsum dolor sit amet
                            </div>
                            <small class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur
                                adipisicing elit, sed do eiusmod tempor
                                incididunt...
                            </small>
                        </div>
                        <hr />
                        <div class="message">
                            <div class="py-3 pb-5 mr-3 float-left">
                                <div class="avatar">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                    <span
                                        class="avatar-status badge-success"
                                    ></span>
                                </div>
                            </div>
                            <div>
                                <small class="text-muted"
                                    >Lukasz Holeczek</small
                                >
                                <small class="text-muted float-right mt-1"
                                    >1:52 PM</small
                                >
                            </div>
                            <div class="text-truncate font-weight-bold">
                                Lorem ipsum dolor sit amet
                            </div>
                            <small class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur
                                adipisicing elit, sed do eiusmod tempor
                                incididunt...
                            </small>
                        </div>
                        <hr />
                        <div class="message">
                            <div class="py-3 pb-5 mr-3 float-left">
                                <div class="avatar">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                    <span
                                        class="avatar-status badge-success"
                                    ></span>
                                </div>
                            </div>
                            <div>
                                <small class="text-muted"
                                    >Lukasz Holeczek</small
                                >
                                <small class="text-muted float-right mt-1"
                                    >1:52 PM</small
                                >
                            </div>
                            <div class="text-truncate font-weight-bold">
                                Lorem ipsum dolor sit amet
                            </div>
                            <small class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur
                                adipisicing elit, sed do eiusmod tempor
                                incididunt...
                            </small>
                        </div>
                        <hr />
                        <div class="message">
                            <div class="py-3 pb-5 mr-3 float-left">
                                <div class="avatar">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                    <span
                                        class="avatar-status badge-success"
                                    ></span>
                                </div>
                            </div>
                            <div>
                                <small class="text-muted"
                                    >Lukasz Holeczek</small
                                >
                                <small class="text-muted float-right mt-1"
                                    >1:52 PM</small
                                >
                            </div>
                            <div class="text-truncate font-weight-bold">
                                Lorem ipsum dolor sit amet
                            </div>
                            <small class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur
                                adipisicing elit, sed do eiusmod tempor
                                incididunt...
                            </small>
                        </div>
                        <hr />
                        <div class="message">
                            <div class="py-3 pb-5 mr-3 float-left">
                                <div class="avatar">
                                    <img
                                        class="img-avatar"
                                        :src="user.avatar"
                                        alt="admin@bootstrapmaster.com"
                                    />
                                    <span
                                        class="avatar-status badge-success"
                                    ></span>
                                </div>
                            </div>
                            <div>
                                <small class="text-muted"
                                    >Lukasz Holeczek</small
                                >
                                <small class="text-muted float-right mt-1"
                                    >1:52 PM</small
                                >
                            </div>
                            <div class="text-truncate font-weight-bold">
                                Lorem ipsum dolor sit amet
                            </div>
                            <small class="text-muted">
                                Lorem ipsum dolor sit amet, consectetur
                                adipisicing elit, sed do eiusmod tempor
                                incididunt...
                            </small>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="settings" role="tabpanel">
                        <h6>Settings</h6>
                        <div class="aside-options">
                            <div class="clearfix mt-4">
                                <small>
                                    <b>Option 1</b>
                                </small>
                                <label
                                    class="switch switch-label switch-pill switch-success switch-sm float-right"
                                >
                                    <input
                                        class="switch-input"
                                        type="checkbox"
                                        checked
                                    />
                                    <span
                                        class="switch-slider"
                                        data-checked="On"
                                        data-unchecked="Off"
                                    ></span>
                                </label>
                            </div>
                            <div>
                                <small class="text-muted">
                                    Lorem ipsum dolor sit amet, consectetur
                                    adipisicing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua.
                                </small>
                            </div>
                        </div>
                        <div class="aside-options">
                            <div class="clearfix mt-3">
                                <small>
                                    <b>Option 2</b>
                                </small>
                                <label
                                    class="switch switch-label switch-pill switch-success switch-sm float-right"
                                >
                                    <input
                                        class="switch-input"
                                        type="checkbox"
                                    />
                                    <span
                                        class="switch-slider"
                                        data-checked="On"
                                        data-unchecked="Off"
                                    ></span>
                                </label>
                            </div>
                            <div>
                                <small class="text-muted">
                                    Lorem ipsum dolor sit amet, consectetur
                                    adipisicing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua.
                                </small>
                            </div>
                        </div>
                        <div class="aside-options">
                            <div class="clearfix mt-3">
                                <small>
                                    <b>Option 3</b>
                                </small>
                                <label
                                    class="switch switch-label switch-pill switch-success switch-sm float-right"
                                >
                                    <input
                                        class="switch-input"
                                        type="checkbox"
                                    />
                                    <span
                                        class="switch-slider"
                                        data-checked="On"
                                        data-unchecked="Off"
                                    ></span>
                                </label>
                            </div>
                        </div>
                        <div class="aside-options">
                            <div class="clearfix mt-3">
                                <small>
                                    <b>Option 4</b>
                                </small>
                                <label
                                    class="switch switch-label switch-pill switch-success switch-sm float-right"
                                >
                                    <input
                                        class="switch-input"
                                        type="checkbox"
                                        checked
                                    />
                                    <span
                                        class="switch-slider"
                                        data-checked="On"
                                        data-unchecked="Off"
                                    ></span>
                                </label>
                            </div>
                        </div>
                        <hr />
                        <h6>System Utilization</h6>
                        <div class="text-uppercase mb-1 mt-4">
                            <small>
                                <b>CPU Usage</b>
                            </small>
                        </div>
                        <div class="progress progress-xs">
                            <div
                                class="progress-bar bg-info"
                                role="progressbar"
                                style="width: 25%"
                                aria-valuenow="25"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ></div>
                        </div>
                        <small class="text-muted"
                            >348 Processes. 1/4 Cores.</small
                        >
                        <div class="text-uppercase mb-1 mt-2">
                            <small>
                                <b>Memory Usage</b>
                            </small>
                        </div>
                        <div class="progress progress-xs">
                            <div
                                class="progress-bar bg-warning"
                                role="progressbar"
                                style="width: 70%"
                                aria-valuenow="70"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ></div>
                        </div>
                        <small class="text-muted">11444GB/16384MB</small>
                        <div class="text-uppercase mb-1 mt-2">
                            <small>
                                <b>SSD 1 Usage</b>
                            </small>
                        </div>
                        <div class="progress progress-xs">
                            <div
                                class="progress-bar bg-danger"
                                role="progressbar"
                                style="width: 95%"
                                aria-valuenow="95"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ></div>
                        </div>
                        <small class="text-muted">243GB/256GB</small>
                        <div class="text-uppercase mb-1 mt-2">
                            <small>
                                <b>SSD 2 Usage</b>
                            </small>
                        </div>
                        <div class="progress progress-xs">
                            <div
                                class="progress-bar bg-success"
                                role="progressbar"
                                style="width: 10%"
                                aria-valuenow="10"
                                aria-valuemin="0"
                                aria-valuemax="100"
                            ></div>
                        </div>
                        <small class="text-muted">25GB/256GB</small>
                    </div>
                </div>
            </aside>
        </div>
    </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";
import { cleanStorage, post } from './utils/services/api';
// import Chat from "../components/Chat/Chat";
export default {
    components: {
        // Chat
    },
    data() {
        return {
            user: {
                avatar: "/images/avatars/profile.jpg"
            },
            michin: {
                logoapp: "/images/logo.png",
                logo: "/images/logo_michin.png"
            }
        };
    },
    async mounted() {
        await this.getDocumentTypes();
        await this.getSexs();
        await this.getCountries();
        await this.getEthnicGroups();
        await this.getLocations();
        await this.getTypesFamily();
        await this.getResponsables();
        await this.getFamilyIncome();
        await this.getFamilyOccupations();
        await this.getFamilyBackground();
        await this.getScholarships();
        await this.getFamilyCurators();
        await this.getZonalCenters();
        await this.getCities();
    },
    methods: {

        async logout(){
            let resp = await post({}, 'auth/logout')
            if (resp.code == 200) {
                cleanStorage()
                window.location.href = '/login'
                console.log(resp);
                
            }

        },
        ...mapActions([
            "getDocumentTypes",
            "getSexs",
            "getCountries",
            "getEthnicGroups",
            "getLocations",
            "getTypesFamily",
            "getResponsables",
            "getFamilyIncome",
            "getFamilyOccupations",
            "getFamilyBackground",
            "getScholarships",
            "getFamilyCurators",
            "getZonalCenters",
            "getCities"
        ])

    },
    computed: {}
};
</script>
