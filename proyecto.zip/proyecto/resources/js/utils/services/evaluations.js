import { logMichin } from "../functions"
import { post,get } from "./api"

export const searchChildren = async(search, type) => {

    try {
        let query = `query{
            searchChildren(search:"${search}",type:${type}){
                id
                primer_nombre
                segundo_nombre
                fecha_nacimiento
                user_document_types{
                    id
                    identificacion
                  }
                  direccion
                  telefono
                  ciudad{
                    id
                    nombre
                  }
                ethnic_group {
                    id
                    name
                }
                children {
                    id
                    numero_ha
                    sim
                    fecha_ingreso
                    family{
                        id
                        user{
                            id
                          primer_nombre
                          direccion
                          telefono
                          ciudad{
                            id
                            nombre
                          }
                          user_document_types{
                            id
                            identificacion
                          }
                        }
                        parentesco{
                          id
                          nombre
                        }
                        parentesco_id
                        habita
                        contacto
                      }
                    scholarship{
                        id
                        nombre
                        scope
                    }
                    family{
                        user{
                            id
                            primer_nombre
                            primer_nombre
                            segundo_nombre
                            fecha_nacimiento
                        }
                      }
                }
            }
          }`
        let result = await post({ query }, "evaluation")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const psicoIndividual = async(data) => {
    let categories = ''
    if (data.dataCategories.length > 0) {
        categories = '[';
        data.dataCategories.map(item => {
            categories += `{
                id:${item.id},
                description:"${item.description}",
            },`
        })
        categories = categories.slice(0, -1);
        categories += ']';
    } else {
        categories = '[]'
    }
    try {
        let query = `mutation{
            psicoIndividual(
                children_id:${data.dataChildren.children_id},
                primer_nombre:"${data.dataChildren.primer_nombre ? data.dataChildren.primer_nombre : null }",
                fecha_nacimiento:"${data.dataChildren.fecha_nacimiento ? data.dataChildren.fecha_nacimiento : null }",
                fecha_evaluacion:"${data.dataChildren.fecha_evaluacion ? data.dataChildren.fecha_evaluacion : null }",
                escolaridad_id:${data.dataChildren.escolaridad_id ? data.dataChildren.escolaridad_id : null },
                grupo_etnico_id:${data.dataChildren.grupo_etnico_id ? data.dataChildren.grupo_etnico_id : null },
                percepcion_ingreso:"${data.reason_admission}",
                antecedentes:"${data.antecedent}",
                examen_mental:"${data.mental_exam}",
                afectividad:"${data.affectivity}",
                percepcion_nna:"${data.perception}",
                prospectiva:"${data.prospective}",
                adaptacion:"${data.adaptation}",
                resultado_pruebas:"${data.result}",
                categories:${categories},
                lectura_profesional:"${data.professional_reading}"){
            code
            status_transaction
            message
        }
      }`
        let result = await post({ query }, "evaluation")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const psicoIngresoFamiliar = async(data) => {

    //categorias
    let categories = ''
    if (data.dataCategories.length > 0) {
        categories = '[';
        data.dataCategories.map(item => {
            categories += `{
                id:${item.id},
                description:"${item.description}",
            },`
        })
        categories = categories.slice(0, -1);
        categories += ']';
    } else {
        categories = '[]'
    }

    // Familiares

    let families = ''
    if (data.entrevistados.entrevistados.length > 0) {
        families = '[';
        data.entrevistados.entrevistados.map((f) => {
            if (f.id) {
                families += `{
                  id:${f.id},
                  parentesco_id:${f.relationship.id},
                },
              `
            } else {
                families += `{
                primer_nombre:"${f.name}",
                segundo_nombre:"${f.secoundName}",
                primer_apellido: "${f.surname}",
                segundo_apellido:"${f.secoundSurname}",
                identificacion:"${f.identification}",
                tipo_identificacion_id:${f.documentType?f.documentType.id:2},
                genero_id:${f.sex.id},
                fecha_nacimiento:"${f.dateBirth}",
                estado_civil_id:${f.civilStatus.id},
                ocupacion_id:${f.activitie.id},
                escolaridad_id:${f.schooling.id},
                barrio_id:${f.neighborhood.id},
                direccion:"${f.address}",
                telefono:"${f.phone}",
                tenencia_id:${f.ownership.id},
                tipo_vivienda_id:${f.housingType.id},
                parentesco_id:${f.relationship.id},
                habita:${f.speak?1:0},
                contacto:${f.principal?1:0}
            },`
            }
        });
        families = families.slice(0, -1);
        families += ']';
    } else {
        families = '[]'
    }

    try {

        let query = `mutation{
            psicoIngresoFamiliar(
                  children_id:${data.entrevistados.children_id},
                  fecha_evaluacion:"${data.entrevistados.fecha_evaluacion ? data.entrevistados.fecha_evaluacion : null }",
                  motivo_ingreso:"${data.motivo_ingreso ? data.motivo_ingreso : null}",
                  caracteristicas:"${data.caracteristicas ? data.caracteristicas : null }",
                  evento_significativo:"${data.evento_significativo ? data.evento_significativo : null}",
                  sistema_creencia:"${data.sistema_creencia ? data.sistema_creencia : null}",
                  generatividad:"${data.generatividad ? data.generatividad : null}",
                  vulnerabilidad:"${data.vulnerabilidad ? data.vulnerabilidad : null}",
                  lectura:"${data.lectura ? data.lectura : null}",
                  family:${families},
                  datacategories:${categories}){
              code
              status_transaction
              message
          }
        }`
        console.log(query);
        let result = await post({ query }, "evaluation")

        return result

    } catch (error) {
        logMichin(error)
        return error
    }
}

export const getComplements =  async() => {
    let result = await get("/evaluation/getComplement")
    return result
}

export const saveSocialIngresoIndividual =  async(data) => {
    let result = await post(data,"evaluation/saveSocialIngresoIndividual")
    return result
}

export const evaSocioFamiliarIngreso =  async(data) => {
    let result = await post(data,"evaluation/evaSocioFamiliarIngreso")
    return result
}
