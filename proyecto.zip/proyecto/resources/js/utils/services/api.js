import { logMichin } from "../functions";

    let baseUrl = `${window.location.origin}/api`;
    // this.apiKeyClient = config.apiKeyClient
    let headers = {
        'Content-Type': 'application/json'
    }
    let token = document.head.querySelector('meta[name="csrf-token"]');
    if (token) {
        headers['X-CSRF-TOKEN'] = token.content;
        // window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;
    } else {
        console.error('CSRF token not found: https://laravel.com/docs/csrf#csrf-x-csrf-token');
    }


    // constructor() {
    //   }
    /**
         * Method for request api graphql
         *
         * @return Object or Array with the answer of API
         * @param data data with request
         * @param schema can is null is schema for request
    */
    export const post = async(data,route = "")=> {



        if (data.toLocaleString() == "[object Object]") {
            headers['Content-Type'] = 'application/json'

            data = JSON.stringify(data)
        } else {
            delete headers['Content-Type']
        }

        let token = localStorage.getItem('token')
        if (token) {
            headers['Authorization'] = `Bearer ${token}`
        }

        try {
            let response = await fetch(`${baseUrl}/${route}`, {
                method: 'POST',
                body: data,
                headers: headers
            });
            
            if (response.ok) {
                let responseJson = await response.json();
                if (responseJson.code && responseJson.code == 401) {
                    logMichin("No autorizado: ",responseJson)
                    cleanStorage()
                    window.location.href = '/login'
                }
                return responseJson;

            } else {
                let responseJson = await response.json();
                if (responseJson.code && responseJson.code == 401) {
                    logMichin("No autorizado: ",responseJson)
                    cleanStorage()
                    window.location.href = '/login'
                }

                return responseJson;

            }
        } catch (error) {
            logMichin(error)

            return error
        }
    }

    export const get = async (route = "")=> {
        let token = localStorage.getItem('token')
        if (token) {
            headers['Authorization'] = `Bearer ${token}`
        }

        try {
            let response = await fetch(`${baseUrl}${route}`, {
                method: 'GET',
                headers: headers
            });
            if (response.ok) {
                let responseJson = await response.json();
                if (responseJson.code && responseJson.code == 401) {
                    logMichin("No autorizado: ",responseJson)
                    cleanStorage()
                    window.location.href = '/login'
                }
                return responseJson;

            } else {
                let responseJson = await response.json();
                if (responseJson.code && responseJson.code == 401) {
                    logMichin("No autorizado: ",responseJson)
                    cleanStorage()
                    window.location.href = '/login'
                }
                return responseJson;
            }
        } catch (error) {
            console.log('error');

            return error
        }
    }

    export const cleanStorage = () => {
        localStorage.removeItem('roles')
        localStorage.removeItem('token')
        localStorage.removeItem('permissions')
    }
