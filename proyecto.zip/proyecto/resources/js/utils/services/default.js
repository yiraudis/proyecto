import { post } from './api';
import { logMichin } from '../functions'



export const documentTypes = async() => {

    try {
        let query = `query{
            documentTypes{
                nombre
                id
            }
          }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const sexs = async() => {

    try {
        let query = `query{
            sexs{
                nombre
                id
            }
          }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const countries = async() => {

    try {
        let query = `query{
            countries{
              nombre
              id
              nacionalidad
              departments{
                nombre
                cities{
                  nombre
                  residence_locality{
                    nombre
                    id
                    neighborhood{
                      nombre
                      id
                    }
                  }
                }
              }
            }
          }`

        let result = await post({ query }, "")
        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const ethnicGroups = async() => {
    try {
        let query = `query{
            ethnicGroups{
                name
                id
            }
          }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const locations = async() => {
    try {
        let query = `query{
            locations{
              nombre
              id
            }
          }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const zonalCenters = async() => {
    try {
        let query = `query{
            zonalCenters{
              nombre
              id
              telefono
            }
          }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const reasonAdmissions = async() => {
    try {
        let query = `query{
        reasonAdmissions{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const typesFamily = async() => {
    try {
        let query = `query{
        TypesFamily{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const responsables = async() => {
    try {
        let query = `query{
        responsables{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const familyIncome = async() => {
    try {
        let query = `query{
        familyIncome{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const familyOccupations = async() => {
    try {
        let query = `query{
        familyOccupations{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const familyBackground = async() => {
    try {
        let query = `query{
        familyBackground{
          nombre
          id
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}
export const scholarships = async() => {
    try {
        let query = `query{
        scholarships{
          id
          nombre
        }
      }`
        let result = await post({ query }, "")
        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const categoryMeta = async() => {
    try {
        let query = `query {
            categoryMeta {
              id
              nombre
            }
          }`
        let result = await post({ query }, "evaluation")
        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const familyCurators = async() => {
    try {
        let query = `query{
        familyCurators{
          id
          nombre
        }
      }`
        let result = await post({ query }, "")

        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const cities = async() => {
    try {
        let query = `query{
        cities{
          id
          nombre
          residence_locality{
            id
            nombre
            neighborhood{
              id
              nombre
            }
          }
        }
      }`
        let result = await post({ query }, "")
        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}

export const familyRelationships = async() => {
    try {
        let query = `query {
        familyRelationships{
          id
          nombre
        }
      }`
        let result = await post({ query }, "")
        return result

    } catch (error) {
        logMichin(error)

        return error

    }


}