import { logMichin } from "../functions"
import { get,post } from "./api"

export const listPlatin = async () => {
    let result = await get("/platin/list_platin")
    return result
}

export const platinById = async (id) => {
    let result = await get(`/platin/get_platin/${id}`)
    return result
}

export const getComplement = async (id) => {
    let result = await get(`/platin/get_complement`)
    return result
}

export const saveDescription = async (data) => {
    // console.log(data);
    let result = await post(data,`platin/save_description`)
    return result
}

export const saveFinalizar = async (data) => {
    // console.log(data);
    let result = await post(data,`platin/finalizar`)
    return result
}
