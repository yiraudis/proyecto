import { logMichin } from "../functions"
import { post } from "./api"

export const houses = async () => {

    try {
        let query = `query{
            houses{
                nombre
                direccion
                plant_coordinator{
                  primer_nombre
                }
                relief_coordinator{
                  primer_nombre
                }
                id
              }
          }`
        let result = await post({query}, "children")

        return result
        
    } catch (error) {
        logMichin(error)

        return error
        
    }
    

}

export const socialWorkers = async () => {
  try {
      let query = `query{
        socialWorkers{
          primer_nombre
          segundo_nombre
          id
        }
      }`
      let result = await post({query}, "children")

      return result
      
  } catch (error) {
      logMichin(error)

      return error
      
  }
  

}

export const psychologists = async () => {
  try {
      let query = `query{
        psychologists{
          primer_nombre
          segundo_nombre
          id
        }
      }`
      let result = await post({query}, "children")

      return result
      
  } catch (error) {
      logMichin(error)

      return error
      
  }
  

}
export const newChildren = async({BasicData, StateProcess, FamilyComposition, Characterization}) =>{
  try {

    const basicData = BasicData.data
    const stateProcess = StateProcess.data
    const familyComposition = FamilyComposition.data
    const characterization = Characterization.data
    let identifications = '';
    if(basicData.documentTypes.length > 0){
      identifications='[';
        basicData.documentTypes.map((dt)=>{
          identifications += `{
              tipo_identificacion_id:${dt.documentType.id},
              identificacion:"${dt.document}",
              fecha_expedicion:"${dt.expeditionDate}"
          },`
        });
        identifications=identifications.slice(0, -1);
        identifications+=']';
    }else {
        identifications= '[]'
    }

    let families = ''
    if(familyComposition.families.length > 0){
      families='[';
      familyComposition.families.map((f)=>{
        families += `{
              primer_nombre:"${f.name}",
              segundo_nombre:"${f.secoundName}",
              primer_apellido: "${f.surname}",
              segundo_apellido:"${f.secoundSurname}",
              identificacion:"${f.identification}",
              tipo_identificacion_id:${f.documentType?f.documentType.id:2},
              genero_id:${f.sex.id},
              fecha_nacimiento:"${f.dateBirth}",
              estado_civil_id:${f.civilStatus.id},
              ocupacion_id:${f.activitie.id},
              escolaridad_id:${f.schooling.id},
              barrio_id:${f.neighborhood.id},
              direccion:"${f.address}",
              telefono:"${f.phone}",
              tenencia_id:${f.ownership.id},
              tipo_vivienda_id:${f.housingType.id},
              parentesco_id:${f.relationship.id},
              habita:${f.speak?1:0},
              contacto:${f.principal?1:0}
          },`
        });
        families = families.slice(0, -1);
        families += ']';
    }else {
      families= '[]'
    }

    

    console.log("dfdsfsdffsdf");
    let query = `mutation{
          newChildren(
            primer_nombre:"${basicData.name}",
            # segundo_nombre:"${basicData.secondName?basicData.secondName:null}",
            primer_apellido:"${basicData.surname}",
            segundo_apellido:"${basicData.secoundSurname}",
            genero_id:${basicData.sex.id},
            fecha_nacimiento:"${basicData.dateBirth}",
            estado_civil_id:${basicData.civilStatusId?basicData.civilStatusId:null},
            ocupacion_id:${basicData.ocupacionId?basicData.ocupacionId:null},
            grupo_etnico_id:${basicData.ethnicGroup?basicData.ethnicGroup.id:null},
            identifications:${identifications},
            houses:[${basicData.infoHome.house.id}],
            regional_ha:${basicData.regional},
            letra_ha:"${basicData.leter}",
            numero_ha:"${basicData.number}",
            anio_ha:${basicData.number},
            numero_hermanos:${basicData.brothers},
            ubicacion_id:${basicData.location?basicData.location.id:null},
            sim:"${basicData.sim}",
            trabajador_social_id:${basicData.infoHome.socialWorker.id},
            psicologo_id:${basicData.infoHome.psychologist.id},
            fecha_ingreso_icbf:"${stateProcess.icbfIncome}",
            numero_ingresos_icbf:${stateProcess.icbfIncomeNumber},
            fecha_ingreso:"${stateProcess.hcmIncome}",
            centro_zonal_id:${stateProcess.zonalCenter?stateProcess.zonalCenter.id:null},
            tipo_resolucion_id:${stateProcess.resolutionType?stateProcess.resolutionType.id:null},
            numero_resolucion:"${stateProcess.resolutionNumber}",
            fecha_resolucion:"${stateProcess.resolutionDate}",
            comisaria_familiar_id:${stateProcess.familyCommissary?stateProcess.familyCommissary.id:null},
            defensor:"${stateProcess.defender}",
            barrio_id:${stateProcess.neighborhood?stateProcess.neighborhood.id:null},
            motivo_ingreso_id:${stateProcess.reasonAdmission?stateProcess.reasonAdmission.id:null},
            descripcion_ingreso_icbf:"${stateProcess.icbfDescription}",
            descripcion_ingreso_psicosocial:"${stateProcess.teamPsychosocial}",
            escolaridad_id:${characterization.schooling?characterization.schooling.id:null},
            enfermedad:${characterization.disease?characterization.disease.id:null},
            tipo_vacuna:"${characterization.vaccine?characterization.vaccine.name:null}",
            accidente:${characterization.accident?characterization.accident.id:null},
            estado_nutricional_id:${characterization.nutritionalState?characterization.nutritionalState.id:null},
            tipo_discapacidad_id:${characterization.typeDisability?characterization.typeDisability.id:null},
            regimen:"${characterization.regime?characterization.regime.name:null}",
            nombre_regimen:"${characterization.regimeName}",
            area_social:${familyComposition.socialArea?familyComposition.socialArea.id:null},
            tipo_familia_id:${familyComposition.familyType?familyComposition.familyType.id:null},
            responsable_nna_id:${familyComposition.responsible?familyComposition.responsible.id:null},
            antecedente_familiar_nna_id:${familyComposition.familyBackground?familyComposition.familyBackground.id:null},
            ingreso_familiar_nna_id:${familyComposition.familyIncome?familyComposition.familyIncome.id:null},
            ocupacion_familiar_nna_id:${familyComposition.activitie?familyComposition.activitie.id:null},
            aporta_economicamente_familiar_nna_id:${familyComposition.peopleWhoContributeFinancially?familyComposition.peopleWhoContributeFinancially.id:null},
            escolaridad_familiar_nna_id:${familyComposition.schooling?familyComposition.schooling.id:null},
            family:${families}){
          code
          message
          status_transaction
        }
     }`
     console.log(query);
    let result = await post({query}, "children")

    return result
    
  } catch (error) {
      logMichin(error)

      return error
      
  }
} 

export const nnaList = async () => {

  try {
      let query = `query{
          nnaList{
            childrenActive{
              user{
                    primer_nombre
                    segundo_nombre
                    primer_apellido
                    segundo_apellido
                    fecha_nacimiento
              }
              children_house{
                house{
                    id
                    nombre
                    direccion
                  }
              }
              psychologist{      
                id
                primer_nombre
                segundo_nombre
                primer_apellido
                segundo_apellido              
              }
              social_work{
                id
                primer_nombre
                segundo_nombre
                primer_apellido
                segundo_apellido   
              }
              id
              sim
              numero_ha
           } 
           childrenInactive{
              user{
                primer_nombre
                segundo_nombre
                primer_apellido
                segundo_apellido
              }
              id
              sim
              numero_ha
              fecha_ingreso
              fecha_egreso
           }  
          }
        }`
      let result = await post({query}, "children")

      return result
      
  } catch (error) {
      logMichin(error)

      return error
      
  }
  

}

