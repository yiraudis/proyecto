export const logMichin = (...logs)=>{
    if (true) {
        console.log('=================INICIO===================');
        console.log(...logs);
        console.log('=================FIN===================');

    }
}
