import Vue from 'vue'
import Vuex from 'vuex'
import { familyRelationships, categoryMeta, documentTypes, sexs, countries, ethnicGroups, locations, zonalCenters, reasonAdmissions, typesFamily, responsables, familyIncome, familyOccupations, familyBackground, scholarships, familyCurators, cities } from './services/default'
import { houses, socialWorkers, psychologists } from './services/children'
import { logMichin } from './functions'
Vue.use(Vuex)
const stores = new Vuex.Store({
    state: {
        categoryMetas: [],
        documentTypes: [],
        sexs: [],
        countries: [],
        ethnicGroups: [],
        locations: [],
        zonalCenters: [],
        houses: [],
        socialWorkers: [],
        psychologists: [],
        reasonAdmissions: [],
        departmetSelected: { cities: [] },
        typesFamily: [],
        responsables: [],
        familyIncome: [],
        familyOccupations: [],
        familyBackground: [],
        familyRelationships: [],
        scholarships: [],
        familyCurators: [],
        cities: [],
        categoryMetas:[],
        documentTypes:[],
        sexs:[],
        countries:[],
        ethnicGroups:[],
        locations:[],
        zonalCenters:[],
        houses:[],
        socialWorkers:[],
        psychologists:[],
        reasonAdmissions:[],
        departmetSelected:{cities:[]},
        typesFamily:[],
        responsables:[],
        familyIncome:[],
        familyOccupations:[],
        familyBackground:[],
        scholarships:[],
        familyCurators:[],
        cities:[],
        family:[]
    },
    mutations: {
        setDocuments(state, payload) {
            state.documentTypes = payload
        },
        setRelationships(state, payload) {
            state.familyRelationships = payload
        },
        setCategoryMetas(state, payload) {
            state.categoryMetas = payload
        },
        setSexs(state, payload) {
            state.sexs = payload
        },
        setCountries(state, payload) {
            state.countries = payload
        },
        setEthnicGroups(state, payload) {
            state.ethnicGroups = payload
        },
        setLocations(state, payload) {
            state.locations = payload
        },
        setZonalCenters(state, payload) {
            state.zonalCenters = payload
        },

        setHouses(state, payload) {
            state.houses = payload
        },
        setSocialWorkers(state, payload) {
            state.socialWorkers = payload
        },
        setPsychologists(state, payload) {
            state.psychologists = payload
        },
        setReasonAdmissions(state, payload) {
            state.reasonAdmissions = payload
        },
        setDepartmetSelected(state, payload) {
            state.departmetSelected = payload
        },
        setTypesFamily(state, payload) {
            state.typesFamily = payload
        },
        setResponsables(state, payload) {
            state.responsables = payload
        },
        setFamilyIncome(state, payload) {
            state.familyIncome = payload
        },
        setFamilyOccupations(state, payload) {
            state.familyOccupations = payload
        },
        setFamilyBackground(state, payload) {
            state.familyBackground = payload
        },
        setScholarships(state, payload) {
            state.scholarships = payload
        },
        setFamilyCurators(state, payload) {
            state.familyCurators = payload
        },
        setCities(state, payload) {
            state.cities = payload
        },
        setFamily(state, payload) {
            state.family = payload
        },
    },
    actions: {
        async getfamilyRelationships({ commit }) {
            let data = await familyRelationships()
            if (data.data) {
                commit('setRelationships', data.data.familyRelationships)
            } else {
                logMichin("Error", data)
            }

        },

        async getDocumentTypes({ commit }) {
            let data = await documentTypes()
            if (data.data) {
                commit('setDocuments', data.data.documentTypes)
            } else {
                logMichin("Error", data)
            }

        },

        async getCategoryMetas({ commit }) {
            let data = await categoryMeta()
            if (data.data) {
                logMichin(data)
                commit('setCategoryMetas', data.data.categoryMeta)
            } else {
                logMichin("Error", data)
            }

        },

        async getSexs({ commit }) {
            let data = await sexs()
            if (data.data) {
                commit('setSexs', data.data.sexs)
            } else {
                logMichin("Error", data)
            }

        },

        async getCountries({ commit }) {
            let data = await countries()
            if (data.data) {
                commit('setCountries', data.data.countries)
            } else {
                logMichin("Error", data)
            }

        },

        async getEthnicGroups({ commit }) {
            let data = await ethnicGroups()
            if (data.data) {
                commit('setEthnicGroups', data.data.ethnicGroups)
            } else {
                logMichin("Error", data)
            }

        },

        async getLocations({ commit }) {
            let data = await locations()
            if (data.data) {
                commit('setLocations', data.data.locations)
            } else {
                logMichin("Error", data)
            }
        },
        async getZonalCenters({ commit }) {
            let data = await zonalCenters()
            if (data.data) {
                commit('setZonalCenters', data.data.zonalCenters)
            } else {
                logMichin("Error", data)
            }
        },
        async getHouses({ commit }) {
            let data = await houses()
            if (data.data) {
                commit('setHouses', data.data.houses)
            } else {
                logMichin("Error", data)
            }
        },

        async getSocialWorkers({ commit }) {
            let data = await socialWorkers()
            if (data.data) {
                commit('setSocialWorkers', data.data.socialWorkers)
            } else {
                logMichin("Error", data)
            }
        },
        async getPsychologists({ commit }) {
            let data = await psychologists()
            if (data.data) {
                commit('setPsychologists', data.data.psychologists)
            } else {
                logMichin("Error", data)
            }
        },
        async getReasonAdmissions({ commit }) {
            let data = await reasonAdmissions()
            if (data.data) {
                commit('setReasonAdmissions', data.data.reasonAdmissions)
            } else {
                logMichin("Error", data)
            }
        },
        async getTypesFamily({ commit }) {
            let data = await typesFamily()
            if (data.data) {
                commit('setTypesFamily', data.data.TypesFamily)
            } else {
                logMichin("Error", data)
            }
        },
        async getResponsables({ commit }) {
            let data = await responsables()
            if (data.data) {
                commit('setResponsables', data.data.responsables)
            } else {
                logMichin("Error", data)
            }
        },
        async getFamilyIncome({ commit }) {
            let data = await familyIncome()
            if (data.data) {
                commit('setFamilyIncome', data.data.familyIncome)
            } else {
                logMichin("Error", data)
            }
        },
        async getFamilyOccupations({ commit }) {
            let data = await familyOccupations()
            if (data.data) {
                commit('setFamilyOccupations', data.data.familyOccupations)
            } else {
                logMichin("Error", data)
            }
        },
        async getFamilyBackground({ commit }) {
            let data = await familyBackground()
            if (data.data) {
                commit('setFamilyBackground', data.data.familyBackground)
            } else {
                logMichin("Error", data)
            }
        },
        async getScholarships({ commit }) {
            let data = await scholarships()
            if (data.data) {
                commit('setScholarships', data.data.scholarships)
            } else {
                logMichin("Error", data)
            }
        },
        async getFamilyCurators({ commit }) {
            let data = await familyCurators()
            if (data.data) {
                commit('setFamilyCurators', data.data.familyCurators)
            } else {
                logMichin("Error", data)
            }
        },
        async getCities({ commit }) {
            let data = await cities()
            if (data.data) {
                commit('setCities', data.data.cities)
            } else {
                logMichin("Error", data)
            }
        }
        //reasonAdmissions
    }
})


export default stores;