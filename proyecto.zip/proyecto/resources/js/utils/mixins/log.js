
let p = {
    data () {
    return {}
    },
    methods: {
        logMichin(...log){
            console.log('====================================');
            console.log(...log);
            console.log('====================================');
        }
      
    }
}



export default p