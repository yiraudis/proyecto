import {required, minLength, maxLength} from 'vuelidate/lib/validators'
import { customValidate, minDate } from '../globals'
export const familyComposition = {
    families: {
        minLength: minLength(1)
    },
    
    socialArea:{
        customValidate:customValidate()
    },

    familyType:{
        customValidate:customValidate()
    },

    responsible:{
        customValidate:customValidate()
    },


    familyBackground:{
        customValidate:customValidate()
    },

    familyIncome:{
        customValidate:customValidate()
    },

    activitie:{
        customValidate:customValidate()
    },

    peopleWhoContributeFinancially:{
        customValidate:customValidate()
    },


    schooling:{
        customValidate:customValidate()
    },
    
}
export const family = {
    
    name:{
        required,
        minLength: minLength(4),
    },
    surname: {
        required,
        minLength: minLength(4)
    },
    secoundSurname:{
        required,
        minLength: minLength(4)
    },
    identification:{
        required,
        minLength: minLength(4),
    },
    dateBirth:{
        required,
        minDate
    },
    sex:{
        required,
        customValidate:customValidate()
    },
    schooling:{
        required,
        customValidate:customValidate()
    },
    civilStatus:{
        required,
        customValidate:customValidate()
    },
    city:{
        required,
        customValidate:customValidate()
    },
    residenceLocality:{
        required,
        customValidate:customValidate()
    },
    relationship:{
        required,
        customValidate:customValidate()
    },
    activitie:{
        required,
        customValidate:customValidate()
    },
    neighborhood:{
        required,
        customValidate:customValidate()
    },
    address:{
        required,
        minLength: minLength(4),
    },
    housingType:{
        required,
        customValidate:customValidate()
    },
    ownership:{
        required,
        customValidate:customValidate()
    },
    phone:{
        required,
        minLength: minLength(4),
    },

}

