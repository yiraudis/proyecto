import { required, minLength, minValue, maxValue } from 'vuelidate/lib/validators'
import { customValidate, minDate } from '../globals'


export const characterizacion = {
    schooling:{
        customValidate:customValidate()
    },
    disease:{
        customValidate:customValidate()
    },
    vaccine:{
        customValidate:customValidate()
    },
    accident:{
        customValidate:customValidate()
    },
    typeDisability:{
        customValidate:customValidate()
    },
    nutritionalState:{
        customValidate:customValidate()
    },
    regime:{
        customValidate:customValidate()
    },
    regimeName:{
        minLength: minLength(4)
    }
}