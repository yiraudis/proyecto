import { required, minLength, minValue, maxValue } from 'vuelidate/lib/validators'
import { customValidate, minDate } from '../globals'


export const stateProcess = {
    icbfIncome:"",
    icbfIncomeNumber:{
        minLength: minLength(1),
        minValue: minValue(1),
        maxValue: maxValue(10)
    },
    hcmIncome: {
        minLength: minLength(0)
    },
    resolutionType:{
        required,
        customValidate:customValidate()
    },
    resolutionNumber: {
        minLength: minLength(3)
    },
    resolutionDate:{
        minDate
    },
    residenceLocality:{
        customValidate:customValidate()
    },
    neighborhood:{
        customValidate:customValidate()
    },
    reasonAdmission:{
        customValidate:customValidate()
    },
    icbfDescription: {
        required,
        minLength: minLength(4)
    },
    teamPsychosocial: {
        minLength: minLength(4)
    },
    familyCommissary:{
    
        customValidate:customValidate()
    },
    zonalCenter:{
    
        customValidate:customValidate()
    },
    defender:{
    
        minLength: minLength(4)
    },
    
}