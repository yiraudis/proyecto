import {required, minLength, maxLength} from 'vuelidate/lib/validators'
import { customValidate, minDate } from '../globals'
export const basicData = {
    name: {
        required,
        minLength: minLength(4)
    },
    surname: {
        required,
        minLength: minLength(4)
    },
    secoundSurname:{
        required,
        minLength: minLength(4)
    },
    
    sex:{
        required,
        customValidate:customValidate()
    },
    dateBirth:{
        minDate
    },
    country:{
        required,
        customValidate:customValidate()
    },
    department:{
        required,
        customValidate:customValidate()
    },
    city:{
        required,
        customValidate:customValidate()
    },
    regional:{
        required,
        minLength: minLength(2)
    },
    leter:{
        required,
        minLength: minLength(1),
        maxLength: maxLength(2)
    },
    number:{
        required,
        minLength: minLength(2)
    },
    brothers:{
        required,
        minLength: maxLength(2)
    },
    ethnicGroup:{
        customValidate:customValidate()
    },
    sim:{
        required,
        minLength: minLength(4)
    },
    documentTypes:{
        minLength: minLength(1)
    },
    location:{
        customValidate:customValidate()
    },
    infoHome:{
        required,
        customValidate:customValidate()
    },
}

export const infoHome = {
    house:{
        required,
        customValidate:customValidate("primer_nombre")
    },
    socialWorker:{
        required,
        customValidate:customValidate("primer_nombre")
    },
    psychologist:{
        required,
        customValidate:customValidate("primer_nombre")
    },
    
}

export const newDocumentType = {
    documentType:{
        required,
        customValidate:customValidate()
    },
    document:{
        required,
        minLength: minLength(4),
        maxLength: maxLength(11)
    },
    expeditionDate:{
        required,
        minDate
    },
}