export const customValidate = (value, key = "nombre") => value != null && value[key] ? true:false
export const minDate = value => value < new Date().toISOString()
export const isNumeric = (n)=> !isNaN(parseFloat(n)) && isFinite(n);
