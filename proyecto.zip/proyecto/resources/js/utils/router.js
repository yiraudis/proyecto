import VueRouter from "vue-router";
import Children from "../Pages/Children/View.vue";
import EvaluationIndividualIncomePsychology from "../Pages/Evaluations/IndividualIncomePsychology/View.vue";
import EvaluationFamilyIncomePsychology from "../Pages/Evaluations/FamilyIncomePsychology/View.vue";
import EvaluationIndividualIncomeSocial from "../Pages/Evaluations/IndividualIncomeSocial/View.vue";
import EvaluationFamilySocial from "../Pages/Evaluations/FamilySocial/View.vue";
import PlatinNuevo from "../Pages/IcbfReports/Platin/View.vue";
import InformeNNA from "../Pages/IcbfReports/NNA/View.vue";
import PlatinListado from "../Pages/IcbfReports/Platin/ListPlatin.vue";
import NnaListado from "../Pages/Children/ListChildren.vue";
import FamilyList from "../Pages/FamilyRegister/ListFamily.vue";
import Home from "../Pages/Home/View.vue";

// import Genograma from "../Pages/Evaluations/Components/Genograma.vue";

let pathInit = "/admin/";
const routes = [
    {
        path: `${pathInit}children`,
        name: "children",
        component: Children
    },
    {
        path: `${pathInit}eva_psi_ingreso_ind`,
        name: "eva_psi_ingreso_ind",
        component: EvaluationIndividualIncomePsychology
    },
    {
        path: `${pathInit}eva_psi_ingreso_familiar`,
        name: "eva_psi_ingreso_familiar",
        component: EvaluationFamilyIncomePsychology
    },
    {
        path: `${pathInit}eva_sociofamiliar_ingreso`,
        name: "eva_sociofamiliar_ingreso",
        component: EvaluationFamilySocial
    },
    {
        path: `${pathInit}eva_social_ingreso_ind`,
        name: "eva_social_ingreso_ind",
        component: EvaluationIndividualIncomeSocial
    },
    {
        path: `${pathInit}gestionar_platin/:id`,
        name: "registro_nplatin",
        component: PlatinNuevo
    },
    {
        path: `${pathInit}listado_platin`,
        name: "listado_platin",
        component: PlatinListado
    },
    {
        path: `${pathInit}informe_nna`,
        name: "informe_nna",
        component: InformeNNA
    },
    {
        path: `${pathInit}listado_nna`,
        name: "listado_nna",
        component: NnaListado
    },
    {
        path: `${pathInit}listado_familia`,
        name: "listado_familia",
        component: FamilyList
    },
    {
        path: `${pathInit}home`,
        name: "home",
        component: Home
    }
];

const router = new VueRouter({
    history: true,
    mode: "history",
    routes
});

export default router;
