<template>
    <form @submit.prevent="save()" class="fade-in">
      <div class="row">
          <BigHead :name_evaluacion="name_evaluacion" />
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>Panel de búsqueda</strong>
              <small>NNA</small>
            </div>
            <div class="card-body">
              <SearchPanel @children="resultChildren" />
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>Datos de Identidad</strong>
              <small>NNA</small>
            </div>
            <div class="card-body" v-if="children.id">
               <IdentityData @identityData="identityData" :children="children" v-if="children.id"/>
            </div>
          </div>
        </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
              <strong>2. Vida Saludable</strong>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group row">
                    <label class="col-md-7 col-form-label" for="health-affiliation">Afiliación al sistema de salud</label>
                    <div class="col-md-5 col-form-label">
                      <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input" id="health-affiliation1" type="radio" value="si" name="health-affiliation">
                          <label class="form-check-label" for="health-affiliation1">Si</label>
                      </div>
                      <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input" id="health-affiliation2" type="radio" value="no" name="health-affiliation">
                          <label class="form-check-label" for="health-affiliation2">No</label>
                      </div>
                    </div>
                 </div>
              </div>
              <div class="col-md-4">
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="health-regime">Régimen</label>
                    <div class="col-md-9 col-form-label">
                      <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input" id="health-regime1" type="radio" value="CONTRIBUTIVO" checked v-model="data_save.vida_saludable.regimen" name="health-regime">
                          <label class="form-check-label" for="health-regime1">Contributivo</label>
                      </div>
                      <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input" id="health-regime2" type="radio" value="SUBSIDIADO" v-model="data_save.vida_saludable.regimen" name="health-regime">
                          <label class="form-check-label" for="health-regime2">Subsidiado</label>
                      </div>
                      <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input" id="health-regime3" type="radio" value="NINGUNA" v-model="data_save.vida_saludable.regimen" name="health-regime">
                          <label class="form-check-label" for="health-regime3">Ninguna</label>
                      </div>
                    </div>
                 </div>
              </div>
              <div class="col-md-4">
                <input  type="text" v-model.trim="data_save.vida_saludable.nombre_regimen" id="health_name" name="health_name" class="form-control" placeholder="Nombre">
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-md-12 subtitulo-vidas">
                  <h4>Utilización servicios de salud</h4>
              </div>
              <div class="form-group col-md-6">
                <label for="service-type">Tipo servicio</label>
                <v-select v-model="type_service" :options="servicesType" label="nombre" placeholder="Seleccione una categoría" inputId="service-type">
                  <template slot="no-options">
                      <span>No existe servicio</span>
                  </template>
                 </v-select>
                <small class="text-success"><a href="#">Agregar nuevo tipo de servicio</a></small>
              </div>
              <div class="form-group col-md-4">
                <label for="health-scale">Escala</label>
                <div class="col-md-12 col-form-label">
                  <div class="form-check form-check-inline mr-1" v-for="(item, index) in frecuencias" :key="index">
                        <input class="form-check-input" v-model="frecuencia" :id="'health-scale1'+index" type="radio" :value="item" name="health-scale">
                        <label class="form-check-label" :for="'health-scale1'+index">{{ item.nombre }}</label>
                  </div>
                </div>
              </div>
              <div class="form-group col-md-2">
                <label for="add-scale"></label>
                <button id="add-scale" @click="addServicio" class="btn btn-block btn-outline-success" type="button" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Agregar</button>
              </div>
              <div class="col-md-8" v-if="data_save.vida_saludable.servicio_salud.length > 0">
                <table class="table table-sm">
                    <thead>
                    <tr>
                        <th>Tipo de servicio</th>
                        <th>Escala</th>
                        <th>Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in data_save.vida_saludable.servicio_salud" :key="index">
                            <td>{{item.type_service.nombre}}</td>
                            <td>{{item.frecuencia.nombre}}</td>
                            <td>
                                <button @click="data_save.vida_saludable.servicio_salud.splice(index,1)" type="button" class="btn btn-pill btn-outline-danger  pull-right btn-add-c">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
              </div>
              <div class="form-group col-md-12">
                  <textarea class="form-control textarea-g" v-model="data_save.vida_saludable.observacion" id="health-scale-end" name="health-scale-end" rows="4" placeholder="Observaciones"></textarea>
                </div>
            </div>
          </div>
        </div>
        </div>
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>3. Desarrollo de potenciales</strong>
            </div>
            <div class="card-body">
              <div class="row justify-content-center">
                <div class="form-group col-md-3">
                  <label for="school">Institución educativa</label>
                  <input  type="text" v-model="data_potencial.institucion" id="school" name="school" class="form-control">
                </div>
                <div class="form-group col-md-3">
                  <label for="school">Tipo</label>
                  <div class="col-md-12 col-form-label">
                    <div class="form-check form-check-inline mr-1">
                        <input class="form-check-input" id="school1" v-model="data_potencial.tipo" type="radio" value="1" name="school">
                        <label class="form-check-label" for="school1">Pública</label>
                    </div>
                    <div class="form-check form-check-inline mr-1">
                        <input class="form-check-input" id="school2" v-model="data_potencial.tipo" type="radio" value="2" name="school">
                        <label class="form-check-label" for="school2">Privado</label>
                    </div>
                    <div class="form-check form-check-inline mr-1">
                        <input class="form-check-input" id="school3" v-model="data_potencial.tipo" type="radio" value="3" name="school">
                        <label class="form-check-label" for="school3">Otro</label>
                    </div>
                  </div>
                </div>
                <div class="form-group col-md-2">
                  <label for="date-school">Año</label>
                  <datetime input-class="form-control" type="date" :flow="['year', 'date', 'time']" input-id="date-school" v-model="data_potencial.year" placeholder="Año"></datetime>
                </div>
                <div class="form-group col-md-2">
                  <label for="taken-school">Grado cursado</label>
                  <v-select v-model="data_potencial.grado" :options="grados" label="nombre" placeholder="Seleccione un cursado" inputId="taken-school">
                    <template slot="no-options">
                        <span>No existe grado cursado</span>
                    </template>
                  </v-select>
                  <small class="text-success"><a href="#">Agregar grado cursado</a></small>
                </div>
                <div class="form-group col-md-2">
                  <label for="certificate-certificate-school">Certificado escolar</label>
                  <div class="col-md-12 col-form-label">
                    <div class="form-check form-check-inline mr-1">
                        <input class="form-check-input" id="certificate-school1" v-model="data_potencial.certificado" checked type="radio" value="1" name="certificate-school">
                        <label class="form-check-label" for="certificate-school1">Si</label>
                    </div>
                    <div class="form-check form-check-inline mr-1">
                        <input class="form-check-input" id="certificate-school2" v-model="data_potencial.certificado" type="radio" value="0" name="certificate-school">
                        <label class="form-check-label" for="certificate-school2">No</label>
                    </div>
                    <button id="add-school" class="btn btn-pill btn-outline-success  pull-right btn-add-c" @click="addPotencial" type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="Tooltip on top"><i class="bnt-ico fas fa-check-double"></i></button>
                  </div>
                </div>
                <div class="col-md-8" v-if="data_save.desarrollo_potenciales.potenciales.length > 0">
                    <table class="table table-sm">
                        <thead>
                        <tr>
                            <th>Institución</th>
                            <th>Tipo</th>
                            <th>Año</th>
                            <th>Grado</th>
                            <th>Certificado</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in data_save.desarrollo_potenciales.potenciales" :key="index">
                                <td>{{item.institucion}}</td>
                                <td>
                                    <span v-if="item.tipo == 1">Pública</span>
                                    <span v-if="item.tipo == 2">Privada</span>
                                    <span v-if="item.tipo == 3">Otro</span>
                                </td>
                                <td>{{ new Date(item.year).getFullYear() }}</td>
                                <td>{{item.grado.nombre}}</td>
                                <td>
                                    <span v-if="item.certificado == 0">No</span>
                                    <span v-if="item.certificado == 1">Si</span>
                                </td>
                                <td>
                                    <button @click="data_save.desarrollo_potenciales.potenciales.splice(index,1)" type="button" class="btn btn-pill btn-outline-danger  pull-right btn-add-c">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                 <div class="form-group col-md-12">
                  <label for="Observations-school">Observaciones</label>
                  <textarea v-model="data_save.desarrollo_potenciales.observacion" class="form-control textarea-g" id="Observations-school" name="Observations-school" rows="4" placeholder="Observaciones"></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>4. Fortalecimiento individual y familiar</strong>
            </div>
            <div class="card-body">
              <div class="row">
                  <div class="col-md-12 subtitulo-vidas">
                      <h4>4.1 Antecedentes Institucionales</h4>
                  </div>
                  <div class="form-group col-md-4">
                    <label for="past-icbf-name">Nombre Institución</label>
                    <input v-model.trim="data_antecedente.institucion"  type="text" id="past-icbf-name" name="past-icbf-name" class="form-control">
                  </div>
                  <div class="form-group col-md-4">
                     <div class="form-group row">
                       <label class="col-md-6 col-form-label" for="optability">Adoptabilidad</label>
                        <!-- <div class="col-md-6 col-form-label">
                          <div class="form-check form-check-inline mr-1">
                              <input class="form-check-input" id="option-adoptability1" type="radio" value="si" name="option-adoptability">
                              <label class="form-check-label" for="option-adoptability1">Si</label>
                          </div>
                          <div class="form-check form-check-inline mr-1">
                              <input class="form-check-input" id="option-adoptability2" type="radio" value="no" name="option-adoptability">
                              <label class="form-check-label" for="option-adoptability2">No</label>
                          </div>
                        </div> -->
                        <div class="col-md-12">
                          <input v-model.trim="data_antecedente.adoptabilidad"  type="text" placeholder="N°" id="adoptability-num" name="adoptability-num" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="form-group col-md-4">
                    <div class="form-group row">
                      <label class="col-md-6 col-form-label" for="adoptability">Vulnerabilidad</label>
                      <!-- <div class="col-md-6 col-form-label">
                        <div class="form-check form-check-inline mr-1">
                            <input class="form-check-input" id="option-vulnerability1" type="radio" value="si" name="option-vulnerability">
                            <label class="form-check-label" for="option-vulnerability1">Si</label>
                        </div>
                        <div class="form-check form-check-inline mr-1">
                            <input class="form-check-input" id="option-vulnerability2" type="radio" value="no" name="option-vulnerability">
                            <label class="form-check-label" for="option-vulnerability2">No</label>
                        </div>
                      </div> -->
                      <div class="col-md-12">
                        <input v-model.trim="data_antecedente.vulnerabilidad"  type="text" id="vulnerability-name" name="vulnerability-name" placeholder="N°" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group col-md-12">
                        <label for="date-admission">Fecha de ingreso</label>
                        <datetime v-model.trim="data_antecedente.fecha_ingreso" input-class="form-control" input-id="date-admission" placeholder="Fecha de ingreso"></datetime>
                    </div>
                    <div class="form-group col-md-12">
                      <label for="date-admission">Motivo de Ingreso</label>
                      <textarea v-model.trim="data_antecedente.motivo_ingreso" class="form-control textarea-g" id="description-category" name="description-category" rows="4" placeholder=""></textarea>
                    </div>
                 </div>
                 <div class="col-md-6">
                    <div class="form-group col-md-12">
                        <label for="date-admission">Fecha de Egreso</label>
                        <datetime v-model.trim="data_antecedente.fecha_egreso" input-class="form-control" input-id="date-admission" placeholder="Fecha de ingreso"></datetime>
                    </div>
                    <div class="form-group col-md-12">
                      <label for="date-admission">Motivo de Egreso</label>
                      <textarea v-model.trim="data_antecedente.motivo_egreso" class="form-control textarea-g" id="description-category" name="description-category" rows="4" placeholder=""></textarea>
                    </div>
                 </div>
                <div class=" form-group col-md-12">
                  <button @click="addAntecedente" id="add-category" class="btn btn-outline-success pull-right" type="button" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Agregar</button>
                </div>
                <div class="col-md-12 table-responsive" v-if="data_save.antecedentes_institucionales.length > 0">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">Nombre Inst</th>
                            <th scope="col">Motivo Ingreso</th>
                            <th scope="col">Fecha Ingreso</th>
                            <th scope="col">Motivo Egreso</th>
                            <th scope="col">Fecha Egreso</th>
                            <th scope="col">Adoptabilidad</th>
                            <th scope="col">Vulnerabilidad</th>
                            <th scope="col">Acciones</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in data_save.antecedentes_institucionales" :key="index">
                                <td>{{item.institucion}}</td>
                                <td>{{item.motivo_ingreso}}</td>
                                <td>{{item.fecha_ingreso}}</td>
                                 <td>{{item.motivo_egreso}}</td>
                                <td>{{item.fecha_egreso}}</td>
                                <td>{{item.adoptabilidad}}</td>
                                <td>{{item.vulnerabilidad}}</td>
                                <td>
                                    <button @click="data_save.antecedentes_institucionales.splice(index,1)" type="button" class="btn btn-pill btn-outline-danger  pull-right btn-add-c">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.2 Motivo de Ingreso Actual (apreciación de niños, niñas y adolescentes)</h4>
                </div>
                <div class="form-group col-md-12">
                    <textarea v-model.trim="data_save.motivo_ingreso" class="form-control textarea-g" id="reason-entry" name="reason-entry" rows="4" placeholder=""></textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.3 Factor de Riesgo a los que ha estado expuesto</h4>
                </div>
                <div class="form-group col-md-12">
                    <div class="form-check form-check-inline mr-1" v-for="(item, index) in riesgos" :key="index">
                      <input class="form-check-input" v-model="data_save.factores_riesgo" :id="'riesgo'+item.id" type="checkbox" :value="item.id">
                      <label class="form-check-label" :for="'riesgo'+item.id">{{ item.nombre }}</label>
                    </div>

                </div>
                <div class="form-group col-md-12">
                  <label for="risks-observations">Observaciones</label>
                  <textarea v-model.trim="data_save.observacion_riesgo"  class="form-control textarea-g" id="observations" name="observations" rows="4" placeholder=""></textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.4 Composición Familiar (personas con quien viva el(a) niño(a) a su ingreso)</h4>
                </div>
                <div class="col-md-12">
                  <!-- <FamilyComposition/> -->
                    <IdentityDataEvF :children="children" :title="`<strong>Composición familiar</strong>`" :showNameDate:="false" @dataEntrevistados="getFamilies" />

                </div>
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.5 Mapa de pertenencia actual y participación social</h4>
                </div>
                <MembershipMap @observacionesMap="addObservacionesMap" @membershipMap="addMmebershipMap" />
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.6 Dinámica Familiar</h4>
                </div>
                <div class="form-group col-md-12">
                  <textarea v-model.trim="data_save.dinamica_familiar" class="form-control textarea-g" id="family-dynamics" name="family-dynamics" rows="4" placeholder=""></textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 subtitulo-vidas">
                  <h4>4.7 Vivienda</h4>
                </div>
                <!-- <div class="form-group col-md-3">
                  <label for="living-location">Localidad</label>
                  <v-select v-model="data_save.locality" :options="locality" label="name" placeholder="Seleccione una localidad" inputId="living-location">
                    <template slot="no-options">
                        <span>No existe localidad</span>
                    </template>
                   </v-select>
                  <small class="text-success"><a href="#">Agregar nueva localidad</a></small>
                </div> -->
                <div class="form-group col-md-4">
                  <label for="living-neighborhood">Barrio</label>
                  <v-select v-model="data_save.neighborhood" :options="neighborhoods" label="nombre" placeholder="Seleccione un barrio" inputId="living-neighborhood">
                    <template slot="no-options">
                        <span>No existe barrio</span>
                    </template>
                   </v-select>
                  <small class="text-success"><a href="#">Agregar nuevo barrio</a></small>
                </div>
                <div class="form-group col-md-4">
                  <label for="living-address">Dirección</label>
                    <input  type="text" v-model="data_save.address" id="living-address" name="living-address" placeholder="" class="form-control">
                </div>
                <div class="form-group col-md-4">
                  <label for="living-telephone">Teléfono</label>
                    <input  type="text" v-model="data_save.phone"   id="living-telephone" name="living-telephone" placeholder="" class="form-control">
                </div>
                <div class="form-group col-md-12">
                  <label for="social-economically">Situación Socio-económica</label>
                  <textarea v-model.trim="data_save.socio_economica" class="form-control textarea-g" id="social-economically" name="social-economically" rows="4" placeholder=""></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>5. Expectativas del niño, niña adolescente frente al proceso</strong>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="form-group col-md-12">
                  <textarea v-model.trim="data_save.expectativas" class="form-control textarea-g" id="expectancy-nna" name="expectancy-nna" rows="4" placeholder=""></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>6. Impresión diagnostico social de niño, niña o adolescente</strong>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="form-group col-md-12">
                  <textarea v-model.trim="data_save.impresiones" class="form-control textarea-g" id="diagnostic-nna" name="diagnostic-nna" rows="4" placeholder=""></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <FormulationAgreements  @resultCategories="dataCategories"/>
        </div>
      </div>
      <div class="row justify-content-center">
        <h5 class="text-center">
            <button  id="save-evaluation" class="btn btn-outline-success active" type="submit" aria-pressed="true">Guardar evaluacion</button>
        </h5>
      </div>
    </form>
</template>
<script>
import SearchPanel from "../Components/SearchPanel";
import IdentityData from "./Components/IdentityData";
import FormulationAgreements from "../Components/FormulationAgreements";
import FamilyComposition from "../Components/FamilyComposition";
import BigHead from "../Components/BigHead";
import MembershipMap from "../Components/MembershipMap";
import IdentityDataEvF from "../Components/IdentityDataEvF";
import {getComplements,saveSocialIngresoIndividual} from '../../../utils/services/evaluations'
import { mapActions, mapState } from 'vuex'


export default {
  components: {
    SearchPanel,
    IdentityData,
    FormulationAgreements,
    MembershipMap,
    BigHead,
    FamilyComposition,
    IdentityDataEvF
  },
  data(){
        return {
            name_evaluacion: "Evaluación social individual",
            SinglySocial:{},
            servicesType:[],
            frecuencias:[],
            barrios:[],
            grados:[],
            riesgos:[],
            children:{},
            data_save:{
                entrevistados:null,
                vida_saludable:{
                    servicio_salud:[]
                },
                desarrollo_potenciales:{
                    potenciales:[]
                },
                antecedentes_institucionales:[],
                factores_riesgo:[],
                mebership_map:[],
                dataCategories:[],
                identityData:null
            },
            type_service:null,
            frecuencia:null,
            data_potencial:{},
            data_antecedente:{},
            locality:[
                {id:1, name:"Suba"},
                {id:2, name:"Usaquen"},
                {id:3, name:"Barrios Unidos"},
            ],
            neighborhoods:[],
        }
    },
    mounted() {
        this.getComplements()
    },
    methods: {
        ...mapActions(['getfamilyRelationships']),

        resultChildren(data){
            this.children = data
        },
        async getComplements(){
            let loader = this.$loading.show();
            try {
                let data = await getComplements()
                this.servicesType = data.services_type
                this.frecuencias = data.frecuencias
                this.grados = data.grados
                this.riesgos = data.riesgos
                this.neighborhoods = data.barrios
                loader.hide()
            } catch (error) {
                loader.hide()
                console.log(error);
            }
        },
        addServicio(){
            if(this.type_service && this.frecuencia){
                let validate = this.data_save.vida_saludable.servicio_salud.filter(item => item.type_service.id == this.type_service.id)

                if (validate.length > 0) {
                    this.$swal({
                        icon: 'warning',
                        text: "Ya añadió este tipo de servicio"
                    })
                    return false
                }
                this.data_save.vida_saludable.servicio_salud.push({type_service:this.type_service, frecuencia:this.frecuencia})
                this.type_service = null
                this.frecuencia = null
            }else{
                this.$swal({
                    icon: 'warning',
                    text: "Debe seleccionar un tipo de servicio y una escala"
                })
            }
        },
        addPotencial(){
            if (this.data_potencial.institucion && this.data_potencial.tipo && this.data_potencial.year && this.data_potencial.grado && this.data_potencial.certificado) {
                this.data_save.desarrollo_potenciales.potenciales.push(this.data_potencial)
                this.data_potencial = {}
            }else{
                this.$swal({
                    icon: 'warning',
                    text: "Todos los datos son requeridos"
                })
            }
        },
        addAntecedente(){
            if(this.data_antecedente.institucion && this.data_antecedente.fecha_ingreso && this.data_antecedente.motivo_ingreso && this.data_antecedente.fecha_egreso && this.data_antecedente.motivo_egreso){
                this.data_save.antecedentes_institucionales.push(this.data_antecedente)
                this.data_antecedente = {}
            }else{
                this.$swal({
                    icon: 'warning',
                    text: "Datos requeridos"
                })
            }
        },
        addMmebershipMap(data){
            this.data_save.mebership_map = data
        },
        addObservacionesMap(data){
            this.data_save.observacion_membership = data
        },
        dataCategories(data){
            this.data_save.dataCategories = data
        },
        identityData(data){
            this.data_save.identityData = data
        },
        getFamilies(data){
            this.data_save.entrevistados = data
        },
        async save(){
            if (!this.data_save.identityData || !this.data_save.identityData.primer_nombre) {
                this.$swal({
                    icon: 'warning',
                    text: `Debe elegir un NNA`
                })
            }else if(!this.data_save.dataCategories || this.data_save.dataCategories.length == 0){
                this.$swal({
                    icon: 'warning',
                    text: `Debe incluir almenos un acuerdo de intervención`
                })
            }else if(!this.data_save.entrevistados || this.data_save.entrevistados.entrevistados.length == 0){
                this.$swal({
                    icon: 'warning',
                    text: `Debe incluir almenos un entrevistado`
                })
            }else{
                console.log(this.data_save)
                let loader = this.$loading.show();
                try {
                    let resp = await saveSocialIngresoIndividual(this.data_save)
                    loader.hide()
                    console.log(resp);
                    if (resp.status_transaction) {
                        this.$swal({
                            icon: 'success',
                            text: `${resp.message}`
                        })
                        location.reload()
                        // if (resp.data.psicoIndividual.status_transaction) {
                        // }else{
                        //     this.$swal({
                        //         icon: 'error',
                        //         text: `${resp.data.psicoIndividual.message}`
                        //     })
                        // }
                        console.log(resp);
                    }else{
                        this.$swal({
                            icon: 'error',
                            text: `${resp.message}`
                        })
                    }
                } catch (error) {
                    loader.hide()
                    this.$swal({
                        icon: 'error',
                        text: `Estamos presentando fallos internos, recarga la pagina e intenta nuevamente`
                    })
                    return true
                }

            }
        }
    },
};
</script>
