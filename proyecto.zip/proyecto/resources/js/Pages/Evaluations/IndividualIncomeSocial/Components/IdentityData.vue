<template>
    <div class="row" v-if="children && children.children">
        <div class="form-group  col-md-6">
          <label for="nna-name">Nombre del NNA</label>
          <input class="form-control" id="nna-name" v-model="children.primer_nombre" type="text" name="nna-name">
        </div>
        <div class="form-group  col-md-4">
         <label for="date-birth">Fecha de nacimiento</label>
            <datetime v-model="children.fecha_nacimiento" :auto="true" input-class="form-control" input-id="date-birth" placeholder="Fecha de nacimiento"></datetime>
        </div>
        <div class="form-group  col-md-2">
          <label for="years">Edad </label>
          <input class="form-control" id="years" type="text" name="years" :value="ageCalculate" disabled>
        </div>
        <div class="form-group  col-md-4">
          <label for="ha_hsf">N° HA/HSF</label>
            <input  type="number" disabled :value="children.children[0].id" id="ha_hsf" name="ha_hsf" class="form-control" placeholder="Número historia de atención">
        </div>
        <div class="form-group  col-md-4">
         <label for="date-entry">Fecha de ingreso NNA</label>
            <datetime  input-class="form-control" v-model="children.children[0].fecha_ingreso" input-id="date-entry" placeholder="Fecha de Ingreso" disabled ></datetime>
        </div>
        <div class="form-group  col-md-4">
         <label for="date-evaluation">Fecha de evaluación</label>
            <datetime input-class="form-control" v-model="children.fecha_evaluacion"  input-id="date-evaluation" placeholder="Fecha de evaluación"></datetime>
        </div>
        <!-- <div class="form-group col-md-2">
            <label for="civil-registration">Registro civil</label>
            <div class="col-md-12 col-form-label">
                <div class="form-check form-check-inline mr-1">
                    <input class="form-check-input" id="civil-registration1" type="radio" value="si" name="civil-registration">
                    <label class="form-check-label" for="civil-registration1">Si</label>
                </div>
                <div class="form-check form-check-inline mr-1">
                    <input class="form-check-input" id="civil-registration2" type="radio" value="no" name="civil-registration">
                    <label class="form-check-label" for="civil-registration2">No</label>
                </div>
            </div>
        </div> -->
        <div class="form-group col-md-4">
            <label for="notary">Notaria</label>
            <input  type="text" v-model="children.notaria" id="notary" name="notary" class="form-control" placeholder="Notaria">
        </div>
         <div class="form-group col-md-4">
            <label for="registraduria">Registraduría</label>
            <input  type="text" v-model="children.registraduria" id="registraduria" name="registraduria" class="form-control" placeholder="Registraduría">
        </div>
        <div class="form-group col-md-4">
            <label for="serial">Serial</label>
            <input  type="text" v-model="children.serial" id="serial" name="serial" class="form-control" placeholder="Serial">
        </div>
         <div class="form-group col-md-4">
            <label for="nuip">NUIP</label>
            <input  type="text" v-model="children.nuip" id="nuip" name="nuip" class="form-control" placeholder="NUIP">
        </div>
        <div class="form-group col-md-6">
            <label for="defender">Remitido por</label>
            <input  type="text" v-model="children.defensor" id="defender" name="defender" class="form-control" placeholder="Defensor asignado">
        </div>

        <div class="d-none">
            {{ dataReturn }}
        </div>

    </div>
</template>
<script>
export default {
    props:{
        children:{
            type:Object,
            required:true
        },
    },
    data(){
        return {
            IdentityData: {},
        }
    },
    computed:{
        ageCalculate() {
            if (this.children) {
                let fecha = this.children.fecha_nacimiento

                if (typeof fecha != "string" && fecha && esNumero(fecha.getTime())) {
                    fecha = formatDate(fecha, "yyyy-MM-dd");
                }


                var values = fecha.split("-");
                var dia = values[2];
                var mes = values[1];
                var ano = values[0];

                // cogemos los valores actuales
                var fecha_hoy = new Date();
                var ahora_ano = fecha_hoy.getYear();
                var ahora_mes = fecha_hoy.getMonth() + 1;
                var ahora_dia = fecha_hoy.getDate();

                // realizamos el calculo
                var edad = (ahora_ano + 1900) - ano;
                if (ahora_mes < mes) {
                    edad--;
                }
                if ((mes == ahora_mes) && (ahora_dia < dia)) {
                    edad--;
                }
                if (edad > 1900) {
                    edad -= 1900;
                }

                // calculamos los meses
                var meses = 0;

                if (ahora_mes > mes && dia > ahora_dia)
                    meses = ahora_mes - mes - 1;
                else if (ahora_mes > mes)
                    meses = ahora_mes - mes
                if (ahora_mes < mes && dia < ahora_dia)
                    meses = 12 - (mes - ahora_mes);
                else if (ahora_mes < mes)
                    meses = 12 - (mes - ahora_mes + 1);
                if (ahora_mes == mes && dia > ahora_dia)
                    meses = 11;

                // calculamos los dias
                // var dias = 0;
                // if (ahora_dia > dia)
                //     dias = ahora_dia - dia;
                // if (ahora_dia < dia) {
                //     ultimoDiaMes = new Date(ahora_ano, ahora_mes - 1, 0);
                //     dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
                // }

                return edad + " años, " + meses + " meses"//  + dias + " días";
            }else{
                return ""
            }
        },
        dataReturn(){
            if (this.children) {
                let data = {
                    'children_id': this.children.children ? this.children.children[0].id : 0,
                    'primer_nombre':this.children.primer_nombre,
                    'fecha_evaluacion':this.children.fecha_evaluacion,
                    'fecha_nacimiento':this.children.fecha_nacimiento,
                    notaria: this.children.notaria ? this.children.notaria : null,
                    registraduria: this.children.registraduria ? this.children.registraduria : null,
                    serial: this.children.serial ? this.children.serial : null,
                    nuip: this.children.nuip ? this.children.nuip : null,
                    defensor: this.children.defensor ? this.children.defensor : null,
                    // 'entrevistados':this.entrevistados
                }
                this.$emit('identityData',data)
                return 0
            }
        }
    }
}
</script>

