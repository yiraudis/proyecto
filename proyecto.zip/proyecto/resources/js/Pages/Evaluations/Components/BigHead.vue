<template>
    <div class="col-md-12">
        <div class="card border-success mb-3 pull-right card-ev-cabezote">
            <div class="card-header">
                <h6>Versión:08</h6>
                <h6>Código: HCM-PH-F-28</h6>
            </div>
            <div class="card-body text-success">
                <h5 class="card-title">{{ name_evaluacion }}</h5>
                <!-- <p class="card-text">Quick sample text to create the card title and make up the body of the card's content.</p> -->
            </div>
        </div>
    </div>
</template>
<script>
export default {
    props: {
        name_evaluacion: {
            type: String,
            required: true
        }
    }
};
</script>
