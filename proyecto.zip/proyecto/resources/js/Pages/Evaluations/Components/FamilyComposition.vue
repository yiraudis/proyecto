<template>
    <div class="row justify-content-center" >
        <div class="col-md-6">
           <button id="new-family" class="btn btn-outline-success btn-entre pull-right mr-3" type="button" aria-pressed="true" @click.prevent="openModal('#addFamily')"><i class="bnt-ico fas fa-user-plus"></i>Agregar</button>
           <v-select :options="family" label="user" @input="addFamilyInExists">
               <template slot="option" slot-scope="{user}">
                   <div>
                       {{user && user.primer_nombre}}
                   </div>
               </template>
               <template slot="selected-option" slot-scope="{user}">
                   <div>
                       {{user && user.primer_nombre}}
                   </div>
               </template>
           </v-select>
        </div>             
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">Nombres</th>
                    <th scope="col">Documento</th>
                    <th scope="col">Parentesco</th>
                    <th scope="col">Teléfono</th>
                    <th scope="col">Dirección</th>
                    <th scope="col">Ciudad</th>
                    <th scope="col">Ver más</th>
                </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in familyExists" :key="index">
                        <td>{{item.user.primer_nombre}}</td>
                        <td>000000</td>
                        <td>dddd</td>
                        <td>dddd</td>
                        <td>dddd</td>
                        <td>dddd</td>
                        <td>ver</td>
                    </tr>
                </tbody>
            </table>           
        </div>
        <AddFamily @addFamily="addFamily"/>
    </div>
</template>

<script>
import { mapState } from 'vuex'
import { logMichin } from '../../../utils/functions'
import  AddFamily from '../../Children/Components/AddFamily'
export default {
    components:{
        AddFamily
    },
    data() {
        return {
            familyExists:[]
        }
    },
    methods: {
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        },
        addFamily(family){

            /// Enviar a guardar el familiar
            logMichin(family)
        },
        addFamilyInExists(family){
            if (family) {
                let validate = this.familyExists.filter(item => item.id == family.id)
                if (validate.length == 0) {
                    this.familyExists.push(family)
                    return
                }
                logMichin("El familiar ya fue añadido.")

            }
        }
    },
    computed: {
        ...mapState(["family"])
    },
}
</script>