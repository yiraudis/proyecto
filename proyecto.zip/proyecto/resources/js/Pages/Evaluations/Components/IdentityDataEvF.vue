<template>
    <div class="card">
        <div class="card-header" v-html="title">
          
        </div>
        <div class="card-body">

            <div class="row" v-if="showNameDate">
                <div class="form-group  col-md-5">
                  <label for="nna-name">Nombre del NNA</label>
                  <input disabled class="form-control" id="nna-name" v-model="children.primer_nombre" type="text" name="nna-name">
                </div>
                <div class="form-group  col-md-3" v-if="children.children">
                  <label for="ha_hsf">N° HA/HSF</label>
                    <input disabled  type="number" :value="children.children[0].id" id="ha_hsf" name="ha_hsf" class="form-control" placeholder="Número historia de atención">
                </div>
                <div class="form-group  col-md-2" v-if="children.children">
                 <label for="date-entry">Fecha de ingreso NNA</label>
                    <datetime disabled  input-class="form-control" v-model="children.children[0].fecha_ingreso" input-id="date-entry" placeholder="Fecha de Ingreso" disabled ></datetime>
                </div>
                <div class="form-group  col-md-2">
                 <label for="date-evaluation">Fecha de evaluación</label>
                    <datetime input-class="form-control" v-model="children.fecha_evaluacion" input-id="date-evaluation" placeholder="Fecha de evaluación"></datetime>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6  titulo-entrevistados">
                    <h4>Personas entrevistadas</h4>
                    <hr>
                </div>
                <div class="form-group col-md-4 ">
                    <!-- <label for="nombre_id">Buscar familiar</label> -->
                    <v-select v-model.trim="familiar" @input="changeFamiliar" :filterable="false" @search="search" :options="usuarios" label="id" placeholder="Buscar familiar">
                        <template slot="no-options">
                            <span>No existe el NNA</span>
                        </template>
                        <template slot="option" slot-scope="option">
                            <p>{{ option.primer_nombre }}</p>
                        </template>
                        <template slot="selected-option" slot-scope="option">
                            <p>{{ option.primer_nombre }}</p>
                        </template>
                    </v-select>
                </div>
                <div class="col-md-2">
                   <button id="new-interviewed" @click.prevent="openModal('#addFamily')" class="btn btn-block btn-outline-success btn-entre pull-left" type="button" aria-pressed="true"><i class="bnt-ico fas fa-user-plus"></i>Agregar nuevo</button>
                </div>

                
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Documento</th>
                            <th scope="col">Parentesco</th>
                            <th scope="col">Teléfono</th>
                            <th scope="col">Dirección</th>
                            <th scope="col">Ciudad</th>
                            <th scope="col">Ver más</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(entrevistado, index) in entrevistados" :key="index">
                                <td >
                                      <span >{{ entrevistado.name }}</span>  
                                </td>

                                <td>
                                    <span >{{entrevistado.identification}}</span>
                                </td>
                                <td>
                                    <span v-if="entrevistado.relationship"> <span >{{ entrevistado.relationship.name }} {{ entrevistado.relationship.nombre }}</span> </span>
                                    <v-select v-else v-model="entrevistado.relationship" :options="familyRelationships" label="nombre" placeholder="Parentesco" inputId="relationship">
                                        <template slot="no-options">
                                            <span>No existe la opción</span>
                                        </template>
                                    </v-select>
                                </td>
                                <td>
                                    <span>{{ entrevistado.phone }}</span>
                                </td>
                                <td>
                                    <span >{{ entrevistado.address }}</span>
                                </td>
                                <td>
                                    <span> <span v-if="entrevistado.city">{{ entrevistado.city.nombre }}</span> </span>
                                </td>
                                <td>
                                    <button @click.prevent="entrevistados.splice(index,1)" class="btn btn-danger" type="button" aria-pressed="true"><i class="fas fa-backspace"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <AddFamily @addFamily="addFamily"/>
        <div class="d-none">
            {{ dataReturn }}
        </div>
    </div>
</template>
<script>
import {searchChildren} from '../../../utils/services/evaluations'
import {logMichin} from '../../../utils/functions';
import AddFamily from '../../Children/Components/AddFamily'
import { mapActions, mapState } from 'vuex'

export default {
    components:{
        AddFamily
    },
    props:{
        children:{
            type:Object,
            required:true
        },
        title:{
            type:String,
            default: `<strong>Datos de Identidad</strong>
          <small>NNA y entrevistados</small>`
        },
        showNameDate:{
            type: Boolean,
            default: false
        }
    },
    data(){
        return {
            usuarios:[],
            entrevistados:[],
            familiar:null
        }
    },
    mounted(){
        this.getfamilyRelationships()
    },
    methods:{
        ...mapActions(['getfamilyRelationships']),
        async search(search, loading){
            if (!this.children.id) {
                this.$swal({
                    icon: 'warning',
                    text: `Debes elegir un NNA`
                })
                return false
            }
            if (search != "") {
                loading(true)
                let data = await searchChildren(search,2);
                 logMichin(data)
                if (data.data) {
                    this.usuarios = data.data.searchChildren
                }else{
                    this.$swal({
                        icon: 'error',
                        text: `Ocurrio un error`
                    })
                }
                loading(false)

            }
        },
        addFamily(family){
            console.log(family);
            this.entrevistados.push(family)
        },
        openModal(id, hide){
            if (!hide) {
                if (this.children.id) {
                    $(id).modal("show")
                }else{
                    this.$swal({
                        icon: 'warning',
                        text: `Debes elegir un NNA`
                    })
                }
            }else{
                $(id).modal("hide")
            }
        },
        changeFamiliar(){
            if (!this.children.id) {
                this.$swal({
                    icon: 'warning',
                    text: `Debes elegir un NNA`
                })
                return false
            }
            let validate = this.entrevistados.filter(item => item.id == this.familiar.id)
            if (validate.length > 0) {
                this.$swal({
                    icon: 'warning',
                    text: `Ya has incluido este familiar`
                })
            }else{
                if (this.children.id == this.familiar.id) {
                    this.$swal({
                        icon: 'warning',
                        text: `No puedes hacer esta accion`
                    })
                    return false;
                }
                // Buscar si es familiar del nna
                logMichin("Children: ",this.children)
                let familiares_children = this.children.children[0].family
                console.log(familiares_children);
                let mismo = familiares_children.filter(item => item.user.id == this.familiar.id)
                this.familiar.parentesco = null 
                if (mismo.length > 0) {
                    this.familiar.parentesco = mismo[0].parentesco
                }

                // rearmar la info del familiar
                let data = {
                    id:this.familiar.id,
                    name:this.familiar.primer_nombre,
                    identification: (this.familiar.user_document_types && this.familiar.user_document_types.length > 0) ? this.familiar.user_document_types[0].identificacion : null,
                    relationship: this.familiar.parentesco,
                    phone:this.familiar.telefono,
                    address:this.familiar.direccion,
                    city:this.familiar.ciudad
                }
                this.entrevistados.push(data)
                this.familiar = null
                console.log('aqui');
            }
        }
    },
    computed:{
        ...mapState(['familyRelationships']),
        dataReturn(){
            if (this.children) {
                let data = {
                    'children_id': this.children.children ? this.children.children[0].id : 0,
                    'primer_nombre':this.children.primer_nombre,
                    'fecha_evaluacion':this.children.fecha_evaluacion,
                    'entrevistados':this.entrevistados
                }
                this.$emit('dataEntrevistados',data)
                return 0
            }
        }

    }

}
</script>


