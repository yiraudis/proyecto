<template>
  <div class="card card-accent-success">
      <div class="card-header">
        <strong>Formulación de metas y acuerdo de intervención</strong>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group col-md-12">
                <label for="category-platin">Atenciones a realizar - Categoría</label>
                <v-select @input="changeCategory" v-model="FormulationAgreements.category" :options="categoryPlatin" label="name" placeholder="Seleccione una categoría" inputId="category-platin">
                  <template slot="no-options">
                      <span>No existe categoría</span>
                  </template>
                 </v-select>
            </div>
            <div class="form-group col-md-12">
              <textarea class="form-control textarea-g" v-model="description" id="description-category" name="description-category" rows="8" placeholder=""></textarea>
            </div>
            <div class=" form-group col-md-12">
              <button id="add-category" class="btn btn-outline-success pull-right" type="button" @click="addCatgeory" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Agregar /Actualizar</button>
            </div>
          </div>
          <div class="form-group col-md-6">
            <div id="category-data-platin" v-for="(category, index) in categories" :key="index" data-children=".item">
                <div class="item">
                    <a data-toggle="collapse" data-parent="#category-data-platin" href="#category-data-platin1" aria-expanded="true" aria-controls="category-data-platin1" class="">{{ category.name }}</a>
                    <div class="collapse show" id="category-data-platin1" role="tabpanel" >
                      <p class="mb-3 categorias-plantin-ev">{{ category.description }}</p>
                    </div>
                </div>
              </div>
          </div>
        </div>
      </div>
      <span class="d-none">{{ resultCategories }}</span>
      <!-- <div class="card-footer">
        <button id="save-evaluation" class="btn btn-outline-success active " type="button" aria-pressed="true">Guardar evaluacion</button>
      </div>             -->
    </div>
</template>
<script>
import {mapState} from "vuex"
export default {
    data(){
        return {
            FormulationAgreements:{
                category:null
            },
            categoryPlatin:[
                {id:1, name:"Familiar"},
                {id:2, name:"Interinstitucionales"},
                {id:3, name:"Individual"},
            ],
            categories:[],
            description:null
        }
    },
    methods:{
        changeCategory(){
            let category = this.categories.filter(item => item.id == this.FormulationAgreements.category.id)
            if (category.length > 0) {
                this.description = category[0].description
            }else{
                this.description = null
            }
        },
        addCatgeory(){
            if (this.FormulationAgreements.category == null) {
                this.$swal({
                    icon: 'warning',
                    // title: 'Genial',
                    text: `Debe seleccionar una categoría`
                })
            }else if(this.description == null){
                this.$swal({
                    icon: 'warning',
                    // title: 'Genial',
                    text: `La descripccion es requerida`
                })
            }else{
                let new_categories = this.categories.filter(item => item.id != this.FormulationAgreements.category.id)
                let data = {
                    id:this.FormulationAgreements.category.id,
                    name:this.FormulationAgreements.category.name,
                    description:this.description
                }
                new_categories.push(data);
                this.categories = new_categories
                this.description = null
                this.FormulationAgreements.category = null
            }
        }
    },
    computed:{
        ...mapState(["categoryMetas"]),
        resultCategories(){
            let data = this.categories
            this.$emit('resultCategories',this.categories)
            return 1
        }
    }
}
</script>

<style>

    #vs15__listbox{
        z-index: 9999 !important;
    }

</style>
