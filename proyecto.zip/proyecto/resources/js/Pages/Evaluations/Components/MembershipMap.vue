<template>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
          <div class="row map-relaciones-row">
            <div class="col-md-6 map-left">
               <div class="cont-map-left-top">
                  <h5 class="map-tit-sec">VIDA SOCIAL:<small>amigos,vecinos, grupos sociales</small></h5>
                 <div  class="sec1 sec1-left-top pull-right" href="#">
                  <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `vida_social1`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>

                    </h6>
                   <div  class="sec2 sec2-left-top pull-right" href="#">
                     <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `vida_social2`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>

                    </h6>
                      <div  class="sec3 sec3-left-top pull-right" href="#">
                        <h6>
                          <span v-for="(item, key) in membershipMap" :key="key">
                            <small class="map-sm-sec" v-if="item.ref ==  `vida_social3`">
                              {{item.text}}
                              <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                            </small>

                          </span>

                        </h6>
                      </div>
                    </div>
                 </div>
               </div>
            </div>
            <div class="col-md-6 map-right">
               <div class="cont-map-right-top">
                <h5 class="map-tit-sec">FAMILIA</h5>
                 <div class="sec1 sec1-right-top pull-left">
                  <h3>1</h3>
                    <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `familia1`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>

                    </h6>

                   <div class="sec2 sec2-right-top pull-left">
                      <h3>2</h3>
                      <h6>
                        <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `familia2`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>
                      </h6>
                      <div class="sec3 sec3-right-top pull-left">
                          <h6>
                            <span v-for="(item, key) in membershipMap" :key="key">
                              <small class="map-sm-sec" v-if="item.ref ==  `familia3`">
                                {{item.text}}
                                <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                              </small>
                            </span>
                          </h6>
                          <h3>3</h3>
                      </div>
                  </div>
                 </div>
               </div>
            </div>
            <div class="col-md-6 map-left">
              <div class="cont-map-left-sub">
                 <div class="sec1 sec1-left-sub pull-right">
                  <h6>
                    <span v-for="(item, key) in membershipMap" :key="key">
                      <small class="map-sm-sec" v-if="item.ref ==  `profesionales1`">
                        {{item.text}}
                        <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                      </small>
                    </span>
                  </h6>
                   <div class="sec2 sec2-left-sub pull-right">
                    <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `profesionales2`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>
                      </span>
                    </h6>
                      <div class="sec3 sec3-left-sub pull-right">
                        <h6>
                          <span v-for="(item, key) in membershipMap" :key="key">
                            <small class="map-sm-sec" v-if="item.ref ==  `profesionales3`">
                              {{item.text}}
                              <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                            </small>
                          </span>
                        </h6>
                    </div>
                    </div>
                 </div>
                 <h5 class="map-tit-sec">INSTITUCIONES Y PROFESIONALES:<small>salud,ICBF, justicia iglesia,etc.</small></h5>
              </div>
            </div>
           <div class="col-md-6 map-right">
             <div class="cont-map-right-sub">
                <div class="sec1 sec1-right-sub pull-left">
                  <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `ocupacion1`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>

                    </h6>
                   <div class="sec2 sec2-right-sub pull-left">
                      <h6>
                      <span v-for="(item, key) in membershipMap" :key="key">
                        <small class="map-sm-sec" v-if="item.ref ==  `ocupacion2`">
                          {{item.text}}
                          <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                        </small>

                      </span>

                    </h6>
                        <div class="sec3 sec3-right-sub pull-left">
                          <h6>
                            <span v-for="(item, key) in membershipMap" :key="key">
                              <small class="map-sm-sec" v-if="item.ref ==  `ocupacion3`">
                                {{item.text}}
                                <span class="delete-component text-danger" aria-hidden="true" @click="deleteCompoenet(key)">&times;</span>
                              </small>

                            </span>

                          </h6>
                        </div>
                    </div>
                 </div>
               <h5 class="map-tit-sec">OCUPACIÓN:<small>estudio,trabajo</small></h5>
              </div>
           </div>
          </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group">
              <label>Convenciones:</label>
            </div>
            <div class="row">
                <div class="col-md-6">
                <div class="map-convenciones">
                  <span class="map-con-nivel1"></span><small>Nivel 1</small>
                </div>
                <div class="map-convenciones">
                  <span class="map-con-nivel2"></span><small>Nivel 2</small>
                </div>
                <div class="map-convenciones">
                  <span class="map-con-nivel3"></span><small>Nivel 3</small>
                </div>
            </div>
            <div class="col-md-6">
              <div class="map-convenciones">
                  <span class="map-con-sec1"></span><small>
                  VIDA SOCIAL</small>
                </div>
                <div class="map-convenciones">
                  <span class="map-con-sec2"></span><small>FAMILIA</small>
                </div>
                <div class="map-convenciones">
                  <span class="map-con-sec3"></span><small>INSTITUCIONES Y PROFESIONALES</small>
                </div>
                <div class="map-convenciones">
                  <span class="map-con-sec4"></span><small>OCUPACIÓN</small>
                </div>
            </div>
        </div>
         <div class="col-md-12">
            <div class="row justify-content-center">
                <button type="button" class="btn btn-primary text-center" @click="$modal.show(name)">
                    Agregar pertenencia
                </button>
            </div>
        </div>
          <div class="form-group">
            <label for="map-membership-observations">Observaciones</label>
            <textarea v-model.trim="observaciones"  class="form-control textarea-g" id="map-membership-observations" name="map-membership-observations" rows="4" placeholder=""></textarea>
          </div>
          <span class="d-none">{{observacionesMap}}</span>
        </div>
        <div class="modal fade" id="mapa-pertenencia-add" tabindex="-1" role="dialog" aria-labelledby="mapa-pertenencia-addLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title tit-modal" id="mapa-pertenencia-addLabel">Agregar item</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body row">
                 <div class="form-group col-md-6">
                      <div class="map-convenciones">
                        <v-select :options='levels' label="name" placeholder="Nivel" v-model="level"></v-select>
                      </div>

                  </div>
                 <div class="form-group col-md-6">


                  <div class="map-convenciones">
                          <v-select :options='components' label="name" placeholder="Componente" v-model="component"></v-select>
                      </div>

                 </div>
                  <div class="form-group col-md-12">
                      <label for="item-map">Nombre item</label>
                      <input class="form-control" type="text" name="item-map" v-model.trim="text" placeholder="Algo">
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" @click="add">Agregar</button>
              </div>
            </div>
          </div>
        </div>
        <!-- Componente para agregar -->
        <AddComponent :name="name" @newComponent="add"/>

  </div>

</template>

<script>
import AddComponent from './AddComponent'
export default {
  components:{
    AddComponent
  },
  data(){
    return {
      data_save:[],
      observaciones:null,
      level: null,
      component: null,
      text:"",
      levels: [
          {"name": "Nivel 1", id: 1},
          {"name": "Nivel 2", id: 2},
          {"name": "Nivel 3", id: 3},
        ],
        components: [
          {"name": "VIDA SOCIAL", flag: "vida_social"},
          {"name": "FAMILIA", flag: "familia"},
          {"name": "INSTITUCIONES Y PROFESIONALES", flag: "profesionales"},
          {"name": "OCUPACIÓN", flag: "ocupacion"},
        ],
      name: `add_component${Math.random(10)}`

    }
  },
  methods:{
    add(data){
        this.data_save.push(data)
    },
    deleteCompoenet(key){
      this.data_save.splice(key, 1)
    }
  },
  computed:{
    membershipMap(){
      this.$emit("membershipMap", this.data_save)
      return this.data_save
    },
    observacionesMap(){
        this.$emit("observacionesMap",this.observaciones)
        return null
    }
  }
}
</script>
<style >
  .delete-component{
    cursor: pointer;
    font-size: 12px;
    font-weight: bold;
  }
</style>


