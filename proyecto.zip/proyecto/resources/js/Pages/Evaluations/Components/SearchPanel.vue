<template>
    <div class="row">
        <div class="form-group col-md-12">
          <label for="nombre_id">Nombre NNA / Identificación</label>
          <v-select v-model.trim="resultChildren" @input="changeChildren" :filterable="false" @search="search" :options="children" label="id" placeholder="Nombre ó Identificación del NNA">
            <template slot="no-options">
                <span>No existe el NNA</span>
            </template>
            <template slot="option" slot-scope="option">
                <p>{{ option.primer_nombre }}</p>
            </template>
             <template slot="selected-option" slot-scope="option">
                <p>{{ option.primer_nombre }}</p>
            </template>
           </v-select>
        </div>
      <!-- <div class="form-group col-md-4">
         <label for="sim">SIM</label>
         <input  type="number" id="sim" name="sim" class="form-control">
      </div> -->
      <!-- <div class=" form-group col-md-2">
        <label for="searcher"></label>
        <button id="searcher" class="btn btn-block btn-ghost-success active" type="button" aria-pressed="true"><i class="bnt-ico fas fa-search"></i>Buscar</button>
      </div> -->
    </div>
</template>
<script>
import {searchChildren} from '../../../utils/services/evaluations'
import {logMichin} from '../../../utils/functions';
export default {
    data(){
        return {
            resultChildren:null,
            children:[]
        }
    },
    methods:{
        async search(search, loading){
            if (search != "") {
                loading(true)
                let data = await searchChildren(search,1);
                 logMichin(data)
                if (data.data) {
                    this.children = data.data.searchChildren
                }else{
                    alert('ocurrio un fallo')
                }
                loading(false)

            }
        },
        changeChildren(){
            this.$emit("children",this.resultChildren)
        }

    }
}
</script>

<style>

    #vs15__listbox{
        z-index: 9999 !important;
    }

</style>
