<template>
    <div>
        <modal :name="name" :adaptive="true" :scrollable="true" height="auto" :clickToClose="false" classes="fadeIn">
            <div>
                <div>
                    <div >
                        <div class="modal-header" >
                            <h5 class="modal-title tit-modal" id="mapa-pertenencia-addLabel">Agregar item</h5>
                            <button type="button" slot="top-right" class="close" @click="$modal.hide(name)">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body row">
                            <div class="form-group col-md-6">
                                <div class="map-convenciones">
                                    <v-select :options='levels' label="name" placeholder="Nivel" v-model="level"></v-select>    
                                </div>
                                
                            </div>
                            <div class="form-group col-md-6">


                            <div class="map-convenciones">
                                    <v-select :options='components' label="name" placeholder="Componente" v-model="component"></v-select>    
                                </div>

                            </div>
                            <div class="form-group col-md-12">
                                <label for="item-map">Nombre item</label>
                                <input class="form-control" type="text" name="item-map" v-model.trim="text" placeholder="Algo">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="$modal.hide(name)">Cancelar</button>
                            <button type="button" class="btn btn-primary" @click="add">Agregar</button>
                        </div>
                    </div>
                </div>
            </div>
        </modal>
        
    </div>
</template>
<script>
export default {
    props:{
        name:{
            type: String,
            requred: true
        }
    },
    data(){
        return {
            level: null,
                component: null,
                text:"",
                levels: [
                    {"name": "Nivel 1", id: 1},
                    {"name": "Nivel 2", id: 2},
                    {"name": "Nivel 3", id: 3},
                ],
                components: [
                    {"name": "VIDA SOCIAL", flag: "vida_social"},
                    {"name": "FAMILIA", flag: "familia"},
                    {"name": "INSTITUCIONES Y PROFESIONALES", flag: "profesionales"},
                    {"name": "OCUPACIÓN", flag: "ocupacion"},
                ]
        }
    },
    methods:{
        add(){
            if (this.level && this.component && this.text != "") {
                this.$emit("newComponent",{level: this.level, component:this.component, text:this.text, ref:  `${this.component.flag}${this.level.id}`})
                this.level = null,
                this.component = null
                this.text = ""
                this.$modal.hide(this.name)
            }
        },
    }
}
</script>