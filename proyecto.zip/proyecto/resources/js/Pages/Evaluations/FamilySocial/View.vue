<template>
    <form class="fade-in" @submit.prevent="save">
        <div class="row">
            <BigHead name_evaluacion="Evaluación sociofamiliar" />
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Panel de búsqueda dd</strong>
                        <small>NNA</small>
                    </div>
                    <div class="card-body">
                        <SearchPanel @children="resultSearch" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- <div class="col-sm-12">
          asdfa
         <IdentityDataEvF/>
        </div> -->
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>1. Motivo de ingreso</strong>
                        <small>
                            (Entidades que participaron en la detección, manejo
                            del problema y antecedentes institucionales)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.reason"
                                    class="form-control textarea-g"
                                    id="reason-admission"
                                    name="reason-admission"
                                    rows="3"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <!-- <div class="card"> -->
                <!-- <div class="card-header">
              <strong>2. Composición familiar</strong>
              <small>(personas que viven con el o los niños, niñas o adolescentes)</small>
            </div> -->
                <!-- <div class="card-body"> -->
                <IdentityDataEvF
                    :children="
                        data_save.children_family
                            ? data_save.children_family
                            : []
                    "
                    :title="`<strong>Composición familiar</strong>`"
                    :showNameDate:="false"
                    @dataEntrevistados="getFamilies"
                />
                <!-- </div>             -->
                <!-- </div> -->
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>3. Genograma </strong>
                        <small
                            >(Subsistema que convive/tipo y número de
                            uniones)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.genogram"
                                    class="form-control textarea-g"
                                    id="consulting-system"
                                    name="consulting-system"
                                    rows="6"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>4. Historia de vida familiar</strong>
                        <small>(eventos significativos)</small>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.history_family"
                                    class="form-control textarea-g"
                                    id="family-life-story"
                                    name="family-life-story"
                                    rows="5"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>5. Dinámica Familiar Actual</strong>
                        <small
                            >(ciclo vital, roles, manejo de autoridad,
                            distribución de tareas, resolución de
                            conflictos)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <FamilyDynamics />
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.family_dinamic"
                                    class="form-control textarea-g"
                                    id="family-dynamics"
                                    name="family-dynamics"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>6. Aspectos Socio económico </strong>
                        <small
                            >(Historia Laboral, Ingresos y presupuesto
                            familiar)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.socioeconomic_aspects"
                                    class="form-control textarea-g"
                                    id="socioeconomic-aspect"
                                    name="socioeconomic-aspect"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>7. Redes de Apoyo Familiar</strong>
                        <small
                            >(Nombre de personas significativas, Apoyo: ¿En qué
                            circunstancias?)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.support_family"
                                    class="form-control textarea-g"
                                    id="support-networks-f"
                                    name="support-networks-f"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>8. Redes de Apoyo Social</strong>
                        <small
                            >(vivienda, salud, educación, trabajo) ¿Recibe
                            Subsidio?)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.support_social"
                                    class="form-control textarea-g"
                                    id="support-networks-s"
                                    name="support-networks-s"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>9. Mapa de pertenecía actual</strong>
                    </div>
                    <div class="card-body">
                        <div class="row ev-socifamiliar-map">
                            <MembershipMap
                                @membershipMap="getMembershipMapCurrent"
                                @observacionesMap="observacionesMap"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>10. Mapa de pertenecía potencial</strong>
                    </div>
                    <div class="card-body">
                        <div class="row ">
                            <MembershipMap
                                @membershipMap="getMembershipMapPotential"
                                @observacionesMap="observacionesMap2"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >11. Proyecto y/o aspiraciones de la familia para el
                            próximo año</strong
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.project"
                                    class="form-control textarea-g"
                                    id="family-project"
                                    name="family-project"
                                    rows="2"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >12. Que esperan del proceso de protección y cual su
                            compromiso en el mismo</strong
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="data_save.observation"
                                    class="form-control textarea-g"
                                    id="protection-commitment"
                                    name="protection-commitment"
                                    rows="2"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{ read }}
        <div class="row">
            <div class="col-sm-12">
                <FormulationAgreements @resultCategories="resultCategories" />
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-4">
                <button type="submit" class="btn btn-primary btn-block">
                    Guardar
                </button>
            </div>
        </div>
    </form>
</template>
<script>
import SearchPanel from "../Components/SearchPanel";
import IdentityDataEvF from "../Components/IdentityDataEvF";
import FormulationAgreements from "../Components/FormulationAgreements";
import BigHead from "../Components/BigHead";
import FamilyDynamics from "./Components/FamilyDynamics";
import MembershipMap from "../Components/MembershipMap";
import FamilyComposition from "../Components/FamilyComposition";
import { logMichin } from "../../../utils/functions";
import { evaSocioFamiliarIngreso } from "../../../utils/services/evaluations";

export default {
    components: {
        SearchPanel,
        IdentityDataEvF,
        FormulationAgreements,
        BigHead,
        FamilyComposition,
        FamilyDynamics,
        MembershipMap
    },
    data() {
        return {
            data_save: {
                children: {},
                families: [],
                membership_map_current: [],
                membership_map_potential: [],
                children_family: [],
                name_evaluacion: "Evaluación sociofamiliar"
            }
        };
    },
    methods: {
        observacionesMap(ob) {
            this.data_save.map_current = ob;
        },

        observacionesMap2(ob) {
            this.data_save.map_potential = ob;
        },
        resultSearch(nna) {
            if (nna) {
                logMichin(nna);
                this.data_save.children = nna.children[0];
                this.data_save.children_family = nna;
            } else {
                this.data_save.children = {};
            }
        },
        getFamilies(family) {
            logMichin("Family: ", family);
            let result = this.data_save.families.filter(
                item => item.id == family.id
            );
            if (result.length > 0) {
                return;
            }
            this.data_save.families.push(family);
        },
        getMembershipMapCurrent(data) {
            // let result = this.data_save.families.filter(item => item.id == family.id)
            // if (result.length > 0) {
            //   return
            // }
            this.data_save.membership_map_current = data;
        },
        getMembershipMapPotential(data) {
            this.data_save.membership_map_potential = data;
        },
        resultCategories(categories) {
            this.data_save.categories = categories;
        },
        async save() {
            if (!this.data_save.children.id) {
                this.$swal({
                    icon: "warning",
                    html: "Debe seleccionar un nna."
                });

                return;
            }
            if (
                this.data_save.membership_map_potential.length == 0 ||
                typeof this.data_save.membership_map_potential[0] == "undefined"
            ) {
                this.$swal({
                    icon: "warning",
                    html:
                        'Debe agregar información al "Mapa de pertenecía actual"'
                });

                return;
            }

            if (
                this.data_save.membership_map_current.length == 0 ||
                typeof this.data_save.membership_map_current[0] == "undefined"
            ) {
                this.$swal({
                    icon: "warning",
                    html:
                        'Debe agregar información al "Mapa de pertenecía potencial"'
                });
                return;
            }
            let loader = this.$loading.show();
            try {
                let data = {
                    nna_id: this.data_save.children.id,
                    motivo_ingreso: this.data_save.reason,
                    genograma: this.data_save.genogram,
                    history_family: this.data_save.history_family,
                    membership_map_current: this.data_save
                        .membership_map_current,
                    membership_map_potential: this.data_save
                        .membership_map_potential,
                    families: this.data_save.families[0]
                        ? this.data_save.families[0]
                        : null,
                    categories: this.data_save.categories,
                    family_dinamic: this.data_save.family_dinamic,
                    socioeconomic_aspects: this.data_save.socioeconomic_aspects,
                    support_family: this.data_save.support_family,
                    support_social: this.data_save.support_social,
                    project: this.data_save.project,
                    observation: this.data_save.observation,
                    map_current: this.data_save.map_current,
                    map_potential: this.data_save.map_potential
                };
                let resp = await evaSocioFamiliarIngreso(data);

                if (resp.status_transaction) {
                    this.$swal({
                        icon: "success",
                        html: resp.message
                    });

                    this.resetData();
                    document.location.reload();
                }

                logMichin("save", resp);
            } catch (error) {
                let html = "";
                for (const key in error) {
                    error[key].map(err => {
                        html += `${err} </br>`;
                    });
                }
                this.$swal({
                    icon: "warning",
                    html
                });
            }

            loader.hide();
        },
        resetData() {
            this.data_save = {
                children: {},
                families: [],
                membership_map_current: [],
                membership_map_potential: [],
                children_family: []
            };
        }
    },
    computed: {
        read() {
            // logMichin("Read", this.data_save)
            return null;
        }
    }
};
</script>
<style>
.sec3-left-top {
    position: relative;
    top: 38%;
}
.sec3-right-top {
    position: absolute;
    top: 37%;
}
</style>
