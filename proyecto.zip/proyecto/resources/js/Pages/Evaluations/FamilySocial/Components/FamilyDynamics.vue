<template>
  <div class="form-group col-md-12">
    <div class="btn-toolbar dinamica-familiar" role="toolbar" aria-label="Toolbar with button groups">
      <span>Ciclo Vital:</span>
      <div class="btn-group mr-2" role="group" aria-label="First group">
        <button type="button" class="btn btn-primary">Primera infancia </button>
        <button type="button" class="btn btn-primary">Adulto mayor </button>
        <button type="button" class="btn btn-primary">Adolescencia</button>
      </div>
      <span>Mejo de autoridad:</span>
      <div class="btn-group mr-2" role="group" aria-label="First group">
        <button type="button" class="btn btn-warning">Flexible </button>
        <button type="button" class="btn btn-warning">Permisivo </button>
        <button type="button" class="btn btn-warning">Inconstante</button>
        <button type="button" class="btn btn-warning">Rígida</button>
      </div>                   
    </div>
  </div>
</template>


