<template>
    <form @submit.prevent="saveEvaluation" class="fade-in">
        <div class="row">
            <BigHead name_evaluacion="Evaluación psicológica familiar" />
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Panel de búsqueda</strong>
                        <small>NNA</small>
                    </div>
                    <div class="card-body">
                        <SearchPanel @children="resultChildren" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <IdentityDataEvF
                    :children="data_save.children"
                    @dataEntrevistados="dataEntrevistados"
                />
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>1. Percepción del motivo de ingreso</strong>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.motivo_ingreso"
                                    id="reason-admission"
                                    name="reason-admission"
                                    rows="3"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >2. Características del sistema consultante</strong
                        >
                        <small>
                            (tipología, ciclo vital, estructura y organización,
                            dinámica familiar, comunicación, tipo de relaciones,
                            estilos de crianza, redes de apoyo)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.caracteristicas"
                                    id="consulting-system"
                                    name="consulting-system"
                                    rows="6"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>3. Evento significativos y antecedentes</strong>
                        <small
                            >(consumo de sustancias psicoactivas, abuso sexual,
                            abandono, violencia interfamiliar, duelo etc.
                            Indicadores de ajuste, crisis y
                            adaptabilidad)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="
                                        data_save.evento_significativo
                                    "
                                    id="significant-event"
                                    name="significant-event"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>4. Sistema de creencias</strong>
                        <small
                            >(acuerdos implícitos, pensamientos dominantes,
                            reglas familiares que subyace pautas de
                            comportamiento disfuncional)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.sistema_creencia"
                                    id="belief-system"
                                    name="belief-system"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >5. Factores de generatividad y vulnerabilidad
                        </strong>
                        <small>(afectivo y relacional)</small>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <h6 class="subt-ev-pf">GENERATIVIDAD</h6>
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.generatividad"
                                    id="generativity-factors"
                                    name="generativity-factors"
                                    rows="6"
                                    placeholder=""
                                ></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <h6 class="subt-ev-pf">VULNERABILIDAD</h6>
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.vulnerabilidad"
                                    id="vulnerability-factors"
                                    name="vulnerability-factors"
                                    rows="6"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>6. Lectura profesional</strong>
                        <small>(conclusiones e hipótesis)</small>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    class="form-control textarea-g"
                                    v-model.trim="data_save.lectura"
                                    id="vital-prospective"
                                    name="vital-prospective"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <FormulationAgreements @resultCategories="dataCategories" />
            </div>
        </div>
        <div class="row justify-content-center">
            <h5 class="text-center">
                <button
                    id="save-evaluation"
                    class="btn btn-outline-success active"
                    type="submit"
                    aria-pressed="true"
                >
                    Guardar evaluacion
                </button>
            </h5>
        </div>
    </form>
</template>
<script>
import SearchPanel from "../Components/SearchPanel";
import IdentityDataEvF from "../Components/IdentityDataEvF";
import FormulationAgreements from "../Components/FormulationAgreements";
import BigHead from "../Components/BigHead";
import { psicoIngresoFamiliar } from "../../../utils/services/evaluations";

export default {
    components: {
        SearchPanel,
        IdentityDataEvF,
        FormulationAgreements,
        BigHead
    },
    data() {
        return {
            data_save: {
                children: {},
                dataCategories: [],
                name_evaluacion2: "Evaluación psicológica familiar"
            }
        };
    },
    methods: {
        resultChildren(data) {
            console.log(data);
            this.data_save.children = data;
        },
        dataCategories(data) {
            this.data_save.dataCategories = data;
        },
        dataEntrevistados(data) {
            this.data_save.entrevistados = data;
        },
        async saveEvaluation() {
            if (
                !this.data_save.children ||
                !this.data_save.children.primer_nombre
            ) {
                this.$swal({
                    icon: "warning",
                    text: `Debe elegir un NNA`
                });
            } else if (
                !this.data_save.entrevistados ||
                this.data_save.entrevistados.entrevistados.lenght == 0
            ) {
                this.$swal({
                    icon: "warning",
                    text: `Debe incluir almenos un entrevistado`
                });
            } else if (
                !this.data_save.dataCategories ||
                this.data_save.dataCategories.length == 0
            ) {
                this.$swal({
                    icon: "warning",
                    text: `Debe incluir almenos un acuerdo de intervención`
                });
            } else {
                let validate = 0;
                this.data_save.entrevistados.entrevistados.forEach(item => {
                    if (!item.relationship) {
                        validate++;
                    }
                });

                if (validate > 0) {
                    this.$swal({
                        icon: "warning",
                        text: `Todos los familiares agregados deben tener un parentesco`
                    });
                    return false;
                }

                //guardar aqui
                console.log(this.data_save);
                let loader = this.$loading.show();
                try {
                    let resp = await psicoIngresoFamiliar(this.data_save);
                    console.log(resp);

                    if (resp.data) {
                        if (resp.data.psicoIngresoFamiliar.status_transaction) {
                            this.$swal({
                                icon: "success",
                                text: `${resp.data.psicoIngresoFamiliar.message}`
                            });
                            location.reload();
                        } else {
                            this.$swal({
                                icon: "error",
                                text: `${resp.data.psicoIngresoFamiliar.message}`
                            });
                        }
                    } else {
                        this.$swal({
                            icon: "error",
                            text: `No se pudo guardar la evaluación`
                        });
                    }
                    loader.hide();
                } catch (error) {
                    console.log(error);
                    loader.hide();
                    this.$swal({
                        icon: "error",
                        text: `Estamos presentando fallos internos, recarga la pagina e intenta nuevamente`
                    });
                    return true;
                }
            }
        }
    }
};
</script>
