<template>
    <form @submit.prevent="saveEvaluation" class="fade-in">
        <div class="row">
            <BigHead :name_evaluacion="name_evaluacion" />
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Panel de búsqueda</strong>
                        <small>NNA</small>
                    </div>
                    <div class="card-body">
                        <SearchPanel @children="resultChildren" />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Datos de Identidad</strong>
                        <small>NNA</small>
                    </div>
                    <div class="card-body">
                        <IdentityData
                            :children="children"
                            @dataChildren="dataChildren"
                        />
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>2. Percepción del motivo de ingreso</strong>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.reason_admission"
                                    class="form-control textarea-g"
                                    id="reason-admission"
                                    name="reason-admission"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>3. Antecedentes</strong>
                        <small
                            >(Psiquiatría, psicología, salud, discapacidad,
                            legales o sociales)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.antecedent"
                                    class="form-control textarea-g"
                                    id="record-social"
                                    name="record-social"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>4. Examen Mental</strong>
                        <small
                            >(orientación, atención, memoria, lenguaje,
                            pensamiento, sueños)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.mental_exam"
                                    class="form-control textarea-g"
                                    id="mental-exam"
                                    name="mental-exam"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>5. Afectividad</strong>
                        <small
                            >(emociones, sentimientos, autocontrol, autoesquema,
                            sexualidad)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.afectivity"
                                    class="form-control textarea-g"
                                    id="affectivity"
                                    name="affectivity"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >6. Percepción del niño, niña o adolescente sobre su
                            sistema familiar</strong
                        >
                        <small
                            >(tipología, ciclo vital, estructura y organización,
                            dinámica familiar, comunicación, tipo de relación,
                            estilo de crianza, redes de apoyo)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.perception"
                                    class="form-control textarea-g"
                                    id="family-perception"
                                    name="family-perception"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>7. Prospectiva Vital</strong>
                        <small
                            >(Expectativas personales, familiares y del proceso
                            de restablecimiento de derechos)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.prospective"
                                    class="form-control textarea-g"
                                    id="vital-prospective"
                                    name="vital-prospective"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>8. Adaptación al medio institucional</strong>
                        <small
                            >(percepción con el niño con relación a su
                            adaptación normas, rutinas y figuras de autoridad,
                            relación con pares y adultos, gusto e
                            inconformidades)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.adaptation"
                                    class="form-control textarea-g"
                                    id="adaptation-environment"
                                    name="adaptation-environment"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong
                            >9. Resultado pruebas proyectivas Machover-
                            Familia</strong
                        >
                        <small
                            >(autoestima, expresión emocional, ansiedad y
                            socialización)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="psi_individual.result"
                                    class="form-control textarea-g"
                                    id="results-machover"
                                    name="results-machover"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>10. Lectura profesional</strong>
                        <small
                            >(consulta e hipótesis factores de generatividad y
                            vulnerabilidad)</small
                        >
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea
                                    v-model="
                                        psi_individual.professional_reading
                                    "
                                    class="form-control textarea-g"
                                    id="professional-reading"
                                    name="professional-reading"
                                    rows="4"
                                    placeholder=""
                                ></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <FormulationAgreements @resultCategories="dataCategories" />
            </div>
        </div>
        <div class="row justify-content-center">
            <h5 class="text-center">
                <button
                    id="save-evaluation"
                    class="btn btn-outline-success active"
                    type="submit"
                    aria-pressed="true"
                >
                    Guardar evaluacion
                </button>
            </h5>
        </div>
    </form>
</template>
<script>
import SearchPanel from "../Components/SearchPanel";
import IdentityData from "./Components/IdentityData";
import FormulationAgreements from "../Components/FormulationAgreements";
import BigHead from "../Components/BigHead";
import { psicoIndividual } from "../../../utils/services/evaluations";
import { logMichin } from "../../../utils/functions";
export default {
    components: {
        SearchPanel,
        IdentityData,
        FormulationAgreements,
        BigHead
    },
    data() {
        return {
            children: {},
            psi_individual: {},
            name_evaluacion: "Evaluación psicológica individual"
        };
    },
    methods: {
        resultChildren(data) {
            this.children = data;
        },
        dataChildren(data) {
            this.psi_individual.dataChildren = data;
        },
        dataCategories(data) {
            this.psi_individual.dataCategories = data;
        },
        async saveEvaluation() {
            if (
                !this.psi_individual.dataChildren ||
                !this.psi_individual.dataChildren.primer_nombre
            ) {
                this.$swal({
                    icon: "warning",
                    text: `Debe elegir un NNA`
                });
            } else if (
                !this.psi_individual.dataCategories ||
                this.psi_individual.dataCategories.length == 0
            ) {
                this.$swal({
                    icon: "warning",
                    text: `Debe incluir almenos un acuerdo de intervención`
                });
            } else {
                console.log(this.psi_individual);
                let loader = this.$loading.show();
                try {
                    let resp = await psicoIndividual(this.psi_individual);
                    loader.hide();
                    if (resp.data) {
                        if (resp.data.psicoIndividual.status_transaction) {
                            this.$swal({
                                icon: "success",
                                text: `${resp.data.psicoIndividual.message}`
                            });

                            location.reload();
                        } else {
                            this.$swal({
                                icon: "error",
                                text: `${resp.data.psicoIndividual.message}`
                            });
                        }
                        console.log(resp.data);
                    } else {
                        this.$swal({
                            icon: "error",
                            text: `No se pudo guardar la evaluación`
                        });
                    }
                } catch (error) {
                    loader.hide();
                    this.$swal({
                        icon: "error",
                        text: `Estamos presentando fallos internos, recarga la pagina e intenta nuevamente`
                    });
                    return true;
                }
            }
        }
    }
};
</script>
