<template>
    <div class="row">
        <!-- {{ children }} -->
        <div class="form-group  col-md-6">
          <label for="nna-name">Nombre del NNA</label>
          <input class="form-control" id="nna-name" v-model="children.primer_nombre" type="text" name="nna-name">
        </div>
        <div class="form-group  col-md-4">
         <label for="date-birth">Fecha de nacimiento</label>
            <datetime v-model="children.fecha_nacimiento" :auto="true" input-class="form-control" input-id="date-birth" placeholder="Fecha de nacimiento"></datetime>
        </div>
        <div class="form-group  col-md-2">
          <label for="years">Edad </label>
          <input class="form-control" id="years" type="text" name="years" :value="ageCalculate" disabled>
        </div>
        <div class="form-group  col-md-4" v-if="children.children">
          <label for="ha_hsf">N° HA/HSF</label>
            <input :value="children.children[0].id"  type="number" id="ha_hsf" disabled name="ha_hsf" class="form-control" placeholder="Número historia de atención">
        </div>
        <div class="form-group  col-md-4" v-if="children.children">
            <label for="scholarship">Escolaridad</label>
            <v-select v-model="children.children[0].scholarship" :options="scholarships" label="nombre" placeholder="Escolaridad" inputId="schooling">
                <template slot="no-options">
                    <span>No existe escolaridad</span>
                </template>
            </v-select>
        </div>
        <div class="form-group col-md-4">
            <label for="ethnicGroup">Grupo étnico</label>
            <v-select v-model="children.ethnic_group" :options="ethnicGroups" label="name" placeholder="Grupo étnico" inputId="ethnicGroup">
                <template slot="no-options">
                    <span>No existe el grupo étnico</span>
                </template>
            </v-select>
        </div>
        <div class="form-group  col-md-4" v-if="children.children">
         <label for="date-entry">Fecha de ingreso NNA</label>
            <datetime v-model="children.children[0].fecha_ingreso"  input-class="form-control" input-id="date-entry" placeholder="Fecha de Ingreso" disabled ></datetime>
        </div>
        <div class="form-group  col-md-4">
         <label for="date-evaluation">Fecha de evaluación</label>
            <datetime v-model="children.fecha_evaluacion" input-class="form-control" input-id="date-evaluation" placeholder="Fecha de evaluación"></datetime>
        </div>

        <div class="d-none">
            {{ dataIdentity }}
        </div>
    </div>

</template>
<script>
import {mapState} from "vuex"
export default {
    props:{
        children:{
            type:Object,
            required:true
        },
    },
    data(){
        return {
            IdentityData: {},
            ethnicGroup:[{name:"Ejemplo1", id:1}, {name:"Ejemplo2", id:2}],
            schooling:[{name:"Ejemplo1", id:1}, {name:"Ejemplo2", id:2}]
        }
    },
    computed:{
        ...mapState(["scholarships","ethnicGroups"]),
        dataIdentity(){
            if (this.children) {
                let data = {
                    'children_id': this.children.children ? this.children.children[0].id : 0,
                    'primer_nombre':this.children.primer_nombre,
                    'fecha_nacimiento':this.children.fecha_nacimiento,
                    'escolaridad_id': (this.children.children && this.children.children[0].scholarship) ? this.children.children[0].scholarship.id : null,
                    'grupo_etnico_id':this.children.ethnic_group ? this.children.ethnic_group.id : null,
                    'fecha_evaluacion':this.children.fecha_evaluacion,
                }
                this.$emit('dataChildren',data)

                return 0
            }

            return ""
        },
        ageCalculate() {
            if (this.children.fecha_nacimiento) {
                let fecha = this.children.fecha_nacimiento

                if (typeof fecha != "string" && fecha && esNumero(fecha.getTime())) {
                    fecha = formatDate(fecha, "yyyy-MM-dd");
                }

                var values = fecha.split("-");
                var dia = values[2];
                var mes = values[1];
                var ano = values[0];

                // cogemos los valores actuales
                var fecha_hoy = new Date();
                var ahora_ano = fecha_hoy.getYear();
                var ahora_mes = fecha_hoy.getMonth() + 1;
                var ahora_dia = fecha_hoy.getDate();

                // realizamos el calculo
                var edad = (ahora_ano + 1900) - ano;
                if (ahora_mes < mes) {
                    edad--;
                }
                if ((mes == ahora_mes) && (ahora_dia < dia)) {
                    edad--;
                }
                if (edad > 1900) {
                    edad -= 1900;
                }

                // calculamos los meses
                var meses = 0;

                if (ahora_mes > mes && dia > ahora_dia)
                    meses = ahora_mes - mes - 1;
                else if (ahora_mes > mes)
                    meses = ahora_mes - mes
                if (ahora_mes < mes && dia < ahora_dia)
                    meses = 12 - (mes - ahora_mes);
                else if (ahora_mes < mes)
                    meses = 12 - (mes - ahora_mes + 1);
                if (ahora_mes == mes && dia > ahora_dia)
                    meses = 11;

                // calculamos los dias
                var dias = 0;
                if (ahora_dia > dia)
                    dias = ahora_dia - dia;
                if (ahora_dia < dia) {
                    let ultimoDiaMes = new Date(ahora_ano, ahora_mes - 1, 0);
                    dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
                }

                return edad + " años, " + meses + " meses"//  + dias + " días";
            }else{
                return ""
            }
        }
    }
}
</script>

