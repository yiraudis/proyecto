<template>
    <div class="row justify-content-center row-login" style="background-image:url(images/login.jpg);">
        <div class="col-md-8">
            <div class="card-group">
                <div class="card p-4 login-campos">
                    <form class="card-body needs-validation">
                        <h1>Inicio de sesión </h1>
                        <p class="text-muted">Ingrese los datos </p>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa fa-user"></i>
                                </span>
                            </div>
                            <input
                                class="form-control"
                                type="text"
                                placeholder="Username"
                                v-model="user.email"
                            />
                            <template v-if="errors">
                                <div class="d-block invalid-feedback">
                                    <span
                                        class="text-muted text-danger"
                                        v-for="(error, key) in errors.email"
                                        :key="key"
                                    >
                                        {{ error }}
                                    </span>
                                </div>
                            </template>
                        </div>
                        <div class="input-group mb-4">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa fa-lock"></i>
                                </span>
                            </div>
                            <input
                                class="form-control"
                                type="password"
                                placeholder="Password"
                                v-model="user.password"
                            />
                            <template v-if="errors">
                                <div class="d-block invalid-feedback">
                                    <span
                                        class="text-muted text-danger"
                                        v-for="(error, key) in errors.password"
                                        :key="key"
                                    >
                                        {{ error }}
                                    </span>
                                </div>
                            </template>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <button
                                    class="btn btn-primary px-4 btn-login"
                                    type="button"
                                    @click.prevent="login"
                                >
                                    Login
                                </button>
                            </div>
                            <div class="col-6 text-right">
                                <button class="btn btn-link px-0" type="button">
                                    
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div
                    class="card text-white bg-primary py-5 d-md-down-none card-login-michin"
                    style="width: 44%"
                >
                    <div class="card-body text-center" style="border: none;">
                        <div>
                            <h2>Bienvenido</h2>
                                <img src="images/logo.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { logMichin } from "../../utils/functions";
let sha1 = require("js-sha1");

export default {
    data() {
        return {
            user: {
                email: null,
                password: null
            },
            errors: {}
        };
    },
    methods: {
        login() {
            let loader = this.$loading.show();

            axios
                .post("/api/auth/login", {
                    ...this.user,
                    password: sha1(this.user.password)
                })
                .then(resp => {
                    if (resp.data.status_transaction) {
                        this.errors = {};
                        this.saveToken({ token: resp.data.token });
                        this.saveRoles(resp.data.roles);
                        loader.hide();
                        document.location.href = "/admin";
                    }

                    if (!resp.data.status_transaction) {
                        this.errors.email = resp.data.message;
                    }
                    loader.hide();
                })
                .catch(error => {
                    loader.hide();
                    this.errors = error.response.data;
                });
        },
        saveToken({ token }) {
            token = localStorage.setItem("token", token);
            token = localStorage.getItem("token");
            if (token) {
                return true;
            } else {
                return false;
            }
        },
        saveRoles(roles) {
            roles = localStorage.setItem("roles", JSON.stringify(roles));
            roles = localStorage.getItem("roles");
            if (roles) {
                return true;
            } else {
                return false;
            }
        }
    }
};
</script>
