<template>
   <div class="animated fadeIn">
      <div class="row">
        <div class="col-md-12">
          <div class="card border-success">
            <div class="card-body">
              <div class="row">
                  <div class="col-md-6">
                    <div class="home-img-nna">
                        <h4>Sistema de Gestión de Informes Michin</h4>   
                    </div>
                     <img class="img-fondo-nna"
                        :src="imgenes.fondo"
                        alt="NNA"
                        />   
                  </div>
                  <div class="col-md-6">
                    <div class="cont-des-sgi">
                      <p><b>SGIM</b> Es un aplicativo web que permite la generación de informes de manera semiautomática sustentando los informes presentados al ICBF con el contenido generado de las atenciones realizadas al NNA, dichas atenciones están plasmadas en las evaluaciones realizadas por las áreas de psicología y trabajo social que a su vez se unen con la información que se ingresa de los demás componentes de atención, que son registradas directamente en la plataforma. Permitiendo contar con el seguimiento de cada informe y llevando el ciclo del proceso desde su creación hasta su envió formar al ICBF. <br> <br>
                      Adicionalmente permite llevar el registro de los familiares de cada menor perteneciente a la institución y los datos relevantes del proceso del menor permitiendo centralizar la información y agilizar los procesos paralelos asociados al NNA.
                      </p>
                      <div class="row">
                        <div class="col-md-3">
                          <div class="list-modulos aa">
                            <div class="list-text-home">
                              Registro y listados NNA  
                            </div>                          
                          </div>                           
                        </div>
                        <div class="col-md-3">
                          <div class="list-modulos bb">
                            <div class="list-text-home">
                            Evaluaciones
                            </div>  
                          </div>                          
                        </div>
                        <div class="col-md-3">
                          <div class="list-modulos cc">
                            <div class="list-text-home">
                            Familiares
                            </div> 
                          </div>                           
                        </div>
                        <div class="col-md-3">
                          <div class="list-modulos dd">
                            <div class="list-text-home">
                            PLATIN 
                          </div>
                          </div>                           
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
            <div class="card-footer">
              <div class="row text-center">
                <div class="col-sm-12 col-md mb-sm-2 mb-0">
                    <div class="text-muted">NNA Activos</div>
                    <strong>35 NNA (80%) | 40 Cupos </strong>
                    <div class="progress progress-xs mt-2">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
                <div class="col-sm-12 col-md mb-sm-2 mb-0">
                  <div class="text-muted">Egresados</div>
                  <strong>120 NNA</strong>
                  <div class="progress progress-xs mt-2">
                  <div class="progress-bar bg-info" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
                <div class="col-sm-12 col-md mb-sm-2 mb-0">
                  <div class="text-muted">Familiares </div>
                  <strong>78.706</strong>
                </div>
                <div class="col-sm-12 col-md mb-sm-2 mb-0">
                  <div class="text-muted">PLATIN Proceso</div>
                  <strong>50 (80%)</strong>
                  <div class="progress progress-xs mt-2">
                  <div class="progress-bar bg-danger" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
                <div class="col-sm-12 col-md mb-sm-2 mb-0">
                  <div class="text-muted">Enviados</div>
                  <strong>40.15%</strong>
                  <div class="progress progress-xs mt-2">
                  <div class="progress-bar" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>
<script>
export default {
  components: {
    // Chat
  },
  data() {
    return {
         imgenes:{
          fondo:"/images/fondo-nna.jpg"
        }
    };
  },
  computed: {
    
  }
};
</script>

