<template>
  <div class="fade-in">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
            <div class="card-header">
              <div class="col-md-12">
                 <h5 class="tit-family-list">Listado Familiares</h5>
              </div>
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-6">
                    <div>Lulu Perez</div>
                    <div class="small text-muted"><span>15 años</span> | SIM: JSDD1547</div>
                  </div>
                  <div class="col-md-6">
                    <button type="button" class="btn btn-outline-success pull-right"  @click.prevent="openModal('#addFamily')">
                     <i class="fas fa-user-plus"></i> Agregar Familiar
                    </button>
                  </div>   
                </div>        
              </div> 
            </div>
            <div class="card-body">
              <div class="col-md-12">
                    <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid">
                      <thead>
                          <tr role="row">
                          <th class="sorting">Acciones</th>
                          <th class="sorting">Identificación</th>
                          <th class="sorting">Nombres</th>
                          <th class="sorting">Apellidos</th>
                          <th class="sorting">Parentesco</th>
                          <th class="sorting">Teléfono</th>
                          <th class="sorting">Tipo Contacto</th>
                          <th class="sorting">Habita </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr role="row" class="odd">
                          <td>
                            <a class="btn btn-success btn-ver" @click.prevent="openModal('#detalles-familia')"><i class="fas fa-dot-circle"></i></a>
                          </td>
                          <td class="sorting_1">5187548</td>
                          <td>Fabian </td>
                          <td>Blanco Estupiñan</td>
                          <td>Abuelo Materno</td>
                          <td>3102548748</td>
                          <td>Normal</td>
                          <td><span class="badge badge-success">No</span></td>
                        </tr>
                      </tbody>
                   </table>
               </div>
            </div>    
        </div>     
      </div>
    </div>
    <AddFamily @addFamily="addFamily"/>
    <FamilyDetails @listReport="FamilyDetails"/>
  </div>
</template>
<script>
import FamilyDetails from './Components/FamilyDetails'
import AddFamily from '../Children/Components/AddFamily'
import { mapState } from 'vuex'
export default {
    components:{
        AddFamily,
        FamilyDetails
    },
    data() {
        return {
           
        }
    },
    methods: {
        FamilyDetails(){
            this.openModal("#FamilyDetails", true)
        },
        addFamily(family){
            this.openModal("#addFamily", true)
        },
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        }
    },
    computed:{

    }
}
</script>