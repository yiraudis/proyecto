<template>
    <div class="modal fade" id="detalles-familia" tabindex="-1" role="dialog" aria-labelledby="detalles-familiaLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title tit-modal" id="detalles-familiaLabel">Información del familiar</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row"> 
               <div class="col-md-12">
                <div class="card">
                   <div class="cont-family-detalles">
                    <div class="row">    
                      <div class="col-md-6">
                        <div>Lulu Perez</div>
                        <div class="small text-muted"><span>15 años</span> | SIM: JSDD1547</div>
                      </div>                 
                      <div class="col-md-6">
                        <div>Tipo Contacto: <small>Principal</small></div>
                          <div class="small text-muted"><span>Parentesco: Mamá</span> | Vivía con NNA: NO</div>
                      </div>
                    </div>               
                  </div>
                  <div class="card-body">
                      <div class="row bd-example2 cont-row-dell">
                        <div class="col-3">
                            <div class="list-group" id="list-example"><a class="list-group-item list-group-item-action active" href="#list-item-1">Datos Básicos</a>
                              <a class="list-group-item list-group-item-action" href="#list-item-2">Datos contacto</a>
                              <a class="list-group-item list-group-item-action" href="#list-item-3">NNA Asociados</a>
                              <a class="list-group-item list-group-item-action " href="#list-item-4">Procesos Relacionados</a>
                            </div>
                        </div>
                        <div class="col-9">
                            <div id="spy-example2" data-spy="scroll" data-target="#list-example" data-offset="0" style="height:300px; overflow: auto">
                              <h4 id="list-item-1">Datos Básicos</h4>
                                <div class="row cont-row-dint">
                                  <div class="col-md-6">
                                    <span><b>Nombre:</b>dsgfdgfdg</span>
                                    <span><b>Identificación:</b>dsgfdgfdg</span>
                                    <span><b>Fecha Nacimiento:</b>dsgfdgfdg</span>
                                    <span><b>Género:</b>dsgfdgfdg</span>
                                  </div>
                                  <div class="col-md-6">
                                    <span><b>Estado civil:</b>dsgfdgfdg</span>
                                    <span><b>Ocupación:</b>dsgfdgfdg</span>
                                    <span><b>Escolaridad:</b>dsgfdgfdg</span>
                                  </div>
                                </div>  
                              <h4 id="list-item-2">Datos contacto</h4>
                                <div class="row cont-row-dint">
                                  <div class="col-md-6">
                                    <span><b>Dirección:</b>dsgfdgfdg</span>
                                    <span><b>Ciudad:</b>dsgfdgfdg</span>
                                    <span><b>Localidad de residencia:</b>dsgfdgfdg</span>
                                    <span><b>Barrio de residencia:</b>dsgfdgfdg</span>
                                  </div>
                                  <div class="col-md-6">
                                     <span><b>Tipo de vivienda:</b>dsgfdgfdg</span>
                                      <span><b>Tenencia de la vivienda:</b>dsgfdgfdg</span>
                                      <span><b>Teléfono:</b>dsgfdgfdg</span>
                                  </div>
                                </div>                              
                              <h4 id="list-item-3">NNA Asociados</h4>
                                <table class="table table-responsive-sm table-hover table-outline tb-del-fami">
                                  <thead class="thead-light">
                                    <tr>
                                      <th class="text-center">
                                        <i class="nav-icon fas fa-child"></i>
                                     </th>
                                      <th>NNA</th>
                                      <th>Parentesto</th>
                                      <th class="text-center">Tipo Contactto</th>
                                      <th>Habitába</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td class="text-center">
                                       <div class="c-avatar"><img class="c-avatar-img" src="assets/img/avatars/1.jpg">
                                        <span class="c-avatar-status bg-success"></span></div>
                                      </td>
                                      <td>
                                          <div>Yiorgos Avraamu</div>
                                          <div class="small text-muted"><span>New</span> | Registered: Jan 1, 2015</div>
                                      </td>
                                      <td class="text-center">
                                          <div>Yiorgos Avraamu</div>
                                      </td>
                                      <td class="text-center">
                                          <small>Principal</small>
                                      </td>
                                      <td>
                                         <div>NO</div>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              <h4 id="list-item-4">Procesos Relacionados</h4>
                                <div class="row">
                                  <table class="table table-responsive-sm table-sm">
                                      <thead>
                                        <tr>
                                          <th>ID</th>
                                          <th>Nombre Evaluación</th>
                                          <th>Tipo</th>
                                          <th>Acciones</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td>EV-0005</td>
                                          <td>Evaluación Individual</td>
                                          <td>Entrevistado</td>
                                          <td><a href="#">Ver</a></td>
                                        </tr>
                                        <tr>
                                          <td>EV-0005</td>
                                          <td>Evaluación Individual</td>
                                          <td>Referenciado</td>
                                          <td><a href="#">Ver</a></td>
                                        </tr>
                                        <tr>
                                          <td>EV-0005</td>
                                          <td>Evaluación Individual</td>
                                          <td>Referenciado</td>
                                          <td><a href="#">Ver</a></td>
                                         </tr>
                                    </tbody>
                                  </table>
                              </div>           
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
             </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>    
          </div>
        </div>
      </div>
    </div>
</template>