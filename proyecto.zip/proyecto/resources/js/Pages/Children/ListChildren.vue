<template>
    <div class="fade-in">
      <div class="row">
          <div class="col-md-12">
            <div class="nav-tabs-boxed nav-tabs-boxed-left">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active tap-activos" data-toggle="tab" href="#active-lists-3" role="tab" aria-controls="active-lists" aria-selected="false"><i class="fas fa-home"></i> En proceso</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link tap-egresados" data-toggle="tab" href="#finished-lists-3" role="tab" aria-controls="finished-lists" aria-selected="false"><i class="fas fa-door-closed"></i> Egresados</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="active-lists-3" role="tabpanel">
                      <div class="row">
                        <div class=" form-group col-md-12">
                            <router-link tag="a" to="/admin/children"  class="btn btn-outline-success pull-right">
                              <i class="fas fa-user-plus"></i> Nuevo NNA
                            </router-link>
                        </div>
                        <div class="col-md-12">
                          <table class="table table-striped table-bordered datatable dataTable no-footer" id="tb_children_active" role="grid">
                            <thead>
                              <tr role="row">
                                <th class="sorting">Acciones</th>
                                <th class="sorting">Código</th>
                                <th class="sorting">SIM</th>
                                <th class="sorting">N° H.A.</th>
                                <th class="sorting">Nombre</th>
                                <th class="sorting">Edad</th>
                                <th class="sorting">Casa</th>
                                <th class="sorting">Equipo PS</th>
                                <th class="sorting">Platin</th>
                              </tr>
                            </thead>
                            <tbody>
                                <tr v-for="nna in children_active" :key="nna.id">
                                  <td>
                                   <router-link tag="a" to="/admin/children" class="btn btn-success btn-ver">
                                    <i class="fas fa-user-edit"></i>
                                  </router-link>
                                  <a class="btn btn-warning btn-evaluaciones" @click.prevent="openModal('#report-list-show')"><i class="fas fa-clipboard-list"></i></a>
                                    <router-link tag="a" to="/admin/listado_familia"  class="btn btn-secondary">
                                    <i class="fas fa-users"></i>
                                  </router-link> 
                                  <a class="btn btn-danger btn-delete" href="#" v-on:click="listNna"  ><i class="fas fa-user-slash"></i></a>
                                </td>
                                <td>NNA-{{cerosIzquierda(nna.id,7)}}</td>
                                <td>{{nna.sim}}</td>
                                <td>{{nna.numero_ha}}</td>
                                <td>{{nna.user.primer_nombre}} {{nna.user.segundo_nombre}} {{nna.user.primer_apellido}} {{nna.user.segundo_apellido}}</td>
                                <td>{{ageCalculate(nna.user.fecha_nacimiento)}}</td>                                
                                <td>{{nna.children_house[0].house.nombre}}</td>
                                <td><h6 class="list-nna-ps">{{nna.psychologist.primer_nombre}} {{nna.psychologist.primer_apellido}} {{nna.psychologist.segundo_apellido}} (Psicolog@)</h6><h6 class="list-nna-tb">{{nna.social_work.primer_nombre}} {{nna.social_work.primer_apellido}} {{nna.social_work.segundo_apellido}} (T.Social)</h6></td>
                                <td>{{nna.id}}</td>
                            </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane" id="finished-lists-3" role="tabpanel">
                        <div class="col-md-12">
                          <table class="table table-striped table-bordered datatable dataTable no-footer" id="tb_children_inactive" role="grid">
                            <thead>
                              <tr role="row">
                                <th class="sorting">Acciones</th>
                                <th class="sorting">Código</th>
                                <th class="sorting">SIM</th>
                                <th class="sorting">N° H.A.</th>
                                <th class="sorting">Nombre</th>
                                <th class="sorting">F.Ingreso</th>
                                <th class="sorting">F. Egreso</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr role="row" class="odd"  v-for="nna_inac in children_inactive" :key="nna_inac.id">
                                  <td>
                                   <router-link tag="a" to="/admin/children" class="btn btn-success btn-ver">
                                    <i class="fas fa-dot-circle"></i>
                                  </router-link>
                                  <a class="btn btn-warning btn-evaluaciones" @click.prevent="openModal('#report-list-show')"><i class="fas fa-clipboard-list"></i></a>
                                  <router-link tag="a" to="/admin/listado_familia"  class="btn btn-secondary">
                                    <i class="fas fa-users"></i>
                                  </router-link> 
                                  <a class="btn btn-info btn-history" href="#"  ><i class="fas fa-clipboard"></i></a>
                                </td>
                                <td class="sorting_1">NNA-{{cerosIzquierda(nna_inac.id,7)}}</td>
                                <td>{{nna_inac.sim}}</td>
                                <td>{{nna_inac.numero_ha}}</td>
                                <td>{{nna_inac.user.primer_nombre}} {{nna_inac.user.segundo_nombre}} {{nna_inac.user.primer_apellido}} {{nna_inac.user.segundo_apellido}}</td>
                                <td>{{nna_inac.fecha_ingreso}}</td>
                                <td>{{nna_inac.fecha_egreso}}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
        <ReportList @listReport="listReport"/>
    </div>
</template>
<script>
import ReportList from './Components/ReportList'
import {logMichin} from '../../utils/functions'
import {nnaList} from '../../utils/services/children'
import { mapState } from 'vuex'
export default {
    components:{
        ReportList
    },
    data() {
        return {
           children_active:[],
           children_inactive:[]
        }
    },
    methods: {
        listReport(){
            this.openModal("#listReport", true)
        },
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        },
         async listNna(){
            let data = await nnaList();
            this.children_active=data.data.nnaList.childrenActive;
            this.children_inactive=data.data.nnaList.childrenInactive;
            // logMichin(data);
        },
        cerosIzquierda(number, width){
            var numberOutput = Math.abs(number); /* Valor absoluto del número */
            var length = number.toString().length; /* Largo del número */ 
            var zero = "0"; /* String de cero */  
            
            if (width <= length) {
                if (number < 0) {
                    return ("-" + numberOutput.toString()); 
                } else {
                    return numberOutput.toString(); 
                }
            } else {
                if (number < 0) {
                    return ("-" + (zero.repeat(width - length)) + numberOutput.toString()); 
                } else {
                    return ((zero.repeat(width - length)) + numberOutput.toString()); 
                }
            }
        },
        ageCalculate(fecha_nacimiento) {
            if (fecha_nacimiento) {
                let fecha = fecha_nacimiento;
                
                if (typeof fecha != "string" && fecha && esNumero(fecha.getTime())) {
                    fecha = formatDate(fecha, "yyyy-MM-dd");
                }

                var values = fecha.split("-");
                var dia = values[2];
                var mes = values[1];
                var ano = values[0];

                // cogemos los valores actuales
                var fecha_hoy = new Date();
                var ahora_ano = fecha_hoy.getYear();
                var ahora_mes = fecha_hoy.getMonth() + 1;
                var ahora_dia = fecha_hoy.getDate();

                // realizamos el calculo
                var edad = (ahora_ano + 1900) - ano;
                if (ahora_mes < mes) {
                    edad--;
                }
                if ((mes == ahora_mes) && (ahora_dia < dia)) {
                    edad--;
                }
                if (edad > 1900) {
                    edad -= 1900;
                }

                // calculamos los meses
                var meses = 0;

                if (ahora_mes > mes && dia > ahora_dia)
                    meses = ahora_mes - mes - 1;
                else if (ahora_mes > mes)
                    meses = ahora_mes - mes
                if (ahora_mes < mes && dia < ahora_dia)
                    meses = 12 - (mes - ahora_mes);
                else if (ahora_mes < mes)
                    meses = 12 - (mes - ahora_mes + 1);
                if (ahora_mes == mes && dia > ahora_dia)
                    meses = 11;

                // calculamos los dias
                var dias = 0;
                if (ahora_dia > dia)
                    dias = ahora_dia - dia;
                if (ahora_dia < dia) {
                    ultimoDiaMes = new Date(ahora_ano, ahora_mes - 1, 0);
                    dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
                }

                return edad + " años, " + meses + " meses"//  + dias + " días";
            }else{
                return ""
            }
        }
        
    },
    computed:{

    },
    created() {
      this.listNna();
    }
}
</script>