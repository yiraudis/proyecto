<template>
  <div class="fade-in">
    <div class="row">
      <div class="col-md-12">
        <h6 class="tit-rnna pull-right">Registro NNA</h6>  
      </div>      
    </div>        
    <div class="row bd-example2 cont-row-rnna">    
      <div class="col-2 col-taps-nna">
          <div class="list-group" id="list-example"><a class="list-group-item item-rnna list-group-item-action active" href="#list-item-1">Datos Básicos NNA</a>
            <a class="list-group-item item-rnna list-group-item-action" href="#list-item-2">Estado del proceso</a>
            <a class="list-group-item item-rnna list-group-item-action" href="#list-item-3">Caracterización</a>
            <a class="list-group-item item-rnna list-group-item-action " href="#list-item-4">Composición familiar</a>
          </div>
      </div>
      <div class="col-10 col-rnna-del">
        <div id="spy-example2" data-spy="scroll" data-target="#list-example" data-offset="0" class="cont-interno-nna">
          <h4 id="list-item-1">Datos Básicos</h4>
           <div class="cont-componentes-nna">
             <BasicData @changeCity="changeCity" @changeStatus="statusComponents"/>
           </div>            
          <h4 id="list-item-2">Estado del proceso</h4>
          <div class="cont-componentes-nna">
             <StateProcess :residenceLocality="residenceLocality" @changeStatus="statusComponents"/>
          </div>
          <h4 id="list-item-3">Caracterización</h4>
          <div class="cont-componentes-nna">
              <Characterization @changeStatus="statusComponents"/>
          </div>
          <h4 id="list-item-4">Composición familiar</h4>
          <div class="cont-componentes-nna">
              <FamilyComposition @changeStatus="statusComponents"/>
          </div>
        </div>
        <div class="card">
          <div class="row justify-content-center">
            <button class="btn btn-outline-success active  btn-rnna" @click.prevent="saveInformation()">Registrar</button>
          </div>
      </div>
    </div>
      <p>{{isDisabled.count}}</p>
  </div>
</div> 
</template>
<script>
import BasicData from "./Components/BasicData";
import StateProcess from "./Components/StateProcess";
import Characterization from "./Components/Characterization";
import FamilyComposition from "./Components/FamilyComposition";
import { mapActions } from 'vuex';

import {newChildren} from '../../utils/services/children'
import { logMichin } from '../../utils/functions';
export default {
  components: {
    BasicData,
    StateProcess,
    Characterization,
    FamilyComposition
  },
  data() {
    return {
      residenceLocality:[],
      statusForm:{},
      count: 0
    }
  },
  mounted() {
    // this.$swal({
    //     icon: 'warning',
    //     title: 'Oops...',
    //     text: 'Something went wrong!',
    //   // footer: '<a href>Why do I have this issue?</a>'
    // })
  },
  methods: {
    changeCity(city){
      this.residenceLocality = city.residence_locality;
    },
    statusComponents(data){
      this.statusForm[data.component] = data
    },
    async saveInformation(){
      let count = 0;
      let count_success = 0;
      let count_error = 0;
      for (const key in this.statusForm) {
        count++
        if (this.statusForm[key].hasOwnProperty("status") && this.statusForm[key]["status"]) {
          count_success++ 
          logMichin("Success: ",count_success, key)
        }else{
          count_error++
          this.$swal({
              icon: 'warning',
              title: 'Oops...',
              text: `Falta información en el tab ${this.statusForm[key]["name"]}`
            // footer: '<a href>Why do I have this issue?</a>'
          })
          logMichin("Error: ",count_error, key)
          return
        }
      }

      let loader = this.$loading.show();
      logMichin("Hola .....1 ")
      let resp = await newChildren(this.statusForm)

      if(resp.data.newChildren.status_transaction){
        this.$swal({
              icon: 'success',
              title: 'Genial',
              text: `${resp.data.newChildren.message}`
            // footer: '<a href>Why do I have this issue?</a>'
          })
        loader.hide()
        location.reload()
      }else{
        this.$swal({
              icon: 'error',
              title: 'Oops...',
              text: `${resp.data.newChildren.message}`
            // footer: '<a href>Why do I have this issue?</a>'
          })
        loader.hide()
      }
      logMichin(resp)
      logMichin("Hola .....2 ")

    },
    
  },
  computed: {
    isDisabled(){
      let count = 0;
      let count_success = 0;
      let count_error = 0;
      logMichin("this.statusFor:",this.statusForm.basicData)
    
        
      // for (const key in this.statusForm) {
      //   // count++
      //   // if (this.statusForm[key].hasOwnProperty("status") && this.statusForm[key]["status"]) {
      //   //   count_success++ 
      //   //   logMichin("Success: ",count_success)
      //   // }else{
      //   //   count_error++
      //   //   logMichin("Error: ",count_error)

      //   // }
      // }
      logMichin("Error: ",count_error)
      return count;
    }
  },
};
</script>
