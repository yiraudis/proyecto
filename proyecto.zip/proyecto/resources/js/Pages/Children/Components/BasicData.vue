<template>
   <div>
        <div class="row">
           <!--  <div class="col-md-2 mb-2 text-center mt-0">
                    <img class="rounded shadow-lg foto-nna" src="/images/avatars/profile.jpg">
                    <span class="ha-daba-basic">HA/HSF-</span>
            </div> -->
            <div class="col-md-10">
                <div class="row">
                    <div class="form-group col-md-3">
                    <label for="name">Nombre</label>
                    <input v-model="basicData.name" type="text" id="name" name="name"  :class="classObject.name" placeholder="Nombre">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="surname">Primer apellido</label>
                        <input v-model="basicData.surname" type="text" id="surname" name="surname" :class="classObject.surname" placeholder="Primer apellido">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="secound-surname">Segundo apellido</label>
                        <input v-model="basicData.secoundSurname" type="text" id="secound-surname" :class="classObject.secoundSurname" name="secound-surname" placeholder="Segundo apellido">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="secound-surname">
                            <a href="#" >({{basicData.documentTypes.length}}) documentos</a></label>                        
                        <button type="button" class="btn btn-block btn-outline-success" data-toggle="modal" data-target="#addDocumentType"><i class="bnt-ico fas fa-check-double"></i>                        Agregar Documento
                        </button>
                    </div>

                    
                    <div class="form-group col-md-3">
                        <label for="sex">Género</label>
                        <v-select v-model="basicData.sex" :options="sexs" label="nombre" placeholder="Género" inputId="sex">
                            <template slot="no-options">
                                <span>No existe el género</span>
                            </template>
                        </v-select>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="date-birth">Fecha de nacimiento</label>
                        <datetime v-model="basicData.dateBirth" :auto="true" :input-class="classObject.dateBirth" input-id="date-birth" placeholder="Fecha de nacimiento" :max-datetime="now"></datetime>
                        <small class="text-success">{{ageCalculate}}</small>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="country">País de nacimiento</label>
                        <v-select v-model="basicData.country" :options="countries" label="nombre" placeholder="País de nacimiento" inputId="country" @input="selectCountry">
                            <template slot="no-options">
                                <span>No existe el país</span>
                            </template>
                        </v-select>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="department">Departamento</label>
                        <v-select v-model="basicData.department" :options="departments" label="nombre" placeholder="Departamento" inputId="department" @input="selectDepartment">
                            <template slot="no-options">
                                <span>No existe el departamento</span>
                            </template>
                        </v-select>
                    </div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <label for="country">Municipio</label>
                <v-select v-model="basicData.city" :options="cities" label="nombre" placeholder="Municipio" inputId="city" @input="changeCity">
                    <template slot="no-options">
                        <span>No existe el municipio</span>
                    </template>
                </v-select>
            </div>
            <div class="form-group col-md-3">
                <label for="country">Nacionalidad</label>
                <input type="text" disabled :value="basicData.country&&basicData.country.nacionalidad" class="form-control">
            </div>
            <div class="form-group col-md-3">
                <label for="ethnicGroup">Grupo étnico</label>
                <v-select v-model="basicData.ethnicGroup" :options="ethnicGroups" label="name" placeholder="Grupo étnico" inputId="ethnicGroup">
                    <template slot="no-options">
                        <span>No existe el grupo étnico</span>
                    </template>
                </v-select>
            </div>
            <div class="form-group col-md-3">
                <label for="location">Ubicación</label>
                <v-select v-model="basicData.location" :options="locations" label="nombre" placeholder="Ubicación" inputId="location">
                    <template slot="no-options">
                        <span>No existe el ubicación</span>
                    </template>
                </v-select>
            </div>
            <div class="form-group col-md-3">
                <label for="regional">Regional</label>
                <input v-model="basicData.regional" type="number" id="regional" name="regional" :class="classObject.regional" placeholder="Regional">
            </div>
            <div class="form-group col-md-2">
                <label for="leter">Letra</label>
                <input v-model="basicData.leter" type="text" id="leter" name="leter" :class="classObject.leter" placeholder="Letra">
            </div>
            <div class="form-group col-md-2">
                <label for="number">Número</label>
                <input v-model="basicData.number" type="number" id="number" name="number" :class="classObject.number" placeholder="Número">
            </div>
            <div class="form-group col-md-2">
                <label for="brothers">No hermanos</label>
                <input v-model="basicData.brothers" type="number" id="brothers" name="brothers" :class="classObject.brothers" placeholder="Número de hermanos">
            </div>
            <div class="form-group col-md-3">
                <label for="sim">SIM</label>
                <input v-model="basicData.sim" type="text" id="sim" name="sim" :class="classObject.sim" placeholder="SIM">
            </div>
            <!-- <div class="form-group col-md-3">
                <label for="sexual-orientation">Orientación sexual</label>
                <v-select v-model="basicData.sexualOrientation" :options="sexualOrientations" label="name" placeholder="Orientación sexual" inputId="sexual-orientation">
                    <template slot="no-options">
                        <span>No existe el orientación sexual</span>
                    </template>
                </v-select>
            </div> -->
        </div>
        <AddDocumentType :documentTypesUser="basicData.documentTypes" @addDocumentType="addDocumentType" @deleteDocumentType="deleteDocumentType"/>
        <HomeAssignment @AddInfoHome="addInfoHome"/>
        <!-- <div class="form-group col-md-12">
            <pre>{{ $v }}</pre>
        </div> -->
    </div>
</template>

<script>
import HomeAssignment from './HomeAssignment'
import AddDocumentType from './AddDocumentType'
import { mapState, mapMutations } from 'vuex'
import { basicData } from '../../../utils/validators/Children/basicData'
export default {
    components:{
        HomeAssignment,
        AddDocumentType
    },
    data(){
        return {
            departments:[],
            sexualOrientations:[{name:"Homosexual", id:1}, {name:"Heterosexual", id:2}],
            cities:[],
            now:new Date().toISOString(),
            basicData: {
                name:"",
                surname:"",
                secoundSurname:"",
                sex:null,
                dateBirth:"",
                country:null,
                department:null,
                city:null,
                regional:"",
                leter:"",
                number:"",
                brothers:"",
                ethnicGroup:null,
                sim:"",
                location:null,
                documentTypes:[],
                infoHome:null
            }
        }
    },
    methods: {
        ...mapMutations(["setDepartmetSelected"]),
        selectCountry(country){
            this.basicData.department = null
            if (country) {
                this.departments = country.departments
            }else{
                this.basicData.department = null

                this.departments = []
            }
        },
        selectDepartment(department){
            this.cities = []
            if (department) {
                this.cities= department.cities
            }else{
                this.cities = []
                this.basicData.city = null
            }
            this.setDepartmetSelected(department)
            
        },
        changeCity(city){
            if (city) {
                this.$emit("changeCity", city)
            }
        },
        addInfoHome(data){
            this.logMichin(data)
            this.basicData.infoHome = data

            this.$emit("changeStatus", {
                component:this.$options._componentTag,
                name: "datos básicos de niño o niña",
                status:!this.$v.basicData.$invalid,
                data:this.basicData
            })
        },
        addDocumentType(doc){
            this.basicData.documentTypes.push(doc)
        },
        deleteDocumentType(index){
            this.basicData.documentTypes.splice(index, 1)
        }
    },
    computed:{
        ...mapState(['sexs', 'countries', 'ethnicGroups', 'locations']),
        ageCalculate() {
            if (this.basicData.dateBirth) {
                let fecha = this.basicData.dateBirth
                
                if (typeof fecha != "string" && fecha && esNumero(fecha.getTime())) {
                    fecha = formatDate(fecha, "yyyy-MM-dd");
                }

                var values = fecha.split("-");
                var dia = values[2];
                var mes = values[1];
                var ano = values[0];

                // cogemos los valores actuales
                var fecha_hoy = new Date();
                var ahora_ano = fecha_hoy.getYear();
                var ahora_mes = fecha_hoy.getMonth() + 1;
                var ahora_dia = fecha_hoy.getDate();

                // realizamos el calculo
                var edad = (ahora_ano + 1900) - ano;
                if (ahora_mes < mes) {
                    edad--;
                }
                if ((mes == ahora_mes) && (ahora_dia < dia)) {
                    edad--;
                }
                if (edad > 1900) {
                    edad -= 1900;
                }

                // calculamos los meses
                var meses = 0;

                if (ahora_mes > mes && dia > ahora_dia)
                    meses = ahora_mes - mes - 1;
                else if (ahora_mes > mes)
                    meses = ahora_mes - mes
                if (ahora_mes < mes && dia < ahora_dia)
                    meses = 12 - (mes - ahora_mes);
                else if (ahora_mes < mes)
                    meses = 12 - (mes - ahora_mes + 1);
                if (ahora_mes == mes && dia > ahora_dia)
                    meses = 11;

                // calculamos los dias
                var dias = 0;
                if (ahora_dia > dia)
                    dias = ahora_dia - dia;
                if (ahora_dia < dia) {
                    ultimoDiaMes = new Date(ahora_ano, ahora_mes - 1, 0);
                    dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
                }

                return edad + " años, " + meses + " meses"//  + dias + " días";
            }else{
                return ""
            }
        },
        classObject(){
            let errors = {}
            for (const key in basicData) {
                const element = this.$v.basicData[key];
                if (typeof element.$model != "object") {
                    if (element.$model.length >0 && element.$invalid ) {
                        errors[key] = {
                                'is-invalid':true,
                                'form-control':true,
                            }
                            
                    } else if(element.$model.length >0 && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            this.$emit("changeStatus", {
                component:this.$options._componentTag,
                name: "datos básicos de niño o niña",
                status:!this.$v.basicData.$invalid,
                data:this.basicData
            })
            return errors
        }
    },
    validations: {
        basicData
    }
}
</script>