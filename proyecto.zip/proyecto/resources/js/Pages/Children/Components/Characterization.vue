<template>
    <div class="row">
        <div class="form-group col-md-3">
            <label for="schooling">Escolaridad del menor</label>
            <v-select v-model="characterizacion.schooling" :options="scholarships" label="nombre" placeholder="Escolaridad del menor" inputId="home">
                <template slot="no-options">
                    <span>No existe la escolaridad</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="disease">Enfermedad</label>
            <v-select v-model="characterizacion.disease" :options="diseases" label="name" placeholder="Enfermedad" inputId="disease">
                <template slot="no-options">
                    <span>No existe esta enfermedad</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="vaccine">Vacunas</label>
            <v-select v-model="characterizacion.vaccine" :options="vaccines" label="name" placeholder="Vacunas" inputId="vaccine">
                <template slot="no-options">
                    <span>No existe esta enfermedad</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Accidentes</label>
            <v-select v-model="characterizacion.accident" :options="accidents" label="name" placeholder="Accidentes" inputId="accident">
                <template slot="no-options">
                    <span>No existe este accidente</span>
                </template>
            </v-select>
        </div>


        <div class="form-group col-md-3">
            <label for="typeDisability">Tipo de discapacidad</label>
            <v-select v-model="characterizacion.typeDisability" :options="typeDisabilitys" label="name" placeholder="Tipo de discapacidad" inputId="typeDisability" >
                <template slot="no-options">
                    <span>No existe esta enfermedad</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="nutritionalState">Estado nutricional</label>
            <v-select v-model="characterizacion.nutritionalState" :options="nutritionalStates" label="name" placeholder="Estado nutricional" inputId="nutritionalState" >
                <template slot="no-options">
                    <span>No existe este estado nutricional</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="regime">Regimen</label>
            <v-select v-model="characterizacion.regime" :options="regimes" label="name" placeholder="Regimen" inputId="regime">
                <template slot="no-options">
                    <span>No existe esta regimen</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="regimeName">Nombre</label>
            <input v-model="characterizacion.regimeName" type="text" id="regimeName" name="regimeName" :class="classObject.regimeName" placeholder="Nombre">
        </div>

        <!-- <pre>{{ $v }}</pre> -->
    </div>
</template>

<script>
import { characterizacion } from '../../../utils/validators/Children/characterizacion'
import { mapState } from 'vuex'
export default {
    data() {
        return {
            characterizacion:{
                schooling:null,
                disease:null,
                vaccine:null,
                accident:null,
                typeDisability:null,
                nutritionalState:null,
                regime:null,
                regimeName:""

            },
            diseases:[
                {id:1,name:"SI"},
                {id:0,name:"NO"},
            ],
            vaccines:[
                {id:1,name:"ECE"},
                {id:2,name:"EIE"},
            ],
            accidents:[
                {id:1,name:"SI"},
                {id:0,name:"NO"},
            ],
            typeDisabilitys:[
                {id:1, name:"Congnitiva"},
                {id:2, name:"Física"},
            ],
            nutritionalStates:[
                {id:1, name:"Desnutrición morvida"},
                {id:2, name:"Desnutrición"},
            ],
            regimes:[
                // CONTRIBUTIVO, SUBSIDIADO,NINGUNA
                {id:1, name:"SUBSIDIADO"},
                {id:2, name:"CONTRIBUTIVO"},
                {id:3, name:"BENEFICIARIO"},
                {id:4, name:"NINGUNA"},
            ]
        }
    },
    validations:{
        characterizacion
    },
    computed: {
        ...mapState(['scholarships']),
        classObject(){
            let errors = {}
            for (const key in this.$v.characterizacion.$params) {
                const element = this.$v.characterizacion[key];
                if (key != "schooling" && key != "disease" && key != "vaccine" && key != "accident" && key != "typeDisability" && key != "nutritionalState" && key != "regime") {
                    if (element.$model.length >0 && element.$invalid ) {
                        errors[key] = {
                                'is-invalid':true,
                                'form-control':true,
                            }
                    } else if(element.$model.length >0 && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            this.$emit("changeStatus", {
                component:this.$options._componentTag,
                name: "caracterización",
                status:!this.$v.characterizacion.$invalid,
                data: this.characterizacion
            })
            return errors
        }
    },
}
</script>