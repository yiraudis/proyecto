<template>
<div>
    <div class="col-md-12 titulo-entrevistados">
        <h3>Asignación de casa y profesionales</h3> 
        <hr>
    </div>
    <div class="row con-row-agcasa">
        <div class="form-group col-md-4">
            <label for="house">Casa</label>
            <v-select v-model="infoHome.house" :options="houses" label="nombre" placeholder="Casa" inputId="house" @input="selectHouse">
                <template slot="no-options">
                    <span>No existe esta casa</span>
                </template>
            </v-select>
            <span v-html="getCoordinators"></span>
        </div>
        <div class="form-group col-md-4">
            <label for="social-worker">Trabajador(a) social</label>
            <v-select inputClass="hola" v-model="infoHome.socialWorker" :options="socialWorkers" label="primer_nombre" placeholder="Trabajador(a) social" inputId="social-worker">
                <template slot="no-options">
                    <span>No existe el trabajador(a) social</span>
                </template>
            </v-select>
        </div>
        <div class="form-group col-md-4">
            <label for="psychologist">Psicologo(a)</label>
            <v-select v-model="infoHome.psychologist" :options="psychologists" label="primer_nombre" placeholder="Psicologo(a)" inputId="psychologist">
                <template slot="no-options">
                    <span>No existe el Psicologo(a)</span>
                </template>
            </v-select>
        </div>
    </div>

    


</div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { infoHome } from '../../../utils/validators/Children/basicData'
export default {
    data(){
        return {
            infoHome:{
                house:null,
                socialWorker:null,
                psychologist:null
            },
        }
    },
    mounted() {
        this.getHouses()
        this.getSocialWorkers()
        this.getPsychologists()
    },
    methods: {
        ...mapActions(['getHouses', 'getSocialWorkers', 'getPsychologists']),
        selectHouse(home){
        }
    },
    validations:{
        infoHome
    },
    computed: {
        ...mapState(['houses', 'socialWorkers', 'psychologists']),
        getCoordinators(){
            if (!this.$v.infoHome.$invalid) {
                this.$emit("AddInfoHome", this.infoHome)
            }else{
                this.$emit("AddInfoHome", null)
            }
            if (this.infoHome.house) {
                return `<p class="text-success m-0"><small>  Coordinador(a) palnta: ${this.infoHome.house.plant_coordinator && this.infoHome.house.plant_coordinator.primer_nombre } </small></p>
                        <p class="text-primary m-0"><small>Coordinador(a) fin de semana: ${this.infoHome.house.relief_coordinator && this.infoHome.house.relief_coordinator.primer_nombre }</small></p>`
            }
            return ""
        }
    },
}
</script>