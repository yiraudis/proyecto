<template>
    <div class="row">
        <div class="form-group col-md-3">
            <label for="accident">Area social</label>
            <v-select v-model="familyComposition.socialArea" :options="socialAreas" label="name" placeholder="Area social" inputId="socialArea">
                <template slot="no-options">
                    <span>No existe esta area social</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Tipo de familia</label>
            <v-select v-model="familyComposition.familyType" :options="typesFamily" label="nombre" placeholder="Tipo de familia" inputId="familyType">
                <template slot="no-options">
                    <span>No existe este tipo de familia</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Responden por el menor</label>
            <v-select v-model="familyComposition.responsible" :options="responsables" label="nombre" placeholder="Responden por el menor" inputId="responsible">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>
        <div class="form-group col-md-3">
            <label for="accident">Antecedentes familiares</label>
            <v-select v-model="familyComposition.familyBackground" :options="familyBackground" label="nombre" placeholder="Antecedentes familiares" inputId="familyBackground">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Ingresos familiares</label>
            <v-select v-model="familyComposition.familyIncome" :options="familyIncome" label="nombre" placeholder="Ingresos familiares" inputId="familyIncome">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Ocupación familiar</label>
            <v-select v-model="familyComposition.activitie" :options="familyOccupations" label="nombre" placeholder="Ocupación familiar" inputId="activitie">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Personas que aportan económicamente</label>
            <v-select v-model="familyComposition.peopleWhoContributeFinancially" :options="responsables" label="nombre" placeholder="Ocupación familiar" inputId="activitie">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>

        <div class="form-group col-md-3">
            <label for="accident">Escolaridad del responsable del menor</label>
            <v-select v-model="familyComposition.schooling" :options="scholarships" label="nombre" placeholder="Escolaridad del responsable del menor" inputId="schooling" :class="classObject.schooling">
                <template slot="no-options">
                    <span>No existe la opción</span>
                </template>
            </v-select>
        </div>
        <div class="col-md-12 mb-5">
            <div class="row justify-content-center">
                <button type="button" class="btn btn-outline-success btn-entre  mr-3 text-center"  @click.prevent="openModal('#addFamily')">
                   <i class="bnt-ico fas fa-user-plus"></i> Agregar Familiar
                </button>
            </div>
        </div>

        <div class="col-md-12">
            <div class="row justify-content-center">
                <table class="table table-bordered" v-if="familyComposition.families[0]">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Documento</th>
                            <th scope="col">Escolaridad</th>
                            <th scope="col">Contacto principal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in familyComposition.families" :key="index">
                            <td>{{item.name}}</td>
                            <td>{{item.identification}}</td>
                            <td>{{item.schooling.name}}</td>
                            <td>{{item.principal ? "SI":"NO"}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <AddFamily @addFamily="addFamily"/>

       
    </div>
</template>

<script>
import AddFamily from './AddFamily'
import {familyComposition} from '../../../utils/validators/Children/familyComposition'
import { mapState } from 'vuex'
export default {
    components:{
        AddFamily
    },
    data() {
        return {
            familyComposition:{
                families:[],
                socialArea:null,
                familyType:null,
                responsible:null,
                familyBackground:null,
                familyIncome:null,
                activitie:null,
                peopleWhoContributeFinancially:null,
                schooling:null,
            },
            socialAreas:[
                {id:1, name:"Tiene familia"},
                {id:2, name:"No tiene familia"},
            ],
            peopleWhoContributeFinanciallys:[
                {id:1, name:"Madre"},
                {id:2, name:"Padre"},
            ],
           
        }
    },
    methods: {
        addFamily(family){
            this.familyComposition.families.push(family)
            this.logMichin(family)
            this.openModal("#addFamily", true)
        },
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        }
    },
    validations:{
        familyComposition
    },
    computed:{
        ...mapState(['typesFamily', 'responsables', 'familyIncome', 'familyOccupations', 'familyBackground', 'scholarships']),
        classObject(){
            let errors = {}
            for (const key in familyComposition) {
                const element = this.$v.familyComposition[key];
                if (typeof element.$model != "object") {
                    if (element.$model[0] && element.$invalid ) {
                        errors[key] = {
                                'is-invalid':true,
                                'form-control':true,
                            }
                            
                    } else if(element.$model[0] && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            this.$emit("changeStatus", {
                component:this.$options._componentTag,
                name: "composición familiar",
                status:!this.$v.familyComposition.$invalid,
                data:this.familyComposition
            })
            return errors
        }
    }
}
</script>