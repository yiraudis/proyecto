<template>
    <!-- Button trigger modal -->
    <!-- Modal -->
    <div class="modal fade" id="addFamily" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title tit-modal" id="staticBackdropLabel">Agregar integrante familiar</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body row">
            <div class="form-group col-md-4">
                <label for="name3">Nombre</label>
                <input v-model="family.name" type="text" id="name3" name="name3" :class="classObject.name" placeholder="Nombre completo">
            </div>
            <div class="form-group col-md-4">
                <label for="surname3">Primer apellido</label>
                <input v-model="family.surname" type="text" id="surname3" name="surname3" :class="classObject.surname" placeholder="Primer apellido">
            </div>
            <div class="form-group col-md-4">
                <label for="secound-surname3">Segundo apellido</label>
                <input v-model="family.secoundSurname" type="text" id="secound-surname3" :class="classObject.secoundSurname" name="secound-surname3" placeholder="Segundo apellido">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Número de identificación</label>
                <input v-model="family.identification" type="text" id="identification" name="identification" :class="classObject.identification" placeholder="Número de identificación">
            </div>
            <div class="form-group col-md-4">
                <label for="date-birth">Fecha de nacimiento</label>
                <datetime v-model="family.dateBirth" :auto="true" :input-class="classObject.dateBirth" input-id="datebirth" placeholder="Fecha de nacimiento"></datetime>
                <small class="text-success">{{ageCalculate}}</small>
            </div>
            <div class="form-group col-md-4">
                <label for="sex">Género</label>
                <v-select v-model="family.sex" :options="sexs" label="nombre" placeholder="Género" inputId="sex">
                    <template slot="no-options">
                        <span>No existe el género</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="civilStatus">Estado civil</label>
                <v-select v-model="family.civilStatus" :options="civilStatuses" label="name" placeholder="Estado civil" inputId="civilStatus">
                    <template slot="no-options">
                        <span>No existe la opción</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="accident">Ocupación</label>
                <v-select v-model="family.activitie" :options="familyOccupations" label="nombre" placeholder="Ocupación" inputId="activitie">
                    <template slot="no-options">
                        <span>No existe la opción</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="schooling">Escolaridad</label>
                <v-select v-model="family.schooling" :options="scholarships" label="nombre" placeholder="Escolaridad" inputId="schooling">
                    <template slot="no-options">
                        <span>No existe la escolaridad</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="country">Ciudad</label>
                <v-select v-model="family.city" :options="cities" label="nombre" placeholder="Municipio" inputId="city" @input="changeCity">
                    <template slot="no-options">
                        <span>No existe el municipio</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="residenceLocality">Localidad de residencia</label>
                <v-select v-model="family.residenceLocality" :options="residence_locality" label="nombre" placeholder="Localidad de residencia" inputId="residenceLocality" @input="changeResidenceLocality">
                    <template slot="no-options">
                        <span>No existe la localidad</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="neighborhoodResidence3">Barrio de residencia</label>
                <v-select v-model="family.neighborhood" :options="neighborhood" label="nombre" placeholder="Barrio de residencia" inputId="neighborhoodResidence3">
                    <template slot="no-options">
                        <span>No existe el barrio</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="address">Dirección</label>
                <input v-model="family.address" type="text" id="address" name="address" :class="classObject.address" placeholder="Dorección">
            </div>

            <div class="form-group col-md-4">
                <label for="schooling">Tipo de vivienda</label>
                <v-select v-model="family.housingType" :options="housingTypes" label="nombre" placeholder="Tipo de vivienda" inputId="relationship">
                    <template slot="no-options">
                        <span>No existe la opción</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="schooling">Tenencia de la vivienda</label>
                <v-select v-model="family.ownership" :options="ownerships" label="nombre" placeholder="Tenencia de la vivienda" inputId="relationship">
                    <template slot="no-options">
                        <span>No existe la opción</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-3">
                <label for="phone">Teléfono</label>
                <input v-model="family.phone" type="number" id="phone" name="phone" :class="classObject.phone" placeholder="Teléfono">
            </div>
            <div class="form-group col-md-3">
                <label for="schooling">Parentesco</label>
                <v-select v-model="family.relationship" :options="relationships" label="name" placeholder="Parentesco" inputId="relationship">
                    <template slot="no-options">
                        <span>No existe la opción</span>
                    </template>
                </v-select>
            </div>
            <div class="form-group col-md-6">
                <div class="cont-rad-aadf">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="checkbox" v-model="family.principal" id="customRadioInline1" class="custom-control-input" name="principal">
                        <label class="custom-control-label" for="customRadioInline1" >¿Es contacto principal ?</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="checkbox" v-model="family.speak" id="customRadioInline2" class="custom-control-input" name="speak">
                        <label class="custom-control-label" for="customRadioInline2"  >¿Vive con el nna ?</label>
                    </div>
                </div>          
            <!-- <pre>{{family}}</pre> -->
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" @click.prevent="addFamily">Agregar</button>
        </div>
        </div>
    </div>
    </div>
</template>

<script>
import { family } from '../../../utils/validators/Children/familyComposition'
import { mapState } from 'vuex';
export default {
    data() {
        return {
            family:{
                name:"",
                surname:"",
                secoundSurname:"",
                identification:"",
                dateBirth:"",
                schooling:null,
                civilStatus:null,
                city:null,
                sex:null,
                relationship:null,
                activitie:null,
                residenceLocality:null,
                neighborhood:null,
                address:"",
                housingType:null,
                ownership:null,
                phone:""
            },
            residence_locality:[],
            neighborhood:[],
            
            civilStatuses:[
                {id:1,name:"Soltero"},
                {id:2,name:"Casado"},
            ],
            relationships:[
                {id:1,name:"Hermano"},
                {id:2,name:"Padre"},
            ],
            
            housingTypes:[
                {id:1, nombre:"CASA"},
                {id:2, nombre:"APARTAMETO"},
            ],
            ownerships:[
                {id:1, nombre:"PROPIA"},
                {id:2, nombre:"EN ARRIENDO"},
            ],
        }
    },

    methods: {
        addFamily(){
            if (!this.$v.$invalid) {
                this.$emit("addFamily", this.family);
                this.family = {
                    name:"",
                    surname:"",
                    secoundSurname:"",
                    identification:"",
                    dateBirth:"",
                    schooling:null,
                    civilStatus:null,
                    city:null,
                    sex:null,
                    relationship:null,
                    activitie:null,
                    residenceLocality:null,
                    neighborhood:null,
                    address:"",
                    housingType:null,
                    ownership:null,
                    phone:""
                },
                $("#addFamily").modal("hide")
            }else{
                this.logMichin("Faltan datos por diligenciar")
            }
        },
        changeCity(city){
            if (city) {
                this.logMichin(city);
                this.residence_locality = city.residence_locality
            }
        },
        changeResidenceLocality(residenceLocality){
            if (residenceLocality) {
                this.neighborhood = residenceLocality.neighborhood
            }
        }
    },
    validations: {
        family
    },
    computed:{
        ...mapState(['sexs','cities', 'scholarships', 'familyOccupations']),
        ageCalculate() {
            if (this.family.dateBirth) {
                let fecha = this.family.dateBirth
                
                if (typeof fecha != "string" && fecha && esNumero(fecha.getTime())) {
                    fecha = formatDate(fecha, "yyyy-MM-dd");
                }

                var values = fecha.split("-");
                var dia = values[2];
                var mes = values[1];
                var ano = values[0];

                // cogemos los valores actuales
                var fecha_hoy = new Date();
                var ahora_ano = fecha_hoy.getYear();
                var ahora_mes = fecha_hoy.getMonth() + 1;
                var ahora_dia = fecha_hoy.getDate();

                // realizamos el calculo
                var edad = (ahora_ano + 1900) - ano;
                if (ahora_mes < mes) {
                    edad--;
                }
                if ((mes == ahora_mes) && (ahora_dia < dia)) {
                    edad--;
                }
                if (edad > 1900) {
                    edad -= 1900;
                }

                // calculamos los meses
                var meses = 0;

                if (ahora_mes > mes && dia > ahora_dia)
                    meses = ahora_mes - mes - 1;
                else if (ahora_mes > mes)
                    meses = ahora_mes - mes
                if (ahora_mes < mes && dia < ahora_dia)
                    meses = 12 - (mes - ahora_mes);
                else if (ahora_mes < mes)
                    meses = 12 - (mes - ahora_mes + 1);
                if (ahora_mes == mes && dia > ahora_dia)
                    meses = 11;

                // calculamos los dias
                var dias = 0;
                if (ahora_dia > dia)
                    dias = ahora_dia - dia;
                if (ahora_dia < dia) {
                    ultimoDiaMes = new Date(ahora_ano, ahora_mes - 1, 0);
                    dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
                }

                return edad + " años, " + meses + " meses"//  + dias + " días";
            }else{
                return ""
            }
        },
        classObject(){
            let errors = {}
            for (const key in this.$v.family.$params) {
                const element = this.$v.family[key];
                if (key != "schooling" && key != "civilStatus" && key != 'relationship' && key != 'activitie' && key != 'sex' && key != 'city' && key != 'residenceLocality' && key != 'neighborhood' && key != 'housingType' && key != 'ownership') {
                    if (element.$model[0] && element.$invalid ) {
                        errors[key] = {
                                'is-invalid':true,
                                'form-control':true,
                            }
                            
                    } else if(element.$model[0] && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            return errors
        }
    }
}
</script>