<template>
    <div>
        <div class="row">
            <div class="form-group col-md-2">
                <label for="icbfIncome">Fecha ingreso ICBF</label>
                <datetime v-model="stateProcess.icbfIncome" :auto="true" :input-class="classObject.icbfIncome" input-id="icbfIncome" placeholder="Fecha de ingreso ICBF" :max-datetime="now"></datetime>
            </div>

            <div class="form-group col-md-2">
                <label for="icbfIncomeNumber">No ingresos ICBF</label>
                <input v-model="stateProcess.icbfIncomeNumber" type="number" :class="classObject.icbfIncomeNumber" name="icbfIncomeNumber" id="icbfIncomeNumber" placeholder="Número de ingresos ICBF">
            </div>

            <div class="form-group col-md-2">
                <label for="hcmIncome">Fecha ingreso HCM</label>
                <datetime v-model="stateProcess.hcmIncome" :auto="true" :input-class="classObject.hcmIncome" input-id="hcmIncome" placeholder="Fecha de ingreso HCM"></datetime>
            </div>

            <div class="form-group col-md-2">
                <label for="resolutionType">Tipo resolución</label>
                <v-select v-model="stateProcess.resolutionType" :options="resolutionTypes" label="name" placeholder="Tipo de resolución" inputId="resolutionType">
                    <template slot="no-options">
                        <span>No existe el tipo de resolución</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-2">
                <label for="resolutionNumber">No resolución</label>
                <input v-model="stateProcess.resolutionNumber" type="number" :class="classObject.resolutionNumber" id="resolutionNumber" placeholder="Número de resolución">
            </div>

            <div class="form-group col-md-2">
                <label for="resolutionDate">Fecha resolución</label>
                <datetime v-model="stateProcess.resolutionDate" :auto="true" :input-class="classObject.resolutionDate" input-id="resolutionDate" placeholder="Fecha de resolución" :max-datetime="now"></datetime>
            </div>

            <div class="form-group col-md-4">
                <label for="familyCommissary">Comisaría</label>
                <v-select v-model="stateProcess.familyCommissary" :options="familyCurators" label="nombre" placeholder="Comisaría" inputId="familyCommissary">
                    <template slot="no-options">
                        <span>No existe registro</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="zonalCenter">Centro zonal</label>
                <v-select v-model="stateProcess.zonalCenter" :options="zonalCenters" label="nombre" placeholder="Centro zonal" inputId="zonalCenter">
                    <template slot="no-options">
                        <span>No existe registro</span>
                    </template>
                </v-select>
            </div>
            <div class="form-group col-md-4">
                <label for="defender">Defensor</label>
                <input v-model="stateProcess.defender" type="text" :class="classObject.defender" id="defender" placeholder="Defensor">
            </div>

            <div class="form-group col-md-4">
                <label for="residenceLocality">Localidad de residencia</label>
                <v-select v-model="stateProcess.residenceLocality" :options="residenceLocality" label="nombre" placeholder="Localidad de residencia" inputId="residenceLocality" @input="changeResidenceLocality">
                    <template slot="no-options">
                        <span>No existe la localidad</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="neighborhoodResidence">Barrio de residencia</label>
                <v-select v-model="stateProcess.neighborhood" :options="neighborhood" label="nombre" placeholder="Barrio de residencia" inputId="neighborhoodResidence">
                    <template slot="no-options">
                        <span>No existe el barrio</span>
                    </template>
                </v-select>
            </div>

            <div class="form-group col-md-4">
                <label for="reasonAdmission">Motivo de ingreso</label>
                <v-select v-model="stateProcess.reasonAdmission" :options="reasonAdmissions" label="nombre" placeholder="Motivo de ingreso" inputId="reasonAdmission">
                    <template slot="no-options">
                        <span>No existe el barrio</span>
                    </template>
                </v-select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 titulo-entrevistados">
                <h3>Descripción de ingreso</h3> 
                <hr>
            </div>
            <div class="form-group col-md-12">
                <label for="icbfDescription">Descripción ICBF</label>
                <textarea v-model="stateProcess.icbfDescription" id="icbfDescription" name="icbfDescription" :class="classObject.icbfDescription" placeholder="Descripción ICBF"></textarea>
            </div>

            <div class="form-group col-md-12">
                <label for="teamPsychosocial">Descripción equipo psicosocial</label>
                <textarea v-model="stateProcess.teamPsychosocial" id="team-psychosocial" name="team-psychosocial" :class="classObject.teamPsychosocial" placeholder="Descripción equipo psicosocial"></textarea>
            </div>

            <!-- <pre>{{ $v }}</pre> -->
        </div>
    </div>
</template>
<script>
import { mapActions, mapState } from 'vuex'
import { stateProcess } from '../../../utils/validators/Children/stateProcess'
export default {
    props:['residenceLocality'],
    data(){
        return {
            now:new Date().toISOString(),
            stateProcess:{
                icbfIncome:"",
                icbfIncomeNumber:"",
                hcmIncome:"",
                resolutionType:null,
                resolutionNumber:"",
                resolutionDate:"",
                residenceLocality:null,
                neighborhood:null,
                reasonAdmission:null,
                icbfDescription:"",
                teamPsychosocial:"",
                familyCommissary:null,
                zonalCenter:null,
                defender:""

            },
            resolutionTypes:[
                {id:1, name:"Vulnerabilidad"},
                {id:2, name:"Adoptabilidad"},
                {id:3, name:"Sin resolución"},
            ],
            neighborhood:[],
        }
    },
    mounted(){
        this.getReasonAdmissions()
    },
    methods: {
        ...mapActions(['getReasonAdmissions']),
        changeResidenceLocality(residenceLocality){
            if (residenceLocality) {
                this.neighborhood = residenceLocality.neighborhood
            }else{
                this.neighborhood = []
                this.stateProcess.neighborhood = null
            }
        }
    },
    validations:{
        stateProcess
    },
    computed: {
        ...mapState(['reasonAdmissions', 'familyCurators', 'zonalCenters']),
        classObject(){
            let errors = {}
            for (const key in this.$v.stateProcess.$params) {
                const element = this.$v.stateProcess[key];
                if (typeof element.$model != "object") {
                    if (element.$model.length >0 && element.$invalid ) {
                        errors[key] = {
                            'is-invalid':true,
                            'form-control':true,
                        }
                    } else if(element.$model.length >0 && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            this.$emit("changeStatus", {
                component:this.$options._componentTag,
                name : "estado del proceso",
                status:!this.$v.stateProcess.$invalid,
                data:this.stateProcess
            })
            return errors
        }
        
    }
}
</script>

<style>

    #vs15__listbox{
        z-index: 9999 !important;
    }
    
</style>