<template>
    <!-- Button trigger modal -->
    <!-- Modal -->
    <div class="modal fade" id="addDocumentType" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div role="document" class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title tit-modal" id="staticBackdropLabel">Agregar tipo de documento</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="row justify-content-center">
                <div class="form-group col-md-6">
                    <label for="document-type">Tipo de documento</label>
                    <v-select v-model="newDocumentType.documentType" :options="documentTypes" label="nombre" placeholder="Tipo de documento" inputId="document-type">
                        <template slot="no-options">
                            <span>No existe el tipo de documento</span>
                        </template>
                    </v-select>
                </div>
                <div class="form-group col-md-3">
                    <label for="document">Número de documento</label>
                    <input v-model="newDocumentType.document" type="number" id="document" name="document" :class="classObject.document" placeholder="Número de documento">
                </div>
                <div class="form-group col-md-3">
                    <label for="expedition-date">Fecha de expedición</label>
                    <datetime v-model="newDocumentType.expeditionDate" :auto="true" input-id="expedition-date" :input-class="classObject.expeditionDate" placeholder="Fecha de expedición" :max-datetime="now"></datetime>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12" v-if="documentTypesUser[0]">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tipo</th>
                                <th>Número</th>
                                <th>Expedición</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(doc, index) in documentTypesUser" :key="index">
                                <td>{{doc.documentType.nombre}}</td>
                                <td>{{doc.document}}</td>
                                <td>{{ doc.expeditionDate | moment("DD/MM/YYYY")}}</td>
                                <th>
                                    <button class="btn btn-sm btn-dager" @click.prevent="deleteDocumentType(index)"><i class="fas fa-trash-alt"></i></button>
                                </th>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class="modal-footer">
             <button type="button" class="btn btn-primary" @click.prevent="addDocumentType()"  :disabled="this.$v.newDocumentType.$invalid">Agregar</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        </div>
        </div>
    </div>
    </div>
</template>
<script>
import { mapState } from 'vuex'
import { newDocumentType } from '../../../utils/validators/Children/basicData'

export default {
    props:{
        documentTypesUser:{
            required:true,
            type:Array
        }
    },
    data() {
        return {
            now:new Date().toISOString(),
            newDocumentType:{
                documentType:null,
                document:"",
                expeditionDate:""
            }
        }
    },
    methods: {
        addDocumentType(){
            if (!this.$v.newDocumentType.$invalid) {
                this.$emit("addDocumentType", this.newDocumentType)
                this.newDocumentType = {
                    documentType:null,
                    document:"",
                    expeditionDate:""
                }

            }
        },
        deleteDocumentType(index){
            this.$emit("deleteDocumentType", index)
        }
    },
    validations:{
        newDocumentType
    },

    computed: {
        ...mapState(['documentTypes']),
        classObject(){
            let errors = {}
            for (const key in this.$v.newDocumentType.$params) {
                const element = this.$v.newDocumentType[key];
                if (key != "documentType") {
                    if (element.$model.length >0 && element.$invalid ) {
                        errors[key] = {
                                'is-invalid':true,
                                'form-control':true,
                            }
                            
                    } else if(element.$model.length >0 && element.$invalid == false){
                            errors[key] = {
                                'is-valid':true,
                                'form-control':true,
                            }
                    }else {
                        errors[key] = {
                            'form-control':true,
                        }
                    }
                }
            }
            return errors
        }
    },
}
</script>