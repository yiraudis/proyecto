<template>
    <div class="modal fade" id="report-list-show" tabindex="-1" role="dialog" aria-labelledby="report-list-showLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title tit-modal" id="report-list-showLabel">Listado de Evaluaciones y Reportes</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-md-12">
                <div class="cont-nna-report-list">
                  <div>Lulu Perez</div>
                  <div class="small text-muted"><span>15 años</span> | SIM: JSDD1547</div>
                </div>
              </div>  
               <div class="col-md-12">
                <div class="nav-tabs-boxed nav-tabs-boxed-left">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active " data-toggle="tab" href="#entry-evaluation-3" role="tab" aria-controls="entry-evaluation" aria-selected="false">Evaluaciones de ingreso</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link " data-toggle="tab" href="#evolution-report-3" role="tab" aria-controls="evolution-report" aria-selected="false"> Reportes de evolución </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-toggle="tab" href="#exit-evaluation-3" role="tab" aria-controls="exit-evaluation" aria-selected="false"> Evaluaciones de Egreso </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="entry-evaluation-3" role="tabpanel">
                          <div class="row">
                            <table class="table table-responsive-sm table-sm">
                                <thead>
                                  <tr>
                                    <th>ID</th>
                                    <th>Nombre Evaluación</th>
                                    <th>Platin</th>
                                    <th>Acciones</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>EV-0005</td>
                                    <td>Evaluación Individual</td>
                                    <td>Si</td>
                                    <td><a href="#">Ver</a></td>
                                  </tr>
                                  <tr>
                                    <td>EV-0005</td>
                                    <td>Evaluación Individual</td>
                                    <td>No</td>
                                    <td><a href="#">Ver</a></td>
                                  </tr>
                                  <tr>
                                    <td>EV-0005</td>
                                    <td>Evaluación Individual</td>
                                    <td>No</td>
                                    <td><a href="#">Ver</a></td>
                                   </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <div class="tab-pane" id="evolution-report-3" role="tabpanel">
                            
                        </div>
                         <div class="tab-pane" id="exit-evaluation-3" role="tabpanel">
                            
                        </div>
                    </div>
                </div>
             </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>    
          </div>
        </div>
      </div>
    </div>
</template>