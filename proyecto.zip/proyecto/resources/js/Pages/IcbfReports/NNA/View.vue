<template>
    <div class="row justify-content-center">
        <h5 class="text-center">
            <a href="/informe_nna" target="_blank" class="btn btn-primary"
                >Genrar reporte</a
            >
        </h5>
    </div>
</template>
