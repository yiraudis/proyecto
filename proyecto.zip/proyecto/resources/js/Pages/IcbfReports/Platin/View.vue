<template>
    <div class="fade-in">
      <div class="row">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <strong>Datos de Identidad</strong>
              <small>NNA</small>
            </div>
            <div class="card-body">
               <div class="row" v-if="platin">
                    <div class="form-group  col-md-4">
                        <label for="nna-name">Nombre del NNA</label>
                        <input class="form-control" :value="platin.nna.user.primer_nombre" id="nna-name" type="text" name="nna-name" disabled>
                    </div>
                    <div class="form-group  col-md-2">
                        <label for="ha_hsf">SIM</label>
                        <input  type="text" id="sim" name="sim" :value="platin.nna.sim" class="form-control" disabled placeholder="Número historia de atención">
                    </div>
                    <div class="form-group  col-md-2">
                        <label for="ha_hsf">N° HA/HSF</label>
                        <input  type="number" id="ha_hsf" name="ha_hsf" class="form-control" disabled placeholder="Número historia de atención">
                    </div>
                    <div class="form-group  col-md-4">
                        <label for="date-entry">Fecha de ingreso NNA</label>
                        <datetime  input-class="form-control" :value="platin.nna.fecha_ingreso" input-id="date-entry" placeholder="Fecha de Ingreso" disabled ></datetime>
                    </div>
                    <!-- <div class="form-group  col-md-2">
                        <label for="date-evaluation">Fecha de evaluación</label>
                        <datetime input-class="form-control" input-id="date-evaluation" placeholder="Fecha de evaluación"></datetime>
                    </div> -->
                </div>
            </div>
          </div>
        </div>
      </div>
      <DescriptionIcbf :platin="platin" @addDescription="getPlatin" @saveFinalizar="getPlatin" :workArea="work_area" :categoryPlatin="category_platin" />
    </div>
</template>
<script>
import SearchPanel from "../../Evaluations/Components/SearchPanel";
import IdentityData from "../Components/IdentityData";
import BigHead from "../Components/BigHead";
import DescriptionIcbf from "../Components/DescriptionIcbf";
import {platinById,getComplement} from '../../../utils/services/platin'

export default {
  components: {
    SearchPanel,
    IdentityData,
    BigHead,
    DescriptionIcbf
  },
  data(){
        return {
            platin:null,
            work_area:[],
            category_platin:[]
        }
    },
    mounted() {
        this.getComplements()
       this.getPlatin()
    },
    methods:{
        async getPlatin(){
            let loader = this.$loading.show();
            try {
                let data = await platinById(this.$route.params.id)
                this.platin = data

                this.category_platin.forEach(item => {
                    if (item.id == 1) { // diagnostico integral
                        item.description = this.platin.diagnostico_integral
                    }else if(item.id == 2){ // atencion idividual
                        item.description = this.platin.atencion_individual

                    }else if(item.id == 3){ // atencion familiar
                        item.description = this.platin.atencion_familiar

                    }else if(item.id == 4){ // atencion interinstitucional
                        item.description = this.platin.atencion_interinstitucional

                    }else if(item.id == 5){ // observaciones
                        item.description = this.platin.observaciones

                    }else if(item.id == 6){ //percepcion calidad
                        item.description = this.platin.percepcion_calidad

                    }
                });
                loader.hide()
            } catch (error) {
                loader.hide()
                console.log(error);
            }
        },
        async getComplements(){
            let loader = this.$loading.show();
            try {
                let data = await getComplement()

                this.work_area = data.work_area
                this.category_platin = data.category_platin



                console.log(data);
                // this.platin = data
                loader.hide()
            } catch (error) {
                loader.hide()
                console.log(error);
            }
        },
    }
};
</script>
