<template>
    <div class="fade-in">
      <div class="row">
          <div class="col-md-12">
            <div class="nav-tabs-boxed nav-tabs-boxed-left">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active tap-activos" data-toggle="tab" href="#active-lists-3" role="tab" aria-controls="active-lists" aria-selected="false"><i class="fas fa-edit"></i> Activos</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link tap-finalizados" data-toggle="tab" href="#finished-lists-3" role="tab" aria-controls="finished-lists" aria-selected="false"><i class="far fa-check-square"></i> Finalizados</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="active-lists-3" role="tabpanel">
                      <div class="row">
                        <div class=" form-group col-md-12">
                            <!-- <router-link tag="a" to="/admin/registro_nplatin"  class="btn btn-outline-success pull-right">
                              <i class="bnt-ico fas fa-plus-square"></i>Nuevo Platin
                            </router-link> -->
                        </div>
                        <div class="col-md-12">
                          <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid">
                            <thead>
                              <tr role="row">
                                <th class="sorting">Acciones</th>
                                <th class="sorting">N° Platin</th>
                                <th class="sorting">Estado</th>
                                <th class="sorting">Plazo</th>
                                <th class="sorting">NNA</th>
                                <th class="sorting">F. Entrega</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr role="row" class="odd" v-for="(item, index) in data_table" :key="index">
                                <template v-if="item.flujo_estados.finalizado != item.estado_id">
                                  <td>
                                    <router-link tag="a" :to="`/admin/gestionar_platin/${item.id}`"  class="btn btn-success btn-ver">
                                      <i class="fas fa-marker"></i>
                                    </router-link>
                                    <a class="btn btn-info btn-history" @click.prevent="viewLogPlatin(item)" ><i class="fas fa-history"></i></a>
                                  </td>
                                  <td class="sorting_1">PT-{{ item.codigo }}</td>
                                  <td><span class="badge badge-success">{{ item.estado.nombre }}</span></td>
                                  <td><span class="badge badge-success badge-plazo">{{ item.plazo }}</span></td>
                                  <td>{{ item.nna.user.primer_nombre }} {{ item.nna.user.primer_apellido }}</td>
                                  <td>{{ item.fecha_entrega }}</td>
                                </template>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane" id="finished-lists-3" role="tabpanel">
                        <div class="col-md-12">
                          <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid">
                            <thead>
                              <tr role="row">
                                <th class="sorting">Acciones</th>
                                <th class="sorting">N° Platin</th>
                                <th class="sorting">Estado</th>
                                <th class="sorting">NNA</th>
                                <th class="sorting">F. Creación</th>
                                <th class="sorting">F. Finalización</th>
                                <th class="sorting">F. Envió</th>
                              </tr>
                            </thead>
                            <tbody>
                              
                              <tr role="row" class="odd" v-for="(item, index) in data_table" :key="index">
                                <template v-if="item.flujo_estados.finalizado == item.estado_id">
                                  <td>
                                    <router-link tag="a" :to="`/admin/gestionar_platin/${item.id}`"  class="btn btn-success btn-ver">
                                      <i class="fas fa-marker"></i>
                                    </router-link>
                                    <a class="btn btn-info btn-history" @click.prevent="viewLogPlatin(item)" ><i class="fas fa-history"></i></a>
                                    <a class="btn btn-danger btn-descargar" target="_blank" :href="`/api/platin/download/${item.id}`" data-toggle="tooltip" data-html="true" data-original-title="<em>Tooltip</em> <u>with</u> <b>HTML</b>"><i class="fas fa-file-download"></i></a>
                                  </td>
                                  <td class="sorting_1">PT-{{ item.codigo }}</td>
                                  <td><span class="badge badge-success">{{ item.estado.nombre }}</span></td>
                                  <td>{{ item.nna.user.primer_nombre }} {{ item.nna.user.primer_apellido }}</td>
                                  <td>{{ item.fecha_creacion }}</td>
                                  <td>{{ item.fecha_finalizacion }}</td>
                                  <td></td>
                                
                                </template>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
      <EditReport :platin="platin"/>
    </div>
</template>
<script>
import EditReport from '../Components/EditReport'
import { listPlatin } from '../../../utils/services/platin'
export default {
   components:{
        EditReport
    },
   data(){
        return {
            platin:null,
            data_table : []
        }
    },
    mounted() {
        this.getPlatin()
    },
    methods:{
        viewLogPlatin(data){
            this.platin = data
            this.openModal("#edit-report")
        },
        async getPlatin(){
            let loader = this.$loading.show();
            try {
                let data = await listPlatin()
                this.data_table = data
                loader.hide()
            } catch (error) {
                loader.hide()
                console.log(error);
            }
        },
        
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        }
    }

}
</script>
