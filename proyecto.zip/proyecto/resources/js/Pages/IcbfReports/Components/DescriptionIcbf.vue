<template>
<div class="row" v-if="platin && platin.id">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <strong>Descripción</strong>
        <strong class="pull-right text-centerr">PT-{{ platin.codigo }} | vence: {{ platin.fecha_entrega }}<span class="span-estado-p">{{ platin.estado.nombre }}</span></strong>
      </div>
      <div class="card-body">
        <div class="row select-row-platin">
            <div class="col-md-6" v-if="platin.flujo_estados.finalizado != platin.estado_id && platin.flujo_estados.en_aprobacion != platin.estado_id">
                <div class="custom-control custom-switch" >
                    <input type="checkbox" v-model="complete" class="custom-control-input" id="customSwitches">
                    <label class="custom-control-label" for="customSwitches">Completo</label>
                </div>
            </div>
            <div class="col-md-6" v-if="platin.flujo_estados.finalizado != platin.estado_id && platin.flujo_estados.en_aprobacion == platin.estado_id">
                <div class="form-check">
                    <input v-model="aproved" class="form-check-input" type="radio" value="1" name="flexRadioDefault" id="flexRadioDefault1" />
                    <label class="form-check-label" for="flexRadioDefault1"> Aprobado </label>
                </div>
                <div class="form-check">
                    <input v-model="aproved" class="form-check-input" type="radio" value="0" name="flexRadioDefault" id="flexRadioDefault2" />
                    <label class="form-check-label" for="flexRadioDefault2"> No aprobado </label>
                </div>
            </div>
            <div class="col-md-6" v-if="platin.flujo_estados.finalizado == platin.estado_id">
                <a id="pdf-platin" target="_blank" :href="`/api/platin/download/${platin.id}`" class="btn btn-outline-danger pull-right btn-icbf-dt" type="button" aria-pressed="true"><i class="fas fa-download"></i> Generar PDF</a>
            </div>
        </div>
        <div class="row select-row-platin">
          <div class="col-md-5">
            <label for="work-area">Área de trabajo</label>
          <v-select v-model="data_save.work_area"  :options="workArea" label="name" placeholder="Seleccione un Área" inputId="work-area">
            <template slot="no-options">
                <span>No existe área</span>
            </template>
           </v-select>
          </div>
          <div class="col-md-5">
            <label for="category-platin">Categoría Platin</label>
            <v-select v-model="data_save.category_platin" @input="changeCategory"  :options="categoryPlatin" label="name" placeholder="Seleccione una categoría" inputId="category-platin">
                <template slot="no-options">
                    <span>No existe categoría</span>
                </template>
            </v-select>
          </div>
          <div class="col-md-2 mt-4" v-if="data_save.work_area && data_save.category_platin">
                <button @click.prevent = "uploadEvaluation"  v-if="validateEvaluation()" id="add-description-platin" class="btn btn-outline-success pull-right btn-icbf-dt btn-block" type="button" aria-pressed="true">
                  Cargar evaluación
                </button>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-12">
            <textarea @change="onChageDescription" :value="data_save.description"  class="form-control textarea-g" id="platin-description" name="platin-description" rows="6" placeholder=""></textarea>
          </div>
          <div class=" form-group col-md-12">
              <button v-if="platin.flujo_estados.finalizado != platin.estado_id" id="add-description-platin" @click.prevent="add" class="btn btn-outline-success pull-right btn-icbf-dt" type="button" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Agregar /Actualizar</button>
              <button id="add-description-platin" @click.prevent="openModal('#edit-report')" class="btn btn-outline-primary pull-right btn-icbf-dt" type="button" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Ver</button>
              <button v-if="complete || aproved" @click.prevent="finalizar" id="add-description-platin"  class="btn btn-outline-dark pull-right btn-icbf-dt" type="button" aria-pressed="true"><i class="bnt-ico fas fa-check-double"></i>Finalizar/Enviar</button>
          </div>
       
        </div>
      </div>
    </div>
  </div>
  <EditReport :platin="platin"/>
</div>
</template>
<script>
import EditReport from './EditReport'

import {saveDescription,saveFinalizar} from '../../../utils/services/platin'
export default {
    props:{
        platin:{
            type: Object,
            requred: false
        },
        workArea:{
            type: Array,
            requred: false
        },
        categoryPlatin:{
            type: Array,
            requred: false
        }
    },
   components:{
        EditReport
    },
   data(){
        return {
            data_save:{
                work_area:null,
                category_platin:null,
                description:null
            },
            complete:false,
            aproved:null

        }
    },
    methods:{
        editPlatin(){
            this.openModal("#edit-report", true)
        },
        changeCategory(){
            if (this.data_save.category_platin) {
                this.data_save.description = this.data_save.category_platin.description
            }
        },
        onChageDescription(e){
            this.data_save.description = e.target.value;
            console.log(e.target.value);
        },
        async add(){
            if (!this.data_save.work_area) {
                this.$swal({
                    icon: 'warning',
                    text: "Debe seleccionar area de trabajo"
                })
                return
            }else if (!this.data_save.category_platin) {
                 this.$swal({
                    icon: 'warning',
                    text: "Debe seleccionar una categoría"
                })
                return
            }else if (!this.data_save.description) {
                this.$swal({
                    icon: 'warning',

                    text: "La descripción es requerida"
                })
                return
            }

            this.data_save.id = this.platin.id
            let loader = this.$loading.show();
            try {
                let data = await saveDescription(this.data_save)
                if (data.status_transaction) {
                    this.data_save = {
                        work_area:null,
                        category_platin:null
                    }
                    this.$emit("addDescription")
                    this.$swal({
                        icon: 'success',
                        text: data.message
                    })
                }else{
                    this.$swal({
                        icon: 'error',
                        text: data.message
                    })
                }
                loader.hide()
            } catch (error) {
                loader.hide()
                console.log(error);
            }
        },

        async finalizar(){
            let data = {
                id: this.platin.id
            }
            if (this.aproved) {
                data.aproved = Number(this.aproved)
            }
            let loader = this.$loading.show();
            try {
                let resp = await saveFinalizar(data);
                
                if (resp.status_transaction) {
                    this.$emit("saveFinalizar")
                    this.$swal({
                        icon: 'success',
                        text: resp.message
                    })
                    this.complete = false
                    this.aproved = null
                }else{
                    this.$swal({
                        icon: 'error',
                        text: resp.message
                    })
                }
                loader.hide()
            } catch (e) {
                loader.hide()
                console.log(e);
            }
            // alert('finaliar');
        },

        uploadEvaluation(){
            if(this.data_save.work_area.id == 4){ // psicologico
                let filter = this.platin.categories_psicologica.filter(item => item.id == this.data_save.category_platin.id)
                if(filter.length > 0){
                    let description = `${this.data_save.description} ${filter[0].description}`
                    this.data_save.description = description
                    console.log(description)

                }   
            }
        },

        validateEvaluation(){
            if(this.data_save.work_area.id == 4 || this.data_save.work_area.id == 5){
                if (this.data_save.category_platin.id == 1 || this.data_save.category_platin.id == 2 || this.data_save.category_platin.id == 3 || this.data_save.category_platin.id == 4) {
                    return true
                }
            }
            return false
        },
        openModal(id, hide){
            if (!hide) {
                $(id).modal("show")
            }else{
                $(id).modal("hide")
            }
        }
    }
}
</script>


