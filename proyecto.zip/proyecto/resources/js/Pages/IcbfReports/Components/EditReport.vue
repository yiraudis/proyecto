<template>
    <div class="modal fade" id="edit-report" tabindex="-1" role="dialog" aria-labelledby="edit-reportLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title tit-modal" id="edit-reportLabel">Detalles PLATIN</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" v-if="platin && platin.id">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                   <div class="cont-family-detalles">
                    <div class="row">
                      <div class="col-md-6">
                        <div>{{ platin.nna.user.primer_nombre }} {{ platin.nna.user.primer_apellido }}</div>
                        <div class="small text-muted"><span>{{ platin.nna.user.edad }} años</span> | SIM: {{ platin.nna.sim }}</div>
                      </div>
                      <div class="col-md-6">
                        <strong class="pull-right text-centerr" style="margin-right: 24px;">PT-{{ platin.codigo }} | vence: {{ platin.fecha_entrega }}<span class="span-estado-p">{{ platin.estado.nombre }}</span></strong>
                      </div>
                    </div>
                  </div>
                  <div class="card-body">
                    <!-- <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">3. Motivo de ingreso <small>(referido por la Autoridad Administrativa)</small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {de donde se llena el motivo de ingreso ?}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             
                          </div>
                        </div>
                      </div>
                    </div> -->
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Diagnostico integral <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.diagnostico_integral }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 1">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                            <!--  <span>Evaluación <a href="#">EV-00185</a></span>
                             <span>Psicologia</span> -->
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Atenciones a realizar (INDIVIDUAL) <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.atencion_individual }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 2">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Atenciones a realizar (FAMILIARES) <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.atencion_familiar }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr" >
                              <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 3">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Atenciones a realizar (INTERINSTITUCIONAL) <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.atencion_interinstitucional }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 4">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Observaciones <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.atencion_observaciones }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 5">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <h5 class="tit-item">Percepcio de calidad <small></small></h5>
                        <div class="row">
                          <div class="col-md-8 del-report-text">
                           <p>
                             {{ platin.percepcion_calidad }}
                           </p>
                          </div>
                          <div class="col-md-4 del-report-usr">
                             <template v-for="(item) in platin.log_platin" >
                                <div v-if="item.categoria_platin_id == 6">
                                  <h6> {{ item.user.primer_nombre }}</h6>
                                  <h6>psicologa</h6>
                                  <span>{{item.fecha_creacion}}</span>
                                  <hr> 
                                </div>
                              </template>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
</template>
<script>
export default {
    props:{
        platin:{
            type: Object,
            requred: false
        }
    },
}
</script>
