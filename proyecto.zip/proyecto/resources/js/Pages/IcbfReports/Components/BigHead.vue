<template>
	<div class="col-md-12">
		<div class="card border-success card-icbf-cabezote">
	    	<div class="card-header">
	    		<div class="row">
		    		<div class="col-md-2 logo-icbf-cabezote">
		    			<img
	                      class=""
	                      :src="icbf.logo_png"
	                      alt="ICBF"
	                    />
		    		</div>
		    		<div class="col-md-6 tit-icbf-cabezote">
		    			<h5 class="principal">PROCESO PROTECCIÓN</h5>
		    			<h5>PLAN DE ATENCIÓN INTEGRAL</h5>
		    			<h5>RESTABLECIMIENTO DE DERECHOS</h5>
		    		</div>
		    		<div class="col-md-2 cuadriculas-icbf-cabezote">
		    			<div class="col-md-12 sub-c">
		    				<h6>F1.LM1.P</h6>	
		    			</div>
		    			<div class="col-md-12 sub-c">
		    				<h6>Versión 2</h6>
		    			</div>		    			
		    		</div>
		    		<div class="col-md-2 cuadriculas-icbf-cabezote">
		    			<div class="col-md-12 sub-c">
		    				<h6>17/01/2019</h6>	
		    			</div>
		    			<div class="col-md-12 sub-c">
		    				<h6>Página 1 de 2</h6>
		    			</div>		    			
		    		</div>
	    		</div>	    		
	    	</div>
		</div>
	</div>      	
</template>
<script>
export default {
  components: {
    // Chat
  },
  data() {
    return {
         icbf:{
          logo_jpg:"/images/icbf/logo.jpg",
          logo_png:"/images/icbf/icbf-logo.png"
        }
    };
  },
  computed: {
    
  }
};
</script>
