<template>
   <div class="row">
        <div class="form-group  col-md-4">
          <label for="nna-name">Nombre del NNA</label>
          <input class="form-control" id="nna-name" type="text" name="nna-name">
        </div>
        <div class="form-group  col-md-2">
          <label for="ha_hsf">SIM</label>
            <input  type="number" id="sim" name="sim" class="form-control" placeholder="Número historia de atención">
        </div>
        <div class="form-group  col-md-2">
          <label for="ha_hsf">N° HA/HSF</label>
            <input  type="number" id="ha_hsf" name="ha_hsf" class="form-control" placeholder="Número historia de atención">
        </div>
        <div class="form-group  col-md-2">
         <label for="date-entry">Fecha de ingreso NNA</label>
            <datetime  input-class="form-control" input-id="date-entry" placeholder="Fecha de Ingreso" disabled ></datetime>
        </div>
        <div class="form-group  col-md-2">
         <label for="date-evaluation">Fecha de evaluación</label>
            <datetime input-class="form-control" input-id="date-evaluation" placeholder="Fecha de evaluación"></datetime>
        </div>
    </div>
</template>
<script>
export default {


}
</script>


