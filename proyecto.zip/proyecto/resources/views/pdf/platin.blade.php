<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    {{-- <link href="css/bootstrap.min.css" rel="stylesheet"> --}}
    {{--  <link rel="stylesheet" href="{{asset('css/michin.min.css')}}">  --}}


    <style>
        @page {
            margin: 0cm 0cm;
            /*font-family: Arial;*/
        }



        .page-break { /*Generar una nueva pagina con esta clase*/
            page-break-after: always;
        }

        body {
            margin: 3cm 2cm 2cm;
        }

        header {
            position: fixed;
            left: 0cm;
            right: 0cm;
            height: 10cm;
            margin: auto;
            /*background-color: #2a0927;
            color: white;*/
            text-align: center;
            line-height: 30px;
            margin-bottom: 10px;
        }

        #table_header {
            height: 120px;
            width: 100%;
        }
        .cnter_td {
            text-align: center
        }



        footer {
            position: fixed;
            bottom: 0cm;
            left: 0cm;
            right: 0cm;
            height: 2cm;
            
            text-align: center;
            line-height: 35px;
        }

        .encabezado, .datos_3 {
            border: solid 1px black;
            text-align: center;
            border-collapse: collapse;
        }
        .encabezado td{
            border: solid 1px;
        }
        .encabezado, .datos_1, .datos_2, .datos_3{
            width: 100%; /*1000px;*/
        }
        .datos_1{
            border: solid 2px black;text-align: center; border-collapse: collapse;
        }
        .datos_1 td, .datos_2 td, .datos_1 th{
            border: solid 2px black;
        }
        .datos_1 td, .datos_2 td{
            padding: 1px;
        }
        .datos_1 th, .datos_2 th{
            background: #e6e6e6;
        }
        .datos_2{
            text-align: center; 
            border-collapse: collapse;
            border-left: solid 2px black;
            border-right: solid 2px black;
            border-bottom: solid 2px black;
        }
        .datos_2 th{
            border-left: solid 2px black;
            border-right: solid 2px black;
            border-bottom: solid 2px black;   
        }
        .datos_3 td{
            height: 100px;
        }
        .texto_final{
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        {{--  <div class="row justify-content-center">  --}}
            <table class="encabezado">
                <tr>
                    <td rowspan=2>
                        <img src="{{asset('/images/descargar.png')}}" width="70px">
                    </td>
                    <td rowspan=2>
                        <b>PROCESO PROTECCIÓN</b>
                        <br>
                        PLAN DE ATENCIÓN INTEGRAL
                        <br>
                        RESTABLECIMIENTO DE DERECHOS
                    </td>
                    <td>
                        <b>F1.LM1.P</b>
                    </td>
                    <td>
                        <b>F1.LM1.P</b>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>17/01/2019</b>
                    </td>
                    <td>
                        <b>Página 1 de 2</b>
                    </td>
                </tr>
            </table>
            <br><br><br><br><br>
        {{--  </div>  --}}
    </header>


    <main >
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>1. Datos del niño, niña o adolescente</b>
        <br>
        <table class="datos_1">
            <tr>
                <th>Nombres y apellidos del niño, niña o adolescente:</th>
                <th>Tipo identificación:</th>
                <th>Número:</th>
                <th>Número SIM:</th>
            </tr>
            <tr>
                <td>{{ $platin->nna->user->fullname }}</td>
                <td>{{ $platin->nna->user->identification->tipo }}</td>
                <td>{{ $platin->nna->user->identification->identificacion }}</td>
                <td>{{$platin->nna->sim}}</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Fecha de nacimiento:</th>
                <th>Ciudad de nacimiento:</th>
                <th>Departamento:</th>
                <th>País:</th>
                <th>Nacionalidad:</th>
            </tr>
            <tr>
                <td>{{$platin->nna->user->fecha_nacimiento}}</td>
                <td>{{$platin->nna->user->nacimiento->municipio}}</td>
                <td>{{$platin->nna->user->nacimiento->departamento}}</td>
                <td>{{$platin->nna->user->nacimiento->pais}}</td>
                <td>{{$platin->nna->user->nacimiento->nacionalidad}}</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Edad:</th>
                <th>Sexo:</th>
                <th>Pertenencia étnica:</th>
                <th>Fecha de apertura PARD:</th>
                <th>Fecha de ingreso a la institución y modalidad:</th>
            </tr>
            <tr>
                <td>{{ $platin->nna->user->edad }}</td>
                <td>{{ isset($platin->nna->user->sexo) ? $platin->nna->user->sexo->nombre : "" }}</td>
                <td>{{ isset($platin->nna->user->grupo_etnico) ? $platin->nna->user->grupo_etnico->name : '' }}</td>
                <td>{{$platin->nna->fecha_ingreso_icbf}}</td>
                <td>{{ $platin->nna->fecha_ingreso }}</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Nombre autoridad administrativa:</th>
                <th>Persona de contacto:</th>
                <th>Parentesco:</th>
                <th>Dirección:</th>
                <th>Teléfono/Celular:</th>
            </tr>
            <tr>
                <td>{{$platin->nna->defensor}}</td>
                <td>{{ isset($platin->nna->contacto->fullname) ? $platin->nna->contacto->fullname : ""  }}</td>
                <td>{{ isset($platin->nna->contacto->parentesco) ? $platin->nna->contacto->parentesco : ""  }}</td>
                <td>{{ isset($platin->nna->contacto->direccion) ? $platin->nna->contacto->direccion : ""  }}</td>
                <td>{{ isset($platin->nna->contacto->telefono) ? $platin->nna->contacto->telefono : ""  }}</td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>2. Datos del niño, niña o adolescente</b>
        <table class="datos_1">
            <tr>
                <th>Regional:</th>
                <th>Centro zonal:</th>
                <th>Ciudad/Municipio: </th>
                <th>Nombre autoridad administrativa:</th>
            </tr>
            <tr>
                <td>{{ $platin->nna->regional_ha}}</td>
                <td>{{ isset($platin->nna->zonal_center ) ? $platin->nna->zonal_center->nombre : "" }}</td>
                <td>Bogotá</td>
                <td>{{$platin->nna->defensor}}</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Modalidad de atención:</th>
                <th>Población: </th>
                <th>No. Contrato:</th>
            </tr>
            <tr>
                <td>INTERNADO</td>
                <td>NNA ENTRE LOS 2 Y 18 AÑOS</td>
                <td>1385/2018</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Operador / Institución: Sede:</th>
                <th>Sede:</th>
                <th>Teléfono: </th>
                <th>Dirección:</th>
            </tr>
            <tr>
                <td>HOGARES CLUB MICHIN</td>
                <td>{{$platin->nna->nna_house->house->nombre}}</td>
                <td>4909503</td>
                <td>CAR 74a N 72a -21</td>
            </tr>
        </table>
        <table class="datos_2">
            <tr>
                <th>Responsable del programa:</th>
                <th>Correo electrónico:</th>
                <th>Fecha elaboración informe:</th>
            </tr>
            <tr>
                <td>TUTH AIDE GUADA</td>
                <td>michin@hogaresclubmichin.com</td>
                <td>Impreso 30 dias sin importar fecha cierre</td>
            </tr>
        </table>
        {{--  <div class="page-break"></div>  --}}
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>3. Motivo de ingreso (referido por la Autoridad Administrativa) </b>
        <table class="datos_3">
            <tr>
                <td>
                    {{ $platin->nna->descripcion_ingreso_icbf }}
                </td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>4. Diagnóstico integral. Incluir problemáticas asociadas</b> (Ej. Consumo de sustancias psicoactivas, situación de vida en calle, entre otras)
        <table class="datos_3">
            <tr>
                <td>{{ $platin->diagnostico_integral }}</td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>5. Atenciones a realizar</b>(Corresponden a las acciones que se van en realizar en conjunto con los niños, niñas, adolescentes y sus familias, 
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;y tiene como meta superar las situaciones que dieron origen al ingreso del niño, niña o adolescentes al PARD.)
        <table class="datos_1">
            <tr>
                <th rowspan=2>INDIVIDUAL</th>
                <th colspan=2>REDES DE APOYO</th>
            </tr>
            <tr>
                <th>FAMILIARES</th>
                <th>INTERINSTITUCIONALES</th>
            </tr>
            <tr>
                <td>{{ $platin->atencion_individual }}</td>
                <td>{{ $platin->atencion_familiar }}</td>
                <td>{{ $platin->atencion_interinstitucional }}</td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>6. Observaciones</b>
        <table class="datos_3">
            <tr>
                <td>{{ $platin->observaciones }}</td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>7. Percepción de la calidad del servicio del niño, niña, adolescente, su familia y/o red vincular de apoyo</b>
        <table class="datos_3">
            <tr>
                <td>{{ $platin->percepcion_calidad }}</td>
            </tr>
        </table>
        <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>8. Firmas</b>
        <table class="datos_1">
            <tr>
                <th>Persona</th>
                <th>Nombre</th>
                <th>Firma</th>
            </tr>
            <tr>
                <td>Coordinador de la modalidad</td>
                <td><b>RUT AIDE GUANA</b></td>
                <td></td>
            </tr>
        </table>
        <br><br>
    </main>

   

    <footer>
        <div class="texto_final">
            <b>Antes de imprimir este documento… piense en el medio ambiente!</b>
            <br>
            Cualquier copia impresa de este documento se considera como COPIA NO CONTROLADA.
            <br>
            LOS DATOS PROPORCIONADOS SERAN TRATADOS DE ACUERDO A LA POLITICA DE TRATAMIENTO DE DATOS PERSONALES DEL ICBF Y A LA LEY 1581 DE 2012
        </div>
    </footer>
</body>
</html>