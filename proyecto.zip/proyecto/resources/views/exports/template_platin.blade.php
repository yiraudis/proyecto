<table border="1">
    <thead>
        <tr>
            <th>SIM</th>
            <th>APELLIDO 1</th>
            <th>APELLIDO 2</th>
            <th>NOMBRES</th>
            <th>FECHA NACIMIENTO</th>
            <th>EDAD</th>
            <th>IDENTIFICACION</th>
            <th>FECHA DE INGRESO</th>
            <th>NOMBRE DEL CENTRO ZONAL  ICBF</th>
            <th>NOMBRE DEL DEFENSOR DE FAMILIA ICBF</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $key => $item)
            <tr>
                <td>SIM</td>
                <td>{{$item->primer_apellido}}</td>
                <td>{{$item->segundo_apellido}}</td>
                <td>{{$item->nombres}}</td>
                <td>{{$item->fecha_nacimiento}}</td>
                <td>{{ age($item->fecha_nacimiento) }}</td>
                <td>{{$item->identificacion}}</td>
                <td>{{$item->fecha_ingreso}}</td>
                <td>{{$item->zonal}}</td>
                <td>{{$item->defensor}}</td>
            </tr>
        @endforeach
    </tbody>
</table>