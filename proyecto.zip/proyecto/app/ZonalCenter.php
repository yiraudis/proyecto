<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ZonalCenter extends Model
{
    protected $table = "centros_zonales";
    protected $guarded = [];

    public function city(){
        return $this->belongsTo(City::class,'municipio_id');
    }
}
