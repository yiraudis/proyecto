<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HousingType extends Model
{
    protected $table = "tipo_viviendas";
    protected $guarded = [];
}
