<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MapaPertenencia extends Model
{
    protected $table = "mapa_pertenencia";
    protected $guarded = [];
}
