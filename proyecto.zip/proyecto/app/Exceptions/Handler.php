<?php

namespace App\Exceptions;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Throwable  $exception
     * @return void
     *
     * @throws \Exception
     */
    public function report(Throwable $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Throwable  $exception
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @throws \Throwable
     */
    public function render($request, Throwable $exception)
    {
        // Execpciones de los from request
        if ($exception instanceof ValidationException) {            
            return response()->json($exception->errors(), $exception->status);
        }else if($exception instanceof NotFoundHttpException){
            // La url no existe
            return response()->json(['error' => "El recurso no existe."]);
        }else if($exception instanceof AuthorizationException){
            // La url no existe
            return  [
                'code'=> 401,
                'error' => "No autorizado"
            ];
        }else if($exception instanceof RouteNotFoundException){
            // La url no existe
            return [
                'code'=> 401,
                'error'=>$exception->getmessage(),
            ];
        }

        return parent::render($request, $exception);
    }
}
