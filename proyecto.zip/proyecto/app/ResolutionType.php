<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResolutionType extends Model
{
    protected $table = "tipos_resolucion";
    protected $guraded = [];
}
