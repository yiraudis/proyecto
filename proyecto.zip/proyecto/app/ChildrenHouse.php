<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChildrenHouse extends Model
{
    protected $table = "nna_casas";
    protected $guarded = [];


    public function house(){
        return $this->belongsTo(House::class,'casa_id');
    }

    public function children (){
        return $this->belongsTo(Children::class,'nna_id');
    }

}
