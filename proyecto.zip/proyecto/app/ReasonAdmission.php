<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReasonAdmission extends Model
{
    protected $table = "motivos_ingreso";
    protected $guarded = [];
}
