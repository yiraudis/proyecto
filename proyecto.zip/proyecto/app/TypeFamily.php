<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeFamily extends Model
{
    protected $table = "tipos_familia";
    protected $guarded = [];
}
