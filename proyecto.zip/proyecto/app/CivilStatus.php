<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CivilStatus extends Model
{
    protected $table = "estados_civiles";
    protected $guarded = [];
}
