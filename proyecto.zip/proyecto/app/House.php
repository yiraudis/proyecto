<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class House extends Model
{
    protected $table = "casas";
    protected $guarded = [];

    public function status(){
        return $this->belongsTo(Status::class,'estado_id');
    }

    public function plant_coordinator(){
        return $this->belongsTo(User::class,'coordinador_planta_id');
    }

    public function relief_coordinator(){
        return $this->belongsTo(User::class,'coordinadora_relevo_id');
    }

    public function sex(){
        return $this->belongsTo(Sex::class,'genero_id');
    }
}
