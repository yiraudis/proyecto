<?php

namespace App\Http\Controllers;

use App\AreaTrabajo;
use App\CategoriaPlatin;
use App\EvaSocialIndividual;
use App\EvaSocioFamiliar;
use App\Goals;
use App\Http\Traits\Globals;
use App\InformeEvolucion;
use App\LogPlatin;
use App\LogPlatinEstado;
use App\PsicoIndividual;
use App\PsicoIndividualFamiliar;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PlatinController extends Controller
{
    use Globals;
    public function listPlatin(){
        $platin = InformeEvolucion::with(['estado','nna.user','log_platin.area_trabajo','log_platin.user'])
        ->whereTipo(0)->get();
        return $platin;
    }

    public function platinById($id){

        // dd(Auth::id());
        // Incluir la información de cada evaluación, necesaria para cada category platin
        //psicologícos
        $integral = "";
        $atencion_individual = "";
        $atencion_familiar = "";
        $atencion_inter = "";
        $platin =  InformeEvolucion::with(['nna.user','estado','log_platin.area_trabajo','log_platin.user'])
        ->whereTipo(0)
        ->find($id);

        //categorias psicologicas
        $ev_psico_individual = PsicoIndividual::where('nna_id',$platin->nna_id)->whereEstado_id($this->active_status)->first();
        if(isset($ev_psico_individual)){
            $integral = "$ev_psico_individual->percepcion_ingreso $ev_psico_individual->antecedentes $ev_psico_individual->examen_mental $ev_psico_individual->afectividad $ev_psico_individual->percepcion_niño $ev_psico_individual->prospectiva $ev_psico_individual->adaptacion $ev_psico_individual->resultado_prueba $ev_psico_individual->lectura";
            $psico_metas = Goals::whereIn('model', [PsicoIndividual::class, PsicoIndividualFamiliar::class])->whereModelId($ev_psico_individual->id)->whereEstadoId($this->active_status)->get();
            foreach ($psico_metas as $key => $meta) {
                if ($meta->categoria_metas_id == 1) { // familiar
                    $atencion_familiar .= " $meta->descripcion";
                }else if ($meta->categoria_metas_id == 2) { // Inter
                    $atencion_inter .= " $meta->descripcion";
                }else if ($meta->categoria_metas_id == 3) { // Individual
                    $atencion_individual .= " $meta->descripcion";
                }
            }
        }
        $ev_psico_familiar = PsicoIndividualFamiliar::where('nna_id',$platin->nna_id)->whereEstado_id($this->active_status)->first();
        if(isset($ev_psico_familiar)){
            $integral .= " $ev_psico_familiar->percepcion_ingreso $ev_psico_familiar->cataracteristicas $ev_psico_familiar->evento_significativo $ev_psico_familiar->sistema_creencia $ev_psico_familiar->genereatividad $ev_psico_familiar->vulnerabilidad $ev_psico_familiar->lectura";
        }
        $data_psico_category = [
            [
                "id" => 1,
                "description" => $integral, //Diagnostico integral
            ],
            [
                "id" => 2,
                "description" => trim($atencion_individual), //Atencion individual
            ],
            [
                "id" => 3,
                "description" => trim($atencion_familiar), //atencion familiar
            ],
            [
                "id" => 4,
                "description" => trim($atencion_inter), //atencion interinstitucional
            ],
        ];
        $platin->categories_psicologica = $data_psico_category;

        // Categorias sociales
        $integral = "";
        $atencion_individual = "";
        $atencion_familiar = "";
        $atencion_inter = "";
        $ev_social_individual = EvaSocialIndividual::where('nna_id',$platin->nna_id)->whereEstadoId($this->active_status)->first();
        if(isset($ev_social_individual)){
            $integral .= " $ev_social_individual->vida_saludable $ev_social_individual->desarrollo_potenciales $ev_social_individual->motivo_ingreso $ev_social_individual->observaciones_factores $ev_social_individual->dianamica_familiar $ev_social_individual->socio_economica $ev_social_individual->expectativas $ev_social_individual->impresiones";
            $social_metas = Goals::whereIn('model', [EvaSocialIndividual::class, EvaSocioFamiliar::class])->whereModelId($ev_social_individual->id)->whereEstadoId($this->active_status)->get();
            foreach ($social_metas as $key => $meta) {
                if ($meta->categoria_metas_id == 1) { //  familiar
                    $atencion_familiar .= " $meta->descripcion";
                }else if ($meta->categoria_metas_id == 2) { // Inter
                    $atencion_inter .= " $meta->descripcion";
                }else if ($meta->categoria_metas_id == 3) { // Individual
                    $atencion_individual .= " $meta->descripcion";
                }
            }

            $ev_socio_fmiliar = EvaSocioFamiliar::where('nna_id',$platin->nna_id)->whereEstadoId($this->active_status)->first();
            if(isset($ev_socio_fmiliar)){
                $integral .= " $ev_socio_fmiliar->motivo_ingreso $ev_socio_fmiliar->historia_vida $ev_socio_fmiliar->dianamica_familiar $ev_socio_fmiliar->socio_economica $ev_socio_fmiliar->apoyo_familiar $ev_socio_fmiliar->apoyo_social $ev_socio_fmiliar->mapa_actual $ev_socio_fmiliar->mapa_potencial $ev_socio_fmiliar->proyecto $ev_socio_fmiliar->observacion_compromiso";
            }

            $data_social_category = [
                [
                    "id" => 1,
                    "description" => $integral, //Diagnostico integral
                ],
                [
                    "id" => 2,
                    "description" => trim($atencion_individual), //Atencion individual
                ],
                [
                    "id" => 3,
                    "description" => trim($atencion_familiar), //atencion familiar
                ],
                [
                    "id" => 4,
                    "description" => trim($atencion_inter), //atencion interinstitucional
                ],
            ];

            
            $platin->categories_social = $data_social_category;
            // dd($platin);
        }
        return $platin;
    }

    public function getComplement(){
        return [
            'work_area' => AreaTrabajo::all(),
            'category_platin' => CategoriaPlatin::all(),
        ];
    }

    public function saveDescription(Request $request){
        $status = false;
        $message = "Descripción agregada";
        DB::beginTransaction();
        try {
            $user_id = Auth::id();
            $platin = InformeEvolucion::where('id',$request->id)->where('tipo',0)->first();
            if (isset($platin) && isset($request->category_platin) && $request->work_area) {
                if ($request->category_platin['id'] == 1) { // diagnostico integral
                    $platin->diagnostico_integral = $request->description;
                }else if ($request->category_platin['id'] == 2) { // atencion individual
                    $platin->atencion_individual = $request->description;
                }else if ($request->category_platin['id'] == 3) { // atencion familiar
                    $platin->atencion_familiar = $request->description;
                }else if ($request->category_platin['id'] == 4) { // atencion INTERINSTITUCIONALES
                    $platin->atencion_interinstitucional = $request->description;
                }else if ($request->category_platin['id'] == 5) { // observaciones
                    $platin->observaciones = $request->description;
                }else if ($request->category_platin['id'] == 6) { // percepcion calidad
                    $platin->percepcion_calidad = $request->description;
                }
                if ($platin->estado_id == $this->creado_status) {
                    $platin->estado_id = $this->desarrollo_status;

                    $log_estado = new LogPlatinEstado;
                    $log_estado->user_id = isset($user_id) ? $user_id : 1;
                    $log_estado->informe_evolucion_id = $platin->id;
                    $log_estado->estado_id = $platin->estado_id;
                    $log_estado->save();
                }
                $platin->save();


                //guardar log
                
                LogPlatin::create([
                    'user_id' => isset($user_id) ? $user_id : 1,
                    'informe_evolucion_id' => $platin->id,
                    'area_trabajo_id' => $request->work_area['id'],
                    'categoria_platin_id' => $request->category_platin['id'],
                ]);

            }else{
                return [
                    'code' => $this->error,
                    'status_transaction' => $status,
                    'message' => "Datos incompletos"
                ];
            }
            DB::commit();
            $status = true;
        } catch (\Throwable $th) {
            DB::rollback();
            $message = $th->getMessage();
        }

        if ($status) {
            return [
                'code' => $this->success,
                'status_transaction' => $status,
                'message' => $message
            ];
        }else{
            return [
                'code' => $this->error,
                'status_transaction' => $status,
                'message' => $message
            ];
        }

    }

    public function finalizar(Request $request){

        if(!isset($request->id)){
             return [
                'code' => $this->error,
                'status_transaction' => false,
                'message' => "El platin es requerido"
            ];
        }
        $status = false;
        $message = "Proceso finalizado";
        try {
            $user_id = Auth::id();
            $platin = InformeEvolucion::where('id',$request->id)->where('tipo',0)->first();
            if(isset($platin)){ 
                if ($platin->estado_id == $this->finalizado_status) {
                    return [
                        'code' => $this->error,
                        'status_transaction' => $status,
                        'message' => "No es posible cambiar de estado, el platin ya se encuentra finalizado"
                    ];
                }
                if($platin->estado_id == $this->desarrollo_status){
                    $platin->estado_id = $this->psicologia_status;
                }else if($platin->estado_id == $this->psicologia_status){
                    $platin->estado_id = $this->social_status;
                }else if($platin->estado_id == $this->social_status){
                    $platin->estado_id = $this->en_aprobacion_status;
                }else if($platin->estado_id == $this->en_aprobacion_status && $request->aproved == 1){
                    $platin->estado_id = $this->finalizado_status;
                }else if($platin->estado_id == $this->en_aprobacion_status && $request->aproved == 0){
                    $platin->estado_id = $this->en_ajuste_status;
                }else if($platin->estado_id == $this->en_ajuste_status){
                    $platin->estado_id = $this->en_aprobacion_status;
                }

                $platin->save();

                $log_estado = new LogPlatinEstado;
                $log_estado->user_id = isset($user_id) ? $user_id : 1;
                $log_estado->informe_evolucion_id = $platin->id;
                $log_estado->estado_id = $platin->estado_id;
                $log_estado->save();

                $status = true;
            }else{
                $message = "No se encontró platin";

            }
            
        } catch (\Throwable $th) {
            $message = $th->getMessage();
        }

        if ($status) {
            return [
                'code' => $this->success,
                'status_transaction' => $status,
                'message' => $message
            ];
        }else{
            return [
                'code' => $this->error,
                'status_transaction' => $status,
                'message' => $message
            ];
        }
    }

    public function download($id){
        $platin = InformeEvolucion::with(['nna.user.sexo','nna.nna_house.house'])
        ->whereTipo(0)
        ->find($id);

        // dd($platin->nna->nna_house->house);
        $data = [
            'platin' => $platin
        ];
        // return $platin->nna;
        // return view("pdf.platin",$data);
        $pdf = \PDF::loadView('pdf.platin', $data);

        return $pdf->stream('archivo.pdf');

        dd($platin);

    }
}
