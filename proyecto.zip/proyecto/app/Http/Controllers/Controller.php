<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public $active_status = 1;
    public $inactive_status = 2;
    public $creado_status = 3;
    public $desarrollo_status = 4;
    public $psicologia_status = 5;
    public $social_status = 6;
    public $en_aprobacion_status = 7;
    public $finalizado_status = 8;
    public $en_ajuste_status = 9;

    public function prueba(){

    }
}
