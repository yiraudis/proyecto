<?php

namespace App\Http\Controllers;

use App\Area;
use App\AreaTrabajo;
use App\Arl;
use App\BloodGroup;
use App\CategoriaPlatin;
use App\CategoryGoals;
use App\City;
use App\CivilStatus;
use App\Country;
use App\Degrees;
use App\Department;
use App\DocumentType;
use App\Eps;
use App\EthnicGroup;
use App\FamilyBackground;
use App\FamilyCurator;
use App\FamilyIncome;
use App\FamilyOccupation;
use App\FamilyRelationship;
use App\Frequency;
use App\House;
use App\HousingType;
use App\Institution;
use App\Level;
use App\Location;
use App\Neighborhood;
use App\NutritionalCondition;
use App\Pension;
use App\ReasonAdmission;
use App\ResidenceLocality;
use App\ResolutionType;
use App\Responsable;
use App\RiskFactor;
use App\Scholarship;
use App\SchoolGrade;
use App\SchoolHeadquarter;
use App\ServiceType;
use App\Sex;
use App\Status;
use App\Subject;
use App\Trend;
use App\TypeDisability;
use App\TypeFamily;
use App\User;
use App\ZonalCenter;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class SeedController extends Controller
{
    public function runConfiInit(){
        Artisan::call('passport:install');

        Status::create([
            'nombre' => 'Activo',
            'scope' => 'ALL'
        ]);
        Status::create([
            'nombre' => 'Inactivo',
            'scope' => 'ALL'
        ]);
        Status::create([
            'nombre' => 'Creado',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'Dsarrollo I',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'D psicologia',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'D social',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'En aprobación',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'Finalizado',
            'scope' => 'PLATIN'
        ]);
        Status::create([
            'nombre' => 'En ajustes',
            'scope' => 'PLATIN'
        ]);

    }
    public function runServiceTypes(){
        $data = [
            [
                'nombre' => 'Medico general',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Odontología',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Optometría',
                'estado_id' => 1,
            ],
        ];
        ServiceType::insert($data);
    }
    public function runAreaTrabajo(){
        $data = [
            [
                'name' => 'Pedagogía',
            ],
            [
                'name' => 'Medicina',
            ],
            [
                'name' => 'Nutrición',
            ],
            [
                'name' => 'Psicología',
            ],
            [
                'name' => 'Trabajo social',
            ],
            [
                'name' => 'Odontología',
            ],
            [
                'name' => 'Diciplinar',
            ],
            [
                'name' => 'Familiar',
            ],
            [
                'name' => 'Otras',
            ],
        ];
        AreaTrabajo::insert($data);
    }

    public function runCategoriaPlatin(){
        $data = [
            [
                'name' => '4. Diagnóstico integral. Incluir problemáticas asociadas',
            ],
            [
                'name' => '5. Atenciones a realizar (INDIVIDUAL)',
            ],
            [
                'name' => '5. Atenciones a realizar (FAMILIARES)',
            ],
            [
                'name' => '5. Atenciones a realizar (INTERINSTITUCIONALES)',
            ],
            [
                'name' => '6. Observaciones',
            ],
            [
                'name' => '7. Percepción de la calidad del servicio del niño, niña, adolescente, su familia y/o red vincular de apoyo',
            ],
        ];
        CategoriaPlatin::insert($data);
    }
    public function runFrecuencias(){
        $data = [
            [
                'nombre' => 'Siempre',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Algunas veces',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Nunca',
                'estado_id' => 1,
            ],
        ];
        Frequency::insert($data);
    }
    public function runGadoEscolar(){
        $data = [
            [
                'nombre' => 'Preescolar',
                'estado_id' => 1,
            ],
            [
                'nombre' => '1° Primaria',
                'estado_id' => 1,
            ],
            [
                'nombre' => '2° Primaria',
                'estado_id' => 1,
            ],
        ];
        SchoolGrade::insert($data);
    }

    public function runFactorRiesgo(){
        $data = [
            [
                'nombre' => 'Grupo armado',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Desplazamiento',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Permanencia de calle',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Grupo Armado',
                'estado_id' => 1,
            ],

        ];
        RiskFactor::insert($data);
    }

    public function runCategoryMetas(){
        $metas = [
            [
                'nombre' => 'Familiar',
            ],
            [
                'nombre' => 'interinstitucional',
            ],
            [
                'nombre' => 'individual',
            ],
        ];
        CategoryGoals::insert($metas);
    }
    public function runCountries(){
        $countries = [
            [
                'nombre' => 'Colombia',
                'nacionalidad' => 'Colombiano(a)',
            ]
        ];
        Country::insert($countries);
    }
    public function runDepartments(){
        $department = [
            [
                'nombre' => 'Cundinamarca',
                'pais_id' =>1
            ],
            [
                'nombre' => 'Antioquia',
                'pais_id' =>1

            ],
            [
                'nombre' => 'Valle del cauca',
                'pais_id' =>1

            ]
        ];
        Department::insert($department);
    }
    public function runCities(){
        $cities = [
            [
                'nombre' => 'Bogotá',
                'departamento_id' => 1
            ],
            [
                'nombre' => 'Medellín',
                'departamento_id' => 2
            ],
            [
                'nombre' => 'Cali',
                'departamento_id' => 3
            ]
        ];
        City::insert($cities);
    }

    public function runUsers(){
        Role::create(['name' => 'ADMIN']);
        Role::create(['name' => 'COORDINATOR']);
        Role::create(['name' => 'PSYCHOLOGIST']);
        Role::create(['name' => 'SOCIAL_WORK']);
        Role::create(['name' => 'FAMILY']);
        $users = [
            [
                'primer_nombre' => "Luis Fernando",
                'primer_apellido' => "Raga",
                'segundo_apellido' => "Renteria",
                'email' => "lraga@michin.com.co",
                'estado_id' => 1,
                'genero_id' => 1,
                'password' => Hash::make(sha1("password"))
            ],
            [
                'primer_nombre' => "David",
                'primer_apellido' => "Raga",
                'segundo_apellido' => "Renteria",
                'email' => "david.raga@michin.com.co",
                'estado_id' => 1,
                'genero_id' => 1,
                'password' => Hash::make(sha1("password"))
            ],
            [
                'primer_nombre' => "Yiraudys",
                'primer_apellido' => "Mojica",
                'segundo_apellido' => "",
                'email' => "yira@michin.com.co",
                'estado_id' => 1,
                'genero_id' => 1,
                'password' => Hash::make(sha1("password"))
            ],
            [
                'primer_nombre' => "Yiraudys Tr",
                'primer_apellido' => "Mojica",
                'segundo_apellido' => "",
                'email' => "yiratr@michin.com.co",
                'estado_id' => 1,
                'genero_id' => 1,
                'password' => Hash::make(sha1("password"))
            ],
            [
                'primer_nombre' => "David Psico",
                'primer_apellido' => "Raga",
                'segundo_apellido' => "Renteria",
                'email' => "david.ragapsico@michin.com.co",
                'estado_id' => 1,
                'genero_id' => 1,
                'password' => Hash::make(sha1("password"))
            ],


        ];

        foreach ($users as $key => $u) {
            $user = new User;
            $user->primer_nombre = $u['primer_nombre'];
            $user->primer_apellido = $u['primer_apellido'];
            $user->segundo_apellido = $u['segundo_apellido'];
            $user->email = $u['email'];
            $user->estado_id = $u['estado_id'];
            $user->genero_id = $u['genero_id'];
            $user->password = $u['password'];
            $user->save();


            if($key == 3){
                $user->assignRole('SOCIAL_WORK');
            }else if($key == 4){
                $user->assignRole('PSYCHOLOGIST');
            }else{
                $user->assignRole('ADMIN');
            }
            # code...
        }

    }


    public function runDocumentType(){
        $documentTypes = [
            [
                'nombre' => 'TARJETA DE IDENTIDAD',
            ],
            [
                'nombre' => 'CÉDULA DE CIUDADANÍA',
            ],
            [
                'nombre' => 'REGISTRO CIVIL',
            ],
            [
                'nombre' => 'PASAPORTE',
            ],
            [
                'nombre' => 'CÉDULA DE EXTRANJERÍA',
            ],
        ];
        DocumentType::insert($documentTypes);

    }

    public function runGeneros(){
        $generos = [
            [
                'nombre' => 'MASCULINO',
            ],
            [
                'nombre' => 'FEMENINO',
            ],
        ];
        Sex::insert($generos);

    }
    public function runTrend(){
        $trend = [
            [
                'nombre' => 'Propia',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Familiar',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Arriendo',
                'estado_id' => 1,
            ],
        ];
        Trend::insert($trend);

    }
    public function runHousing(){
        $housing = [
            [
                'nombre' => 'Casa',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Alojamiento',
                'estado_id' => 1,
            ],
        ];
        HousingType::insert($housing);
    }
    public function runLocations(){
        $locations = [
            [
                'nombre' => 'Protección',
            ],
            [
                'nombre' => 'Discapacidad',
            ],
        ];
        Location::insert($locations);

    }
    public function runEthnicGroup(){
        $ethnic = [
            [
                'name' => 'Mestizo',
            ],
            [
                'name' => 'Afrocolombiano',
            ],
            [
                'name' => 'Indigena',
            ],
        ];
        EthnicGroup::insert($ethnic);

    }

    public function runHouse(){
        $house = [
            [
                'nombre' => 'EFI',
                'direccion' => 'calle sur 35',
                'telefono' => '320983453',
                'coordinador_planta_id' => 3,
                'coordinadora_relevo_id' => 3,
                'estado_id' => 1,
                'genero_id' => 1,
                'minimo_edad' => 5,
                'maximo_edad' => 10,
            ],
            [
                'nombre' => 'GENIA',
                'direccion' => 'Av. americas',
                'telefono' => '3209232330',
                'coordinador_planta_id' => 1,
                'coordinadora_relevo_id' => 2,
                'estado_id' => 1,
                'genero_id' => 1,
                'minimo_edad' => 11,
                'maximo_edad' => 17,
            ],
        ];
        House::insert($house);

    }

    public function runResolutionType(){
        $resolution = [
            [
                'nombre' => 'Vulnerabilidad',

            ],
            [
                'nombre' => 'Adoptabilidad',

            ],
            [
                'nombre' => 'Sin resolución',

            ],
        ];
        ResolutionType::insert($resolution);

    }

    public function runZonalCenter(){
        $zonal = [
            [
                'nombre' => 'Zonal 1',
                'telefono' => '36783434343',
                'direccion' => 'calle de prueba',
                'municipio_id' => 1,

            ],
            [
                'nombre' => 'Zonal 2',
                'telefono' => '3202342324',
                'direccion' => 'calle false',
                'municipio_id' => 1,

            ],
            [
                'nombre' => 'Otro',
                'telefono' => '343534',
                'direccion' => 'calle falses',
                'municipio_id' => 1,

            ],
        ];
        ZonalCenter::insert($zonal);

    }

    public function runFamilyCurator(){
        $FamilyCurator = [
            [
                'nombre' => 'Comisaría familiar de prueba',
                'telefono' => '36783434343',
                'direccion' => 'calle de prueba',
                'municipio_id' => 1,

            ],

        ];
        FamilyCurator::insert($FamilyCurator);

    }
    public function runResidenceLocality(){
        $locality = [
            [
                'nombre' => 'Kennedy',
                'estado_id' => 1,
                'municipio_id' => 1,
            ],

        ];
        ResidenceLocality::insert($locality);

    }

    public function runNeighborhood(){
        $neighborhood = [
            [
                'nombre' => 'Tintal',
                'localidad_id' => 1,
                'estado_id' => 1,
            ],

        ];
        Neighborhood::insert($neighborhood);
    }

    public function runAdmission(){
        $admission = [
            [
                'nombre' => 'Inmigrante',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Abusado sexualmente',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Abandono',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Maltrato',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Conflicto familiar',
                'estado_id' => 1,
            ],

        ];
        ReasonAdmission::insert($admission);
    }

    public function runScholarship(){
        $escolaridad = [
            [
                'nombre' => 'Ninguna',
                'estado_id' => 1,
                'scope' => "NNA",
            ],
            [
                'nombre' => 'PRE-ESCOLAR',
                'estado_id' => 1,
                'scope' => "NNA",
            ],
            [
                'nombre' => 'ANALFABETA FUNCIONAL',
                'estado_id' => 1,
                'scope' => "NNA",
            ],
            [
                'nombre' => 'PRIMARIA INCOMPLETA',
                'estado_id' => 1,
                'scope' => "NNA",
            ],
            [
                'nombre' => 'PRIMARIA COMPLETA',
                'estado_id' => 1,
                'scope' => "NNA",
            ],


        ];
        Scholarship::insert($escolaridad);
    }

    public function runDiscapacidad(){
        $discapacidad = [
            [
                'nombre' => 'Ninguna',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Discapaciada física',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Discapaciada sensorial',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Discapaciada cognitiva',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Discapaciada mixta',
                'estado_id' => 1,
            ],
        ];
        TypeDisability::insert($discapacidad);
    }

    public function runNutritional(){
        $nutritional = [
            [
                'nombre' => 'Adecuado',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Desnutrición aguda',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Desnutrición cronica',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Desnutrición global',
                'estado_id' => 1,
            ],
        ];
        NutritionalCondition::insert($nutritional);
    }

    public function runFamily(){
        $typeFamily = [
            [
                'nombre' => 'Nuclear uniparental',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Extensa',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Recompuesta',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Poligenetica',
                'estado_id' => 1,
            ],
        ];
        TypeFamily::insert($typeFamily);
    }

    public function runResponsable(){
        $responsable = [
            [
                'nombre' => 'PADRE',
                'scope' => 'NNA',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'MADRE',
                'scope' => 'NNA',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'AMBOS PADRES',
                'scope' => 'NNA',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'ABUELOS',
                'scope' => 'NNA',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'PERSONAS DIFERENTES',
                'scope' => 'NNA',
                'estado_id' => 1,
            ],

        ];
        Responsable::insert($responsable);
    }

    public function runFamilyBackground(){
        $familyBacgroud = [
            [
                'nombre' => 'Consumo de SPA',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Prostitución',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Delicuencia',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Enfermedad mental',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Con discapacidad',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Con abuso sexual',
                'estado_id' => 1,
            ],

        ];
        FamilyBackground::insert($familyBacgroud);
    }

    public function runFamilyIncome(){
        $familyIncome = [
            [
                'nombre' => 'Menos de un SMLV',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Un SMLV',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'De 2 a 3 SMLV',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Mas de 3 SMLV',
                'estado_id' => 1,
            ],
        ];
        FamilyIncome::insert($familyIncome);
    }
    public function runFamilyOcupation(){
        $familyOcupation = [
            [
                'nombre' => 'Informal',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Independiente',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Empleado',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Prostitución',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Servicio domestico',
                'estado_id' => 1,
            ],
        ];
        FamilyOccupation::insert($familyOcupation);
    }

    public function runStatusCivil(){
        $estatusCivil = [
            [
                'nombre' => 'Soltero(a)',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Casado(a)',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Viudo(a)',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Divorciado(a)',
                'estado_id' => 1,
            ],
        ];
        CivilStatus::insert($estatusCivil);
    }

    public function runFamilyRelationship(){
        $relationship = [
            [
                'nombre' => 'Progenitor',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Progenitora',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Abuelo',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Abuela',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Hermano',
                'estado_id' => 1,
            ],
            [
                'nombre' => 'Hermana',
                'estado_id' => 1,
            ],
        ];
        FamilyRelationship::insert($relationship);
    }

}
