<?php

namespace App\Http\Controllers;

use App\Exports\TemplatePlatinExport;
use Maatwebsite\Excel\Facades\Excel;

class ReportExcelController extends Controller
{
    public function downloadTemplatePlatin(){
        return Excel::download(new TemplatePlatinExport, 'template_platin.xlsx');
    }
}
