<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Traits\CustomResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function login(LoginRequest $request){
        try {
            if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
                $token = Auth::user()->createToken(env('COMPANY_NAME'));
                
                $message = 'Usuario logueado';
                $status = true;
            }else{
                $status = false;
                $message = "Credenciales incorrectas";
            }
        } catch (\Throwable $th) {
            $status = false;
            $message = $th->getMessage();
        }


        if ($status) {
            return [
                'status_transaction' => $status,
                'message' => $message,
                'token' => $token->accessToken,
                'roles' => Auth::user()->roles->pluck('name')
            ];
        }else{
            return [
                'status_transaction' => $status,
                'message' => $message,
            ];
        }
    }

    public function logout(){
        try {
            Auth::user()->tokens()->delete();
            return [
                'code'=> 200
            ];
        } catch (\Throwable $th) {
            return [
                'code' => 500
            ];
        }
    }
}