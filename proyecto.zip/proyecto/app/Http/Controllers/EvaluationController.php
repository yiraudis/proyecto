<?php

namespace App\Http\Controllers;

use App\AntecedenteInstitucional;
use App\Children;
use App\DesarrolloPotencial;
use App\EvaSocialIndividual;
use App\EvaSocioFamiliar;
use App\EvEntrevistadoAgregado;
use App\EvFactorRiesgo;
use App\Family;
use App\Frequency;
use App\Goals;
use App\Http\Requests\EvaluationSocioFamiliar;
use App\Http\Traits\Globals;
use App\MapaPertenencia;
use App\Neighborhood;
use App\RiskFactor;
use App\SchoolGrade;
use App\ServiceType;
use App\User;
use App\UserDocumentType;
use App\VidaSaludable;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class EvaluationController extends Controller
{
    use Globals;
    public function getComplement(){
        $services_type = ServiceType::whereEstadoId($this->active)->get();
        $frecuencia = Frequency::whereEstadoId($this->active)->get();
        $grados = SchoolGrade::whereEstadoId($this->active)->get();
        $riesgos = RiskFactor::whereEstadoId($this->active)->get();
        $barrios = Neighborhood::where('estado_id',$this->active)->get();


        return [
            'services_type' => $services_type,
            'frecuencias' => $frecuencia,
            'grados' => $grados,
            'riesgos' => $riesgos,
            'barrios' => $barrios
        ];
    }

    public function saveSocialIngresoIndividual(Request $request){
        // return $request->identityData['children_id'];
        // return ($request);
        $status = false;
        DB::beginTransaction();
        try {
            $children = Children::find($request->identityData['children_id']);
            if (!isset($children)) {
                return [
                    'status_transaction' => $status,
                    'message' => "El NNA no existe"
                ];
            }


            isset($request->identityData['defensor']) ? $children->defensor = $request->identityData['defensor'] : false;
            isset($request->vida_saludable['regimen']) ? $children->regimen = $request->vida_saludable['regimen'] : false;
            isset($request->vida_saludable['nombre_regimen']) ? $children->nombre_regimen = $request->vida_saludable['nombre_regimen'] : false;
            $children->save();

            $user = User::find($children->usuario_id);
            isset($request->identityData['primer_nombre']) ? $user->primer_nombre = $request->identityData['primer_nombre'] : false;
            (isset($request->identityData['fecha_nacimiento']) &&  $request->identityData['fecha_nacimiento'] != "null") ? $user->fecha_nacimiento = Carbon::parse($request->identityData['fecha_nacimiento'])->toDateString() : false;
            $user->save();


            //guardar registro civil
            $registro_civil = UserDocumentType::whereUsuarioId($user->id)->where('tipo_identificacion_id',3)->first();
            if (!isset($registro_civil)) {
                $registro_civil = new UserDocumentType;
                $registro_civil->tipo_identificacion_id = 3;
                $registro_civil->usuario_id = $user->id;
            }
            $registro_civil->identificacion = isset($request->identityData['nuip']) ? $request->identityData['nuip'] : null;
            $registro_civil->notaria = isset($request->identityData['notaria']) ? $request->identityData['notaria'] : null;
            $registro_civil->registraduria = isset($request->identityData['registraduria']) ? $request->identityData['registraduria'] : null;
            $registro_civil->serial = isset($request->identityData['serial']) ? $request->identityData['serial'] : null;
            $registro_civil->principal = 0;
            $registro_civil->save();
            //crear la evaluacion
            $evaluacion = new EvaSocialIndividual;
            $evaluacion->nna_id = $children->id;
            $evaluacion->fecha_evaluacion = (isset($request->identityData['fecha_evaluacion']) &&  $request->identityData['fecha_evaluacion'] != "null")? Carbon::parse($request->identityData['fecha_evaluacion'])->toDateTimeString() : Carbon::now()->toDateTimeString();
            $evaluacion->vida_saludable = isset($request->vida_saludable['observacion']) ? $request->vida_saludable['observacion'] : null;
            $evaluacion->desarrollo_potenciales = isset($request->desarrollo_potenciales['observacion']) ? $request->desarrollo_potenciales['observacion'] : null;
            $evaluacion->motivo_ingreso = isset($request->motivo_ingreso) ? $request->motivo_ingreso : null;
            $evaluacion->socio_economica = isset($request->socio_economica) ? $request->socio_economica : null;
            $evaluacion->observaciones_factores = isset($request->observacion_riesgo) ? $request->observacion_riesgo : null;
            $evaluacion->dianamica_familiar = isset($request->dinamica_familiar) ? $request->dinamica_familiar : null;
            $evaluacion->expectativas = isset($request->expectativas) ? $request->expectativas : null;
            $evaluacion->impresiones = isset($request->impresiones) ? $request->impresiones : null;
            $evaluacion->mapa_pertenencia = isset($request->observacion_membership) ? $request->observacion_membership : null;
            $evaluacion->barrio_id = isset($request->neighborhood) ? $request->neighborhood['id'] : null;
            $evaluacion->direccion = isset($request->address) ? $request->address : null;
            $evaluacion->telefono = isset($request->phone) ? $request->phone : null;
            $evaluacion->estado_id = $this->active;
            $evaluacion->user_id = Auth::id();
            $evaluacion->save();

            //Familiares entrevistados
            if (isset($request->entrevistados)) {
                foreach ($request->entrevistados['entrevistados'] as $key => $item) {
                    if (isset($item['id'])) { // usuario registrado
                        $childre_family = Family::where('nna_id',$children->id)->where('familiar_id',$item['id'])->first();
                        if (!isset($family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $children->id;
                            $childre_family->familiar_id = $item['id'];
                        }
                        isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : $childre_family->parentesco_id = 1;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = EvaSocialIndividual::class;
                        $childre_family->model_id = $evaluacion->id;
                        $childre_family->save();
                    }else{
                        $family = User::whereHas('user_document_types',function($user_document_type) use($item){
                            $user_document_type->where('identificacion',$item['identificacion'])->where('tipo_identificacion_id',$item['tipo_identificacion_id']);
                        })->first();
                        if (!isset($family)) {
                            $family = new User;
                            isset($item['primer_nombre']) ? $family->primer_nombre = $item['primer_nombre'] : false;
                            isset($item['segundo_nombre']) ? $family->segundo_nombre = $item['segundo_nombre'] : false;
                            isset($item['primer_apellido']) ? $family->primer_apellido = $item['primer_apellido'] : false;
                            isset($item['segundo_apellido']) ? $family->segundo_apellido = $item['segundo_apellido'] : false;
                            isset($item['genero_id']) ? $family->genero_id = $item['genero_id'] : false;
                            isset($item['fecha_nacimiento']) ? $family->fecha_nacimiento = Carbon::parse($item['fecha_nacimiento'])->toDateString()  : false;
                            $family->estado_id = $this->active;
                            $family->save();
                            $family->assignRole('FAMILY');

                            //insertar identificación
                            $family_doc_type = new UserDocumentType();
                            $family_doc_type->usuario_id = $family->id;
                            $family_doc_type->identificacion = $item['identificacion'];
                            $family_doc_type->tipo_identificacion_id = $item['tipo_identificacion_id'];
                            $family_doc_type->save();
                        }else{
                            !$family->hasRole('FAMILY') ? $family->assignRole('FAMILY') : false;
                        }
                        isset($item['ocupacion_id']) ? $family->ocupacion_id = $item['ocupacion_id'] : false;
                        isset($item['escolaridad_id']) ? $family->escolaridad_id = $item['escolaridad_id'] : false;
                        isset($item['barrio_id']) ? $family->barrio_id = $item['barrio_id'] : false;
                        isset($item['direccion']) ? $family->direccion = $item['direccion'] : false;
                        isset($item['telefono']) ? $family->telefono = $item['telefono'] : false;
                        isset($item['tipo_vivienda_id']) ? $family->tipo_vivienda_id = $item['tipo_vivienda_id'] : false;
                        isset($item['tenencia_id']) ? $family->tenencia_id = $item['tenencia_id'] : false;
                        isset($item['estado_civil_id']) ? $family->estado_civil_id = $item['estado_civil_id'] : false;
                        $family->save();

                        //asociar familiar al nna
                        $childre_family = Family::where('nna_id',$children->id)->where('familiar_id',$family->id)->first();
                        if (!isset($childre_family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $children->id;
                            $childre_family->familiar_id = $family->id;
                        }
                        isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : false;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = EvaSocialIndividual::class;
                        $childre_family->model_id = $evaluacion->id;
                        isset($item['habita']) ? $childre_family->habita = $item['habita'] : false;
                        isset($item['contacto']) ? $childre_family->contacto = $item['contacto'] : false;
                        $childre_family->save();
                    }
                    //guardar entrevistado
                    $entrevistado = new EvEntrevistadoAgregado;
                    $entrevistado->nna_id = $children->id;
                    $entrevistado->familiar_id = $childre_family->id;
                    $entrevistado->type = $this->entrevistado;
                    $entrevistado->estado_id = $this->active;
                    $entrevistado->model = EvaSocialIndividual::class;
                    $entrevistado->model_id = $evaluacion->id;
                    $entrevistado->save();
                }
            }

            //vida saludable
            foreach ($request->vida_saludable['servicio_salud'] as $key => $value) {
                $salud = new VidaSaludable;
                $salud->ev_social_individual_id = $evaluacion->id;
                $salud->tipo_servicio_id = $value['type_service']['id'];
                $salud->frecuencia_id = $value['frecuencia']['id'];
                $salud->estado_id = $this->active;
                $salud->save();
            }

            //desarrollo de potenciales
            foreach ($request->desarrollo_potenciales['potenciales'] as $key => $value) {
                $potencial = new DesarrolloPotencial;
                $potencial->ev_social_individual_id = $evaluacion->id;
                $potencial->institucion = $value['institucion'];
                $potencial->tipo = $value['tipo'];
                $potencial->anio = Carbon::parse($value['year'])->year;
                $potencial->grado_escolar_id = $value['grado']['id'];
                $potencial->certifcado = $value['certificado'];
                $potencial->save();
            }

            //antecedentes institucionales
            foreach ($request->antecedentes_institucionales as $key => $value) {
                $antecedente = new AntecedenteInstitucional;
                $antecedente->ev_social_individual_id =$evaluacion->id;
                $antecedente->institucion_bienestar =$value['institucion'];
                $antecedente->fecha_ingreso =Carbon::parse($value['fecha_ingreso'])->toDateString();
                $antecedente->motivo_ingreso =$value['motivo_ingreso'];
                $antecedente->fecha_egreso =Carbon::parse($value['fecha_egreso'])->toDateString();
                $antecedente->motivo_egreso =$value['motivo_egreso'];
                $antecedente->adoptabilidad =isset($value['adoptabilidad']) ? 1 : 0;
                $antecedente->numero_adoptabilidad =$value['adoptabilidad'];
                $antecedente->vulnerabilidad =isset($value['vulnerabilidad']) ? 1 : 0;
                $antecedente->numero_vulnerablidad =$value['vulnerabilidad'];
                $antecedente->estado_id =$this->active;
                $antecedente->save();
            }

            //factores de riesgo
            foreach ($request->factores_riesgo as $key => $value) {
                $riesgo = new EvFactorRiesgo;
                $riesgo->ev_social_individual_id = $evaluacion->id;
                $riesgo->factor_riesgo_id = $value;
                $riesgo->estado_id = $this->active;
                $riesgo->save();
            }

            //mapa de pertenencia
            foreach ($request->mebership_map as $key => $value) {
                $mapa = new MapaPertenencia;
                $mapa->model = EvaSocialIndividual::class;
                $mapa->model_id = $evaluacion->id;
                $mapa->nivel = $value['level']['id'];
                $mapa->componente = $value['component']['name'];
                $mapa->descripcion = $value['text'];
                $mapa->tipo = 0;
                $mapa->save();
            }

            //guardar metas
            foreach ($request->dataCategories as $key => $category) {
                $meta = new Goals;
                $meta->model = EvaSocialIndividual::class;
                $meta->model_id = $evaluacion->id;
                $meta->categoria_metas_id = $category['id'];
                $meta->descripcion = $category['description'];
                $meta->estado_id = $this->active;
                $meta->save();
            }

            DB::commit();
            $status = true;
        } catch (\Throwable $th) {
            DB::rollback();
            $status = false;
            $error = $th->getMessage();
        }

        if ($status) {
            return [
                'status_transaction' => $status,
                'message' => "Evaluacion guardada correctamente"
            ];
        }else{
            return [
                'status_transaction' => $status,
                'message' => "No se pudo guardar la evaluacion",
                "error" => $error
            ];
        }
    }

    public function evaSocioFamiliarIngreso(EvaluationSocioFamiliar $request){

        try {
            DB::beginTransaction();


            $nna_id = $request->nna_id;
            // Crear eva socio familiar
            $evaluacion = new EvaSocioFamiliar;
            $evaluacion->fecha_evaluacion = Carbon::now()->toDateTimeString();
            $evaluacion->nna_id = $nna_id;
            $evaluacion->motivo_ingreso = $request->motivo_ingreso;
            $evaluacion->genograma = $request->genograma;
            $evaluacion->dianamica_familiar = $request->family_dinamic;
            $evaluacion->socio_economica = $request->socioeconomic_aspects;
            $evaluacion->apoyo_familiar = $request->support_family;
            $evaluacion->apoyo_social = $request->support_social;
            $evaluacion->proyecto = $request->project;
            $evaluacion->mapa_actual = $request->map_current;
            $evaluacion->mapa_potencial = $request->map_potential;
            $evaluacion->observacion_compromiso = $request->observation;
            






            $evaluacion->historia_vida = $request->history_family;
            $evaluacion->user_id = Auth::id();
            $evaluacion->estado_id = $this->active;


            $evaluacion->save();


            //Familiares entrevistados

            // dd($request->families);
            if (isset($request->families)) {
                foreach ($request->families['entrevistados'] as $key => $item) {
                    if (isset($item['id'])) { // usuario registrado
                        $childre_family = Family::where('nna_id',$nna_id)->where('familiar_id',$item['id'])->first();
                        if (!isset($family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $nna_id;
                            $childre_family->familiar_id = $item['id'];
                        }
                        isset($item['relationship']) ? $childre_family->parentesco_id = $item['relationship']['id'] : $childre_family->parentesco_id = 1;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = EvaSocialIndividual::class;
                        $childre_family->model_id = $evaluacion->id;
                        $childre_family->save();
                    }else{
                        $family = User::whereHas('user_document_types',function($user_document_type) use($item){
                            $user_document_type->where('identificacion',$item['identificacion'])->where('tipo_identificacion_id',$item['tipo_identificacion_id']);
                        })->first();
                        if (!isset($family)) {
                            $family = new User;
                            isset($item['primer_nombre']) ? $family->primer_nombre = $item['primer_nombre'] : false;
                            isset($item['segundo_nombre']) ? $family->segundo_nombre = $item['segundo_nombre'] : false;
                            isset($item['primer_apellido']) ? $family->primer_apellido = $item['primer_apellido'] : false;
                            isset($item['segundo_apellido']) ? $family->segundo_apellido = $item['segundo_apellido'] : false;
                            isset($item['genero_id']) ? $family->genero_id = $item['genero_id'] : false;
                            isset($item['fecha_nacimiento']) ? $family->fecha_nacimiento = Carbon::parse($item['fecha_nacimiento'])->toDateString()  : false;
                            $family->estado_id = $this->active;
                            $family->save();
                            $family->assignRole('FAMILY');

                            //insertar identificación
                            $family_doc_type = new UserDocumentType();
                            $family_doc_type->usuario_id = $family->id;
                            $family_doc_type->identificacion = $item['identificacion'];
                            $family_doc_type->tipo_identificacion_id = $item['tipo_identificacion_id'];
                            $family_doc_type->save();
                        }else{
                            !$family->hasRole('FAMILY') ? $family->assignRole('FAMILY') : false;
                        }
                        isset($item['ocupacion_id']) ? $family->ocupacion_id = $item['ocupacion_id'] : false;
                        isset($item['escolaridad_id']) ? $family->escolaridad_id = $item['escolaridad_id'] : false;
                        isset($item['barrio_id']) ? $family->barrio_id = $item['barrio_id'] : false;
                        isset($item['direccion']) ? $family->direccion = $item['direccion'] : false;
                        isset($item['telefono']) ? $family->telefono = $item['telefono'] : false;
                        isset($item['tipo_vivienda_id']) ? $family->tipo_vivienda_id = $item['tipo_vivienda_id'] : false;
                        isset($item['tenencia_id']) ? $family->tenencia_id = $item['tenencia_id'] : false;
                        isset($item['estado_civil_id']) ? $family->estado_civil_id = $item['estado_civil_id'] : false;
                        $family->save();

                        //asociar familiar al nna
                        $childre_family = Family::where('nna_id',$nna_id)->where('familiar_id',$family->id)->first();
                        if (!isset($childre_family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $nna_id;
                            $childre_family->familiar_id = $family->id;
                        }
                        isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : false;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = EvaSocialIndividual::class;
                        $childre_family->model_id = $evaluacion->id;
                        isset($item['habita']) ? $childre_family->habita = $item['habita'] : false;
                        isset($item['contacto']) ? $childre_family->contacto = $item['contacto'] : false;
                        $childre_family->save();
                    }
                    //guardar entrevistado
                    $entrevistado = new EvEntrevistadoAgregado;
                    $entrevistado->nna_id = $nna_id;
                    $entrevistado->familiar_id = $childre_family->id;
                    $entrevistado->type = $this->entrevistado;
                    $entrevistado->estado_id = $this->active;
                    $entrevistado->model = EvaSocialIndividual::class;
                    $entrevistado->model_id = $evaluacion->id;
                    $entrevistado->save();
                }
            }

            //mapa de pertenencia
            foreach ($request->membership_map_current as $key => $value) {
                $mapa = new MapaPertenencia;
                $mapa->model = EvaSocialIndividual::class;
                $mapa->model_id = $evaluacion->id;
                $mapa->nivel = $value['level']['id'];
                $mapa->componente = $value['component']['name'];
                $mapa->descripcion = $value['text'];
                $mapa->tipo = 0;
                $mapa->save();
            }

            //mapa de pertenencia
            foreach ($request->membership_map_potential as $key => $value) {
                $mapa = new MapaPertenencia;
                $mapa->model = EvaSocialIndividual::class;
                $mapa->model_id = $evaluacion->id;
                $mapa->nivel = $value['level']['id'];
                $mapa->componente = $value['component']['name'];
                $mapa->descripcion = $value['text'];
                $mapa->tipo = 0;
                $mapa->save();

            }

            //guardar metas
            foreach ($request->categories as $key => $category) {
                $meta = new Goals;
                $meta->model = EvaSocialIndividual::class;
                $meta->model_id = $evaluacion->id;
                $meta->categoria_metas_id = $category['id'];
                $meta->descripcion = $category['description'];
                $meta->estado_id = $this->active;
                $meta->save();


            }

            DB::commit();
            $status = true;
        } catch (\Throwable $th) {
            DB::rollback();
            $status = false;
            $error = $th->getMessage();
        }


        if ($status) {
            return [
                'status_transaction' => $status,
                'message' => "Evaluacion guardada correctamente."
            ];
        }else{
            return [
                'status_transaction' => $status,
                'message' => "No se pudo guardar la evaluacion.",
                "error" => $error
            ];
        }
    }
}
