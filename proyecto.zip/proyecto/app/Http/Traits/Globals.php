<?php
namespace App\Http\Traits;

use GraphQL\Type\Definition\Type;

trait Globals {
    // Estados
    public $active = 1;
    public $inactive = 2;
    public $entrevistado = 1;
    public $agregado = 2;

    // Códigos de respuesta
    public $success = 200; // hasta 209
    public $warning = 300; //hasta 219
    public $error = 500; // hasta 229

    public function responseGQL($type){
        $type['code'] = [
            'type' => Type::int(),
            'description' => 'response code in the system.'
        ];
        $type['status_transaction'] = [
            'type' => Type::boolean()
        ];
        $type['message'] = [
            'type' => Type::string()
        ];
        return $type;
    }

}


