<?php

namespace App;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $table = "paises";
    protected $guarded = [];

    public function departments(){
        return $this->hasMany(Department::class,'pais_id');
    }
}
