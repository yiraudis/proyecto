<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NutritionalCondition extends Model
{
    protected $table = "estados_nutricionales";
    protected $guarded = [];
}
