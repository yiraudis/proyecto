<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VidaSaludable extends Model
{
    protected $table = "vida_saludable";
    protected $guarded = [];
}
