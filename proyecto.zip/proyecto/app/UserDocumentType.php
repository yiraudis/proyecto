<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDocumentType extends Model
{
    protected $table = 'usuario_tipo_identificacion';
    protected $guarded = [];
}
