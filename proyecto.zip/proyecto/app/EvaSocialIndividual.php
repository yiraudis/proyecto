<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EvaSocialIndividual extends Model
{
    protected $table = "ev_social_individual";
    protected $guarded = [];
}
