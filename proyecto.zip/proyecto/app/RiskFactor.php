<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RiskFactor extends Model
{
    protected $table = "factores_riesgos";
}
