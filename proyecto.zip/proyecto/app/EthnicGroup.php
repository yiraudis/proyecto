<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EthnicGroup extends Model
{
    protected $table = "grupos_etnicos";
    protected $guraded = [];
}
