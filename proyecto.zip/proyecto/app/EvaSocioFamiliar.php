<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EvaSocioFamiliar extends Model
{
    protected $table = 'ev_socio_familiar';
}
