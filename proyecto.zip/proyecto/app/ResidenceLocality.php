<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResidenceLocality extends Model
{
    protected $table = "localidaddes";
    protected $guarded = [];

    public function neighborhood(){
        return $this->hasMany(Neighborhood::class,'localidad_id')->where('estado_id',1);
    }
}
