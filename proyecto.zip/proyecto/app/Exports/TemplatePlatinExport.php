<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class TemplatePlatinExport implements FromView
{
    public function view(): View
    {
        return view('exports.template_platin', [
            'data' => DB::select("select u.id, u.primer_apellido, u.segundo_apellido, u.primer_nombre nombres, u.fecha_nacimiento, u.created_at fecha_ingreso, n.defensor, uti.identificacion, c.nombre zonal  from nna n
                join users u on u.id = n.usuario_id
                join usuario_tipo_identificacion uti on uti.usuario_id=u.id
				left join centros_zonales c on c.id = n.centro_zonal_id
                group by u.id")
        ]);
    }
}
