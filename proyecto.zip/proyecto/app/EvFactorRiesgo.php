<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EvFactorRiesgo extends Model
{
    protected $guarded = [];
    protected $table = "ev_soc_ind_fr";
}
