<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FamilyCurator extends Model
{
    protected $table = "comisarias_familiares";
    protected $guarded = [];

    public function city(){
        return $this->belongsTo(City::class,'municipio_id');
    }
}
