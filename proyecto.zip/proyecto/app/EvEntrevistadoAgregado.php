<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EvEntrevistadoAgregado extends Model
{
    protected $table = "ev_entrevistado_agregado";
    protected $guarded = [];
}
