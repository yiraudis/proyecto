<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AntecedenteInstitucional extends Model
{
    protected $table = "antecedentes_institucionales";
    protected $guarded = [];
}
