<?php

declare(strict_types=1);

namespace App\GraphQL\Mutations;

use App\Children;
use App\ChildrenHouse;
use App\DocumentTypeUser;
use App\Family;
use App\Http\Traits\Globals;
use App\InformeEvolucion;
use App\User;
use App\UserDocumentType;
use Carbon\Carbon;
use Closure;
use GraphQL\Type\Definition\InputObjectType;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Illuminate\Support\Facades\DB;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Mutation;
use Rebing\GraphQL\Support\SelectFields;

class NewChildrenMutation extends Mutation
{
    use Globals;
    protected $attributes = [
        'name' => 'newChildren',
        'description' => 'A mutation'
    ];

    public function type(): Type
    {
        return GraphQL::type('children');
    }

    public function args(): array
    {
        return [
            'children_id' => [
                'type' => Type::int(),
                'description' => "requerido si es ediccion"
            ],
            'primer_nombre' => [
                'type' => Type::string()
            ],
            'segundo_nombre' => [
                'type' => Type::string()
            ],
            'primer_apellido' => [
                'type' => Type::string()
            ],
            'segundo_apellido' => [
                'type' => Type::string()
            ],
            'genero_id' => [
                'type' => Type::int()
            ],
            'fecha_nacimiento' => [
                'type' => Type::string()
            ],
            'estado_civil_id' => [
                'type' => Type::int()
            ],
            'ocupacion_id' => [
                'type' => Type::int()
            ],
            'grupo_etnico_id' => [
                'type' => Type::int()
            ],

            'identifications' => [
                'type' => Type::listOf(new InputObjectType([
                    'name' => 'identifications',
                    'fields' => [
                        'tipo_identificacion_id' => [
                            'type' => Type::int(),
                            'rules' => ['required']
                        ],
                        'identificacion' => [
                            'type' => Type::string(),
                            'rules' => ['required']
                        ],
                        'fecha_expedicion' => [
                            'type' => Type::string(),
                            'rules' => ['required','date']
                        ],

                    ]
                ])),
                'description' => 'identificaciones del nna',
                'rules' => ['nullable']
            ],


            // 'tipo_identificacion_id' => [
            //     'type' => Type::int()
            // ],
            // 'identificacion' => [
            //     'type' => Type::string()
            // ],
            // 'fecha_expedicion' => [
            //     'type' => Type::string()
            // ],
            'houses' => [
                'type' => Type::listOf(Type::int()),
                'rules' => ['nullable', 'exists:casas,id']
            ],
            'regional_ha' => [
                'type' => Type::int()
            ],
            'letra_ha' => [
                'type' => Type::string()
            ],
            'numero_ha' => [
                'type' => Type::string()
            ],
            'anio_ha' => [
                'type' => Type::int()
            ],
            'numero_hermanos' => [
                'type' => Type::int()
            ],
            'ubicacion_id' => [
                'type' => Type::int()
            ],
            'sim' => [
                'type' => Type::string()
            ],
            'trabajador_social_id' => [
                'type' => Type::int()
            ],
            'psicologo_id' => [
                'type' => Type::int()
            ],
            'fecha_ingreso_icbf' => [
                'type' => Type::string()
            ],
            'numero_ingresos_icbf' => [
                'type' => Type::int()
            ],
            'fecha_ingreso' => [
                'type' => Type::string()
            ],
            'tipo_resolucion_id' => [
                'type' => Type::int()
            ],
            'numero_resolucion' => [
                'type' => Type::string()
            ],
            'fecha_resolucion' => [
                'type' => Type::string()
            ],
            'centro_zonal_id' => [
                'type' => Type::int()
            ],
            'comisaria_familiar_id' => [
                'type' => Type::int()
            ],
            'defensor' => [
                'type' => Type::string()
            ],
            'barrio_id' => [
                'type' => Type::int()
            ],
            'motivo_ingreso_id' => [
                'type' => Type::int()
            ],
            'descripcion_ingreso_icbf' => [
                'type' => Type::string()
            ],
            'descripcion_ingreso_psicosocial' => [
                'type' => Type::string()
            ],
            'escolaridad_id' => [
                'type' => Type::int()
            ],
            'enfermedad' => [
                'type' => Type::int()
            ],
            'tipo_vacuna' => [
                'type' => Type::string()
            ],
            'accidente' => [
                'type' => Type::int()
            ],
            'estado_nutricional_id' => [
                'type' => Type::int()
            ],
            'tipo_discapacidad_id' => [
                'type' => Type::int()
            ],
            'regimen' => [
                'type' => Type::string()
            ],
            'nombre_regimen' => [
                'type' => Type::string()
            ],
            'area_social' => [
                'type' => Type::int()
            ],
            'tipo_familia_id' => [
                'type' => Type::int()
            ],
            'responsable_nna_id' => [
                'type' => Type::int()
            ],
            'antecedente_familiar_nna_id' => [
                'type' => Type::int()
            ],
            'ingreso_familiar_nna_id' => [
                'type' => Type::int()
            ],
            'ocupacion_familiar_nna_id' => [
                'type' => Type::int()
            ],
            'aporta_economicamente_familiar_nna_id' => [
                'type' => Type::int()
            ],
            'escolaridad_familiar_nna_id' => [
                'type' => Type::int()
            ],

            'family' => [
                'type' => Type::listOf(new InputObjectType([
                    'name' => 'family',
                    'fields' => [
                        'primer_nombre' => [
                            'type' => Type::string()
                        ],
                        'segundo_nombre' => [
                            'type' => Type::string()
                        ],
                        'primer_apellido' => [
                            'type' => Type::string()
                        ],
                        'segundo_apellido' => [
                            'type' => Type::string()
                        ],
                        'identificacion' => [
                            'type' => Type::string(),
                            'rules' => ['required']
                        ],
                        'tipo_identificacion_id' => [
                            'type' => Type::int(),
                            'rules' => ['required']
                        ],
                        'genero_id' => [
                            'type' => Type::int()
                        ],
                        'fecha_nacimiento' => [
                            'type' => Type::string()
                        ],
                        'estado_civil_id' => [
                            'type' => Type::int()
                        ],
                        'ocupacion_id' => [
                            'type' => Type::int()
                        ],
                        'escolaridad_id' => [
                            'type' => Type::int()
                        ],
                        'barrio_id' => [
                            'type' => Type::int()
                        ],
                        'direccion' => [
                            'type' => Type::string()
                        ],
                        'telefono' => [
                            'type' => Type::string()
                        ],
                        'tenencia_id' => [
                            'type' => Type::int()
                        ],
                        'tipo_vivienda_id' => [
                            'type' => Type::int()
                        ],
                        'parentesco_id' => [
                            'type' => Type::int()
                        ],
                        'habita' => [
                            'type' => Type::int(),
                            'rules' => ['in:0,1']
                        ],
                        'contacto' => [
                            'type' => Type::int(),
                            'rules' => ['in:0,1']
                        ],

                    ]
                ])),
                'description' => 'familiares del nna',
                'rules' => ['nullable']
            ]
        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        // return [
        //     'message' => json_encode($args)
        // ];
        $status = true;
        $children = new Children;
        if (isset($ags['children_id'])) {
            $children = Children::find($ags['children_id']);
            if (!isset($children)) {
                return [
                    'status_transaction' => false,
                    'message' => "Niño o niña no existe"
                ];
            }
        }

        $user = new User;
        if (isset($args['children_id'])) {
            $user = User::find($children->usuario_id);
            if (!isset($user)) {
                return [
                    'status_transaction' => false,
                    'message' => "Niño o niña no existe"
                ];
            }
        }
        DB::beginTransaction();
        try {
            //dataos básicos del usuario
            isset($args['primer_nombre']) ? $user->primer_nombre = $args['primer_nombre'] : false;
            isset($args['segundo_nombre']) ? $user->segundo_nombre = $args['segundo_nombre'] : false;
            isset($args['primer_apellido']) ? $user->primer_apellido = $args['primer_apellido'] : false;
            isset($args['segundo_apellido']) ? $user->segundo_apellido = $args['segundo_apellido'] : false;
            isset($args['genero_id']) ? $user->genero_id = $args['genero_id'] : false;
            isset($args['fecha_nacimiento']) ? $user->fecha_nacimiento = Carbon::parse($args['fecha_nacimiento'])->toDateString()  : false;
            isset($args['ocupacion_id']) ? $user->ocupacion_id = $args['ocupacion_id'] : false;
            isset($args['escolaridad_id']) ? $user->escolaridad_id = $args['escolaridad_id'] : false;
            isset($args['grupo_etnico_id']) ? $user->grupo_etnico_id = $args['grupo_etnico_id'] : false;
            $user->estado_id = $this->active;
            $user->save();

            if (isset($args['identifications'])) {
                foreach ($args['identifications'] as $key => $value) {
                    //Validar si existe
                    $user_doc_type = UserDocumentType::where('usuario_id',$user->id)->where('identificacion',$value['identificacion'])
                    ->where('tipo_identificacion_id',$value['tipo_identificacion_id'])->first();
                    if (!isset($user_doc_type)) {
                        $user_doc_type = new UserDocumentType;
                        $user_doc_type->usuario_id = $user->id;
                        $user_doc_type->identificacion = $value['identificacion'];
                        $user_doc_type->tipo_identificacion_id = $value['tipo_identificacion_id'];
                    }
                    isset($value['fecha_expedicion']) ? $user_doc_type->fecha_expedicion = Carbon::parse($value['fecha_expedicion'])  : null;
                    $user_doc_type->save();
                }
            }

            //insertar tipos de identificación
            // DocumentTypeUser::all();


            //datos del nna
            $children->usuario_id = $user->id;
            isset($args['regional_ha']) ?  $children->regional_ha =  $args['regional_ha'] : false;
            isset($args['letra_ha']) ? $children->letra_ha =  $args['letra_ha'] : null;
            isset($args['numero_ha']) ? $children->numero_ha =  $args['numero_ha'] : null;
            isset($args['anio_ha']) ? $children->anio_ha = $args['anio_ha'] : null;
            isset($args['numero_hermanos']) ? $children->numero_hermanos = $args['numero_hermanos'] : null;
            isset($args['ubicacion_id']) ? $children->ubicacion_id = $args['ubicacion_id'] : null;
            isset($args['sim']) ? $children->sim = $args['sim'] : null;
            isset($args['trabajador_social_id']) ? $children->trabajador_social_id = $args['trabajador_social_id'] : null;
            isset($args['psicologo_id']) ? $children->psicologo_id = $args['psicologo_id'] : null;
            isset($args['fecha_ingreso_icbf']) ? $children->fecha_ingreso_icbf = Carbon::parse($args['fecha_ingreso_icbf'])->toDateString() : null;
            isset($args['numero_ingresos_icbf']) ? $children->numero_ingresos_icbf = $args['numero_ingresos_icbf'] : null;
            isset($args['fecha_ingreso']) ? $children->fecha_ingreso = Carbon::parse($args['fecha_ingreso'])->toDateString()  : null;
            isset($args['tipo_resolucion_id']) ? $children->tipo_resolucion_id = $args['tipo_resolucion_id'] : null;
            isset($args['numero_resolucion']) ? $children->numero_resolucion = $args['numero_resolucion'] : null;
            isset($args['fecha_resolucion']) ? $children->fecha_resolucion = Carbon::parse($args['fecha_resolucion'])  : null;

            isset($args['centro_zonal_id']) ? $children->centro_zonal_id = $args['centro_zonal_id'] : null;
            isset($args['comisaria_familiar_id']) ? $children->comisaria_familiar_id = $args['comisaria_familiar_id'] : null;
            isset($args['defensor']) ? $children->defensor = $args['defensor'] : null;
            isset($args['barrio_id']) ? $children->barrio_id = $args['barrio_id'] : null;
            isset($args['motivo_ingreso_id']) ? $children->motivo_ingreso_id = $args['motivo_ingreso_id'] : null;
            isset($args['descripcion_ingreso_icbf']) ? $children->descripcion_ingreso_icbf = $args['descripcion_ingreso_icbf'] : null;
            isset($args['descripcion_ingreso_psicosocial']) ? $children->descripcion_ingreso_psicosocial = $args['descripcion_ingreso_psicosocial'] : null;
            isset($args['escolaridad_id']) ? $children->escolaridad_id = $args['escolaridad_id'] : null;
            isset($args['enfermedad']) ? $children->enfermedad = $args['enfermedad'] : null;
            isset($args['tipo_vacuna']) ? $children->tipo_vacuna = $args['tipo_vacuna'] : null;
            isset($args['accidente']) ? $children->accidente = $args['accidente'] : null;
            isset($args['estado_nutricional_id']) ? $children->estado_nutricional_id = $args['estado_nutricional_id'] : null;

            isset($args['tipo_discapacidad_id']) ? $children->tipo_discapacidad_id = $args['tipo_discapacidad_id'] : null;
            isset($args['regimen']) ? $children->regimen = $args['regimen'] : null;
            isset($args['nombre_regimen']) ? $children->nombre_regimen = $args['nombre_regimen'] : null;
            isset($args['area_social']) ? $children->area_social = $args['area_social'] : null;
            isset($args['tipo_familia_id']) ? $children->tipo_familia_id = $args['tipo_familia_id'] : null;
            isset($args['responsable_nna_id']) ? $children->responsable_nna_id = $args['responsable_nna_id'] : null;
            isset($args['antecedente_familiar_nna_id']) ? $children->antecedente_familiar_nna_id = $args['antecedente_familiar_nna_id'] : null;

            isset($args['ingreso_familiar_nna_id']) ? $children->ingreso_familiar_nna_id = $args['ingreso_familiar_nna_id'] : null;
            isset($args['ocupacion_familiar_nna_id']) ? $children->ocupacion_familiar_nna_id = $args['ocupacion_familiar_nna_id'] : null;
            isset($args['aporta_economicamente_familiar_nna_id']) ? $children->aporta_economicamente_familiar_nna_id = $args['aporta_economicamente_familiar_nna_id'] : null;
            isset($args['escolaridad_familiar_nna_id']) ? $children->escolaridad_familiar_nna_id = $args['escolaridad_familiar_nna_id'] : null;
            $children->estado_id = $this->active;
            $children->save();

            //datos de las casas
            if (isset($args['houses'])) {

                // dd([$children->id, $this->inactive]);
                // ChildrenHouse::where('nna_id',$children->id)->update(['estado_id',$this->inactive]);
                foreach ($args['houses'] as $key => $house) {
                    $children_house = ChildrenHouse::where('casa_id',$house)->where('nna_id',$children->id)->first();
                    if (!isset($children_house)) {
                        $children_house = new ChildrenHouse;
                        $children_house->nna_id = $children->id;
                        $children_house->casa_id = $house;
                    }

                    $children_house->estado_id = $this->active;
                    $children_house->save();
                }
            }

            //datos de los familiares

            if (isset($args['family'])) {
                Family::where('nna_id',$children->id)->update(['estado_id' => $this->inactive]);
                foreach ($args['family'] as $key => $item) {
                    $family = User::whereHas('user_document_types',function($user_document_type) use($item){
                        $user_document_type->where('identificacion',$item['identificacion'])->where('tipo_identificacion_id',$item['tipo_identificacion_id']);
                    })->first();
                    if (!isset($family)) {
                        $family = new User;
                        isset($item['primer_nombre']) ? $family->primer_nombre = $item['primer_nombre'] : false;
                        isset($item['segundo_nombre']) ? $family->segundo_nombre = $item['segundo_nombre'] : false;
                        isset($item['primer_apellido']) ? $family->primer_apellido = $item['primer_apellido'] : false;
                        isset($item['segundo_apellido']) ? $family->segundo_apellido = $item['segundo_apellido'] : false;
                        isset($item['genero_id']) ? $family->genero_id = $item['genero_id'] : false;
                        isset($item['fecha_nacimiento']) ? $family->fecha_nacimiento = Carbon::parse($item['fecha_nacimiento'])->toDateString()  : false;
                        $family->estado_id = $this->active;
                        $family->save();
                        $family->assignRole('FAMILY');

                        //insertar identificación
                        $family_doc_type = new UserDocumentType;
                        $family_doc_type->usuario_id = $family->id;
                        $family_doc_type->identificacion = $item['identificacion'];
                        $family_doc_type->tipo_identificacion_id = $item['tipo_identificacion_id'];
                        $family_doc_type->save();
                    }else{
                        !$family->hasRole('FAMILY') ? $family->assignRole('FAMILY') : false;
                    }
                    isset($item['ocupacion_id']) ? $family->ocupacion_id = $item['ocupacion_id'] : false;
                    isset($item['escolaridad_id']) ? $family->escolaridad_id = $item['escolaridad_id'] : false;
                    isset($item['barrio_id']) ? $family->barrio_id = $item['barrio_id'] : false;
                    isset($item['direccion']) ? $family->direccion = $item['direccion'] : false;
                    isset($item['telefono']) ? $family->telefono = $item['telefono'] : false;
                    isset($item['tipo_vivienda_id']) ? $family->tipo_vivienda_id = $item['tipo_vivienda_id'] : false;
                    isset($item['tenencia_id']) ? $family->tenencia_id = $item['tenencia_id'] : false;
                    isset($item['estado_civil_id']) ? $family->estado_civil_id = $item['estado_civil_id'] : false;
                    $family->save();

                    //asociar familiar al nna
                    $childre_family = Family::where('nna_id',$children->id)->where('familiar_id',$family->id)->first();
                    if (!isset($childre_family)) {
                        $childre_family = new Family;
                        $childre_family->nna_id = $children->id;
                        $childre_family->familiar_id = $family->id;
                    }
                    isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : false;
                    $childre_family->estado_id = $this->active;
                    $childre_family->model = get_class($children->getModel());
                    $childre_family->model_id = $children->id;
                    isset($item['habita']) ? $childre_family->habita = $item['habita'] : false;
                    isset($item['contacto']) ? $childre_family->contacto = $item['contacto'] : false;
                    $childre_family->save();

                }
            }

            //guardar platin
            if (!isset($args['children_id'])) {
                $inf = new InformeEvolucion;
                $inf->nna_id = $children->id;
                $inf->tipo = 0; //platin
                $inf->estado_id = 3; // creado
                $inf->responsable_id = 1; // validar que valor debe ir
                $inf->save();
            }

            // return [
            //     'message' => "aqui"
            // ];
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollback();
            $status= false;
            $error = $th->getMessage();
        }

        if ($status) {
            return [
                'code' => $this->success,
                'status_transaction' => $status,
                'message' => "Información guardada correctamente"
            ];
        }else{
            return [
                'code' => $this->error,
                'status_transaction' => $status,
                'message' => $error
            ];
        }
    }
}
