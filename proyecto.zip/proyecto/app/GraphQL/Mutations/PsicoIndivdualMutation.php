<?php

declare(strict_types=1);

namespace App\GraphQL\Mutations;

use App\Children;
use App\Goals;
use App\Http\Traits\Globals;
use App\PsicoIndividual;
use App\User;
use Carbon\Carbon;
use Closure;
use GraphQL\Type\Definition\InputObjectType;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Mutation;
use Rebing\GraphQL\Support\SelectFields;

class PsicoIndivdualMutation extends Mutation
{
    use Globals;
    protected $attributes = [
        'name' => 'psicoIndivdual',
        'description' => 'A mutation'
    ];

    public function type(): Type
    {
        return GraphQL::type('login');
    }

    public function args(): array
    {
        return [
            'children_id' => [
                'type' => Type::int(),
                'description' => "requerido si es ediccion",
                'rules' => ['required']
            ],
            'primer_nombre' => [
                'type' => Type::string()
            ],
            'fecha_nacimiento' => [
                'type' => Type::string()
            ],
            'fecha_evaluacion' => [
                'type' => Type::string()
            ],
            'escolaridad_id' => [
                'type' => Type::int()
            ],
            'grupo_etnico_id' => [
                'type' => Type::int()
            ],
            'percepcion_ingreso' => [
                'type' => Type::string()
            ],
            'antecedentes' => [
                'type' => Type::string()
            ],
            'examen_mental' => [
                'type' => Type::string()
            ],
            'afectividad' => [
                'type' => Type::string()
            ],
            'percepcion_nna' => [
                'type' => Type::string()
            ],
            'prospectiva' => [
                'type' => Type::string()
            ],
            'adaptacion' => [
                'type' => Type::string()
            ],
            'resultado_pruebas' => [
                'type' => Type::string()
            ],
            'lectura_profesional' => [
                'type' => Type::string()
            ],
            'categories' => [
                'type' => Type::listOf(new InputObjectType([
                    'name' => 'categories',
                    'fields' => [
                        'id' => [
                            'type' => Type::int(),
                            'rules' => ['required']
                        ],
                        'description' => [
                            'type' => Type::string(),
                            'rules' => ['required']
                        ],
                    ]
                ])),
                'description' => 'anotaciones a realizar por categorias',
                'rules' => ['nullable']
            ],
        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {

        $status = false;
        DB::beginTransaction();
        try {
            $children = Children::find($args['children_id']);
            if (!isset($children)) {
                return [
                    'status_transaction' => $status,
                    'message' => "El NNA no existe"
                ];
            }
            // dd($args['children_id']);
            $user = User::find($children->usuario_id);
            isset($args['primer_nombre']) ? $user->primer_nombre = $args['primer_nombre'] : false;
            (isset($args['fecha_nacimiento']) &&  $args['fecha_nacimiento'] != "null") ? $user->fecha_nacimiento = Carbon::parse($args['fecha_nacimiento'])->toDateString() : false;
            isset($args['grupo_etnico_id']) ? $user->grupo_etnico_id = $args['grupo_etnico_id'] : false;
            isset($args['escolaridad_id']) ? $user->escolaridad_id = $args['escolaridad_id'] : false;
            $user->save();
            isset($args['escolaridad_id']) ? $children->escolaridad_id = $args['escolaridad_id'] : false;
            $children->save();



            $psico = new PsicoIndividual;
            $psico->nna_id = $children->id;
            $psico->percepcion_ingreso = isset($args['percepcion_ingreso']) ? $args['percepcion_ingreso'] : null;
            $psico->antecedentes = isset($args['antecedentes']) ? $args['antecedentes'] : null;
            $psico->examen_mental = isset($args['examen_mental']) ? $args['examen_mental'] : null;
            $psico->afectividad = isset($args['afectividad']) ? $args['afectividad'] : null;
            $psico->percepcion_niño = isset($args['percepcion_nna']) ? $args['percepcion_nna'] : null;
            $psico->prospectiva = isset($args['prospectiva']) ? $args['prospectiva'] : null;
            $psico->adaptacion = isset($args['adaptacion']) ? $args['adaptacion'] : null;
            $psico->resultado_prueba = isset($args['resultado_pruebas']) ? $args['resultado_pruebas'] : null;
            $psico->lectura = isset($args['lectura_profesional']) ? $args['lectura_profesional'] : null;
            $psico->fecha_evaluacion = (isset($args['fecha_evaluacion']) &&  $args['fecha_evaluacion'] != "null")? Carbon::parse($args['fecha_evaluacion'])->toDateTimeString() : Carbon::now()->toDateTimeString();
            $psico->estado_id = 1;
            $psico->user_id = Auth::id();
            $psico->save();

            //guardar metas
            foreach ($args['categories'] as $key => $category) {
                $meta = new Goals;
                $meta->model = PsicoIndividual::class;
                $meta->model_id = $psico->id;
                $meta->categoria_metas_id = $category['id'];
                $meta->descripcion = $category['description'];
                $meta->estado_id = $this->active;
                $meta->save();
            }

            $status = true;
            DB::commit();
        } catch (\Throwable $th) {
            $status = false;
            $error = $th->getMessage();
            DB::rollback();
        }

        if ($status) {
            return [
                'status_transaction' => $status,
                'message' => "Evaluación guardada correctamente"
            ];
        }else{
            return [
                'status_transaction' => $status,
                'message' => $error
            ];
        }

    }
}
