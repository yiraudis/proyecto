<?php

declare(strict_types=1);

namespace App\GraphQL\Mutations;

use App\Children;
use App\EvEntrevistadoAgregado;
use App\Family;
use App\Goals;
use App\Http\Traits\Globals;
use App\PsicoIndividualFamiliar;
use App\User;
use App\UserDocumentType;
use Carbon\Carbon;
use Closure;
use GraphQL\Type\Definition\InputObjectType;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Mutation;
use Rebing\GraphQL\Support\SelectFields;

class PsicoIngresoFamiliarMutation extends Mutation
{
    use Globals;
    protected $attributes = [
        'name' => 'psicoIngresoFamiliar',
        'description' => 'A mutation'
    ];

    public function type(): Type
    {
        return GraphQL::type('login');
    }

    public function args(): array
    {
        return [
            'children_id' => [
                'type' => Type::int(),
                'description' => "requerido si es ediccion",
                'rules' => ['required']
            ],
            'fecha_evaluacion' => [
                'type' => Type::string()
            ],
            'motivo_ingreso' => [
                'type' => Type::string()
            ],
            'caracteristicas' => [
                'type' => Type::string()
            ],
            'evento_significativo' => [
                'type' => Type::string()
            ],
            'sistema_creencia' => [
                'type' => Type::string()
            ],
            'generatividad' => [
                'type' => Type::string()
            ],
            'vulnerabilidad' => [
                'type' => Type::string()
            ],
            'lectura' => [
                'type' => Type::string()
            ],
            'datacategories' => [
                'type' => Type::listOf(new InputObjectType([
                    'name' => 'datacategories',
                    'fields' => [
                        'id' => [
                            'type' => Type::int(),
                            'rules' => ['required']
                        ],
                        'description' => [
                            'type' => Type::string(),
                            'rules' => ['required']
                        ],
                    ]
                ])),
                'description' => 'anotaciones a realizar por categorias',
                'rules' => ['nullable']
            ],
            'family' => [
                'type' => Type::listOf(new InputObjectType([
                    'name' => 'family',
                    'fields' => [
                        'id' => [
                            'type' => Type::int(),
                            'description' => "Id del familiar si existe"
                        ],
                        'primer_nombre' => [
                            'type' => Type::string()
                        ],
                        'segundo_nombre' => [
                            'type' => Type::string()
                        ],
                        'primer_apellido' => [
                            'type' => Type::string()
                        ],
                        'segundo_apellido' => [
                            'type' => Type::string()
                        ],
                        'identificacion' => [
                            'type' => Type::string(),
                            // 'rules' => ['required']
                        ],
                        'tipo_identificacion_id' => [
                            'type' => Type::int(),
                            // 'rules' => ['required']
                        ],
                        'genero_id' => [
                            'type' => Type::int()
                        ],
                        'fecha_nacimiento' => [
                            'type' => Type::string()
                        ],
                        'estado_civil_id' => [
                            'type' => Type::int()
                        ],
                        'ocupacion_id' => [
                            'type' => Type::int()
                        ],
                        'escolaridad_id' => [
                            'type' => Type::int()
                        ],
                        'barrio_id' => [
                            'type' => Type::int()
                        ],
                        'direccion' => [
                            'type' => Type::string()
                        ],
                        'telefono' => [
                            'type' => Type::string()
                        ],
                        'tenencia_id' => [
                            'type' => Type::int()
                        ],
                        'tipo_vivienda_id' => [
                            'type' => Type::int()
                        ],
                        'parentesco_id' => [
                            'type' => Type::int()
                        ],
                        'habita' => [
                            'type' => Type::int(),
                            'rules' => ['in:0,1']
                        ],
                        'contacto' => [
                            'type' => Type::int(),
                            'rules' => ['in:0,1']
                        ],

                    ]
                ])),
                'description' => 'familiares del nna',
                'rules' => ['nullable']
            ]
        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        $status = false;
        DB::beginTransaction();
        try {
            $children = Children::find($args['children_id']);
            if (!isset($children)) {
                return [
                    'status_transaction' => $status,
                    'message' => "El NNA no existe"
                ];
            }
            //guardar evaluacion
            $evaluation = new PsicoIndividualFamiliar;
            $evaluation->nna_id = $args['children_id'];
            $evaluation->percepcion_ingreso = $args['motivo_ingreso'];
            $evaluation->cataracteristicas = $args['caracteristicas'];
            $evaluation->evento_significativo = $args['evento_significativo'];
            $evaluation->sistema_creencia = $args['sistema_creencia'];
            $evaluation->genereatividad = $args['generatividad'];
            $evaluation->vulnerabilidad = $args['vulnerabilidad'];
            $evaluation->lectura = $args['lectura'];
            $evaluation->estado_id = $this->active;
            $evaluation->user_id = Auth::id();
            $evaluation->fecha_evaluacion = (isset($args['fecha_evaluacion']) &&  $args['fecha_evaluacion'] != "null")? Carbon::parse($args['fecha_evaluacion'])->toDateTimeString() : Carbon::now()->toDateTimeString();
            $evaluation->save();

            //guardar metas
            if (isset($args['datacategories'])) {
                foreach ($args['datacategories'] as $key => $category) {
                    $meta = new Goals();
                    $meta->model = PsicoIndividualFamiliar::class;
                    $meta->model_id = $evaluation->id;
                    $meta->categoria_metas_id = $category['id'];
                    $meta->descripcion = $category['description'];
                    $meta->estado_id = $this->active;
                    $meta->save();
                }
            }

            //Familiares entrevistados
            if (isset($args['family'])) {
                foreach ($args['family'] as $key => $item) {
                    if (isset($item['id'])) { // usuario registrado
                        $childre_family = Family::where('nna_id',$children->id)->where('familiar_id',$item['id'])->first();
                        if (!isset($family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $children->id;
                            $childre_family->familiar_id = $item['id'];
                        }
                        isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : false;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = PsicoIndividualFamiliar::class;
                        $childre_family->model_id = $evaluation->id;
                        $childre_family->save();
                    }else{
                        $family = User::whereHas('user_document_types',function($user_document_type) use($item){
                            $user_document_type->where('identificacion',$item['identificacion'])->where('tipo_identificacion_id',$item['tipo_identificacion_id']);
                        })->first();
                        if (!isset($family)) {
                            $family = new User;
                            isset($item['primer_nombre']) ? $family->primer_nombre = $item['primer_nombre'] : false;
                            isset($item['segundo_nombre']) ? $family->segundo_nombre = $item['segundo_nombre'] : false;
                            isset($item['primer_apellido']) ? $family->primer_apellido = $item['primer_apellido'] : false;
                            isset($item['segundo_apellido']) ? $family->segundo_apellido = $item['segundo_apellido'] : false;
                            isset($item['genero_id']) ? $family->genero_id = $item['genero_id'] : false;
                            isset($item['fecha_nacimiento']) ? $family->fecha_nacimiento = Carbon::parse($item['fecha_nacimiento'])->toDateString()  : false;
                            $family->estado_id = $this->active;
                            $family->save();
                            $family->assignRole('FAMILY');

                            //insertar identificación
                            $family_doc_type = new UserDocumentType();
                            $family_doc_type->usuario_id = $family->id;
                            $family_doc_type->identificacion = $item['identificacion'];
                            $family_doc_type->tipo_identificacion_id = $item['tipo_identificacion_id'];
                            $family_doc_type->save();
                        }else{
                            !$family->hasRole('FAMILY') ? $family->assignRole('FAMILY') : false;
                        }
                        isset($item['ocupacion_id']) ? $family->ocupacion_id = $item['ocupacion_id'] : false;
                        isset($item['escolaridad_id']) ? $family->escolaridad_id = $item['escolaridad_id'] : false;
                        isset($item['barrio_id']) ? $family->barrio_id = $item['barrio_id'] : false;
                        isset($item['direccion']) ? $family->direccion = $item['direccion'] : false;
                        isset($item['telefono']) ? $family->telefono = $item['telefono'] : false;
                        isset($item['tipo_vivienda_id']) ? $family->tipo_vivienda_id = $item['tipo_vivienda_id'] : false;
                        isset($item['tenencia_id']) ? $family->tenencia_id = $item['tenencia_id'] : false;
                        isset($item['estado_civil_id']) ? $family->estado_civil_id = $item['estado_civil_id'] : false;
                        $family->save();

                        //asociar familiar al nna
                        $childre_family = Family::where('nna_id',$children->id)->where('familiar_id',$family->id)->first();
                        if (!isset($childre_family)) {
                            $childre_family = new Family;
                            $childre_family->nna_id = $children->id;
                            $childre_family->familiar_id = $family->id;
                        }
                        isset($item['parentesco_id']) ? $childre_family->parentesco_id = $item['parentesco_id'] : false;
                        $childre_family->estado_id = $this->active;
                        $childre_family->model = PsicoIndividualFamiliar::class;
                        $childre_family->model_id = $evaluation->id;
                        isset($item['habita']) ? $childre_family->habita = $item['habita'] : false;
                        isset($item['contacto']) ? $childre_family->contacto = $item['contacto'] : false;
                        $childre_family->save();

                        // dd(['segundo_family',$childre_family]);
                    }
                    //guardar entrevistado
                    $entrevistado = new EvEntrevistadoAgregado;
                    $entrevistado->nna_id = $children->id;
                    $entrevistado->familiar_id = $childre_family->id;
                    $entrevistado->type = $this->entrevistado;
                    $entrevistado->estado_id = $this->active;
                    $entrevistado->model = PsicoIndividualFamiliar::class;
                    $entrevistado->model_id = $evaluation->id;
                    $entrevistado->save();
                }
            }
            $status = true;
            DB::commit();
        } catch (\Throwable $th) {
            $status = false;
            $error = $th->getMessage();
            DB::rollBack();
        }

        if ($status) {
            return [
                'status_transaction' => $status,
                'message' => "Evaluación guardada correctamente",
            ];
        }else{
            return [
                'status_transaction' => $status,
                'message' => $error,
            ];
        }
    }
}
