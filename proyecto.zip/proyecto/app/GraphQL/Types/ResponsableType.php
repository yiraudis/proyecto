<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ResponsableType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Responsable',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'id' => [
                'type' => Type::int(),
            ],
            'nombre' => [
                'type' => Type::string(),
            ],
            'scope' => [
                'type' => Type::string(),
            ]
        ];
    }
}
