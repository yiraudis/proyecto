<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use App\Http\Traits\Globals;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ChildrenType extends GraphQLType
{
    use Globals;
    protected $attributes = [
        'name' => 'Chlidren',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return $this->responseGQL([
            'letra_ha' => [
                'type' => Type::string()
            ],
            'id' => [
                'type' => Type::int()
            ],
            'user' => [
                'type' => GraphQL::type('user')
            ],
            'estado_id' => [
                'type' => Type::int()
            ],
            'regional_ha' => [
                'type' => Type::string()
            ],
            'letra_ha' => [
                'type' => Type::string()
            ],
            'numero_ha' => [
                'type' => Type::string()
            ],
            'anio_ha' => [
                'type' => Type::int()
            ],
            'numero_hermanos' => [
                'type' => Type::int()
            ],
            'location' => [
                'type' => GraphQL::type('location')
            ],
            'sim' => [
                'type' => Type::string()
            ],
            'psychologist' => [
                'type' => GraphQL::type('user')
            ],
            'social_work' => [
                'type' => GraphQL::type('user')
            ],
            'fecha_ingreso_icbf' => [
                'type' => Type::string()
            ],
            'numero_ingresos_icbf' => [
                'type' => Type::int()
            ],
            'fecha_ingreso' => [
                'type' => Type::string()
            ],
            'fecha_egreso' => [
                'type' => Type::string()
            ],
            'resolution_type' => [
                'type' => GraphQL::type('resolutionType')
            ],
            'numero_resolucion' => [
                'type' => Type::string()
            ],
            'fecha_resolucion' => [
                'type' => Type::string()
            ],
            'zonal_center' => [
                'type' => GraphQL::type('zonalCenter')
            ],
            'family_curator' => [
                'type' => GraphQL::type('familyCurator')
            ],
            'family' => [
                'type' => Type::listOf(GraphQL::type('family'))
            ],
            'defensor' => [
                'type' => Type::string()
            ],
            'neighborhood' => [
                'type' => GraphQL::type('neighborhood')
            ],
            'reason_admission' => [
                'type' => GraphQL::type('reasonAdmission')
            ],
            'descripcion_ingreso_icbf' => [
                'type' => Type::string()
            ],
            'descripcion_ingreso_psicosocial' => [
                'type' => Type::string()
            ],
            'scholarship' => [
                'type' => GraphQL::type('scholarship')
            ],
            'family' => [
                'type' => Type::listOf(GraphQL::type('family'))
            ],
            'enfermedad' => [
                'type' => Type::int()
            ],
            'tipo_vacuna' => [
                'type' => Type::string()
            ],
            'accidente' => [
                'type' => Type::int()
            ],
            'nutritional_condition' => [
                'type' => GraphQL::type('nutritionalCondition')
            ],
            'type_disability' => [
                'type' => GraphQL::type('typeDisability')
            ],
            'regimen' => [
                'type' => Type::string()
            ],
            'nombre_regimen' => [
                'type' => Type::string()
            ],
            'area_social' => [
                'type' => Type::int()
            ],
            'children_house' => [
                'type' => Type::listOf(GraphQL::type('childrenHouseType'))
            ],

        ]);
    }
}
