<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ResidenceLocalityType extends GraphQLType
{
    protected $attributes = [
        'name' => 'ResidenceLocality',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'id' => [
                'type' => Type::int()
            ],
            'nombre' => [
                'type' => Type::string()
            ],
            'municipio_id' => [
                'type' => Type::int()
            ],
            'estado_id' => [
                'type' => Type::int()
            ],
            'neighborhood' => [
                'type' => Type::listOf(GraphQL::type('neighborhood'))
            ]
        ];
    }
}
