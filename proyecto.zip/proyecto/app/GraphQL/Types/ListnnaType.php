<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ListnnaType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Listnna',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'childrenActive' => [
                'type' => Type::listOf(GraphQL::type('children')),
            ],
            'childrenInactive' => [
                'type' => Type::listOf(GraphQL::type('children')),
            ]
        ];
    }
}
