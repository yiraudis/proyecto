<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class HouseType extends GraphQLType
{
    protected $attributes = [
        'name' => 'House',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'id' => [
                'type' => Type::int()
            ],
            'nombre' => [
                'type' => Type::string()
            ],
            'direccion' => [
                'type' => Type::string()
            ],
            'telefono' => [
                'type' => Type::string()
            ],
            'minimo_edad' => [
                'type' => Type::int()
            ],
            'maximo_edad' => [
                'type' => Type::int()
            ],
            'sex' => [
                'type' => GraphQL::type('sex')
            ],
            'plant_coordinator' => [
                'type' => GraphQL::type('user')
            ],
            'relief_coordinator' => [
                'type' => GraphQL::type('user')
            ],
        ];
    }
}
