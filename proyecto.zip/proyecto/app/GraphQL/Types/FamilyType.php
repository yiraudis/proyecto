<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class FamilyType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Family',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'id' => [
                'type' => Type::int()
            ],
            'nna_id' => [
                'type' => Type::int()
            ],
            'familiar_id' => [
                'type' => Type::int()
            ],
            'parentesco_id' => [
                'type' => Type::int()
            ],
            'contacto' => [
                'type' => Type::int()
            ],
            'habita' => [
                'type' => Type::int()
            ],
            'user' => [
                'type' => GraphQL::type('user')
            ],
            'parentesco' => [
                'type' => GraphQL::type('familyRelationship')
            ]
        ];
    }
}
