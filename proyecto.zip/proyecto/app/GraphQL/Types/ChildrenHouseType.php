<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use App\Http\Traits\Globals;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ChildrenHouseType extends GraphQLType
{
    use Globals;
    protected $attributes = [
        'name' => 'ChildrenHouse',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return $this->responseGQL([
            'id' => [
                'type' => Type::int()
            ],
            'house' => [
                'type' => GraphQL::type('house')
            ],
            'estado_id' => [
                'type' =>  Type::int()
            ],
        ]);
    }
}
