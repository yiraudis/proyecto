<?php

declare(strict_types=1);

namespace App\GraphQL\Types;

use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Type as GraphQLType;

class FamilyCuratorType extends GraphQLType
{
    protected $attributes = [
        'name' => 'FamilyCurator',
        'description' => 'A type'
    ];

    public function fields(): array
    {
        return [
            'id' => [
                'type' => Type::int()
            ],
            'nombre' => [
                'type' => Type::string()
            ],
            'direccion' => [
                'type' => Type::string()
            ],
            'telefono' => [
                'type' => Type::string()
            ],
            'city' => [
                'type' => GraphQL::type('city')
            ],
        ];
    }
}
