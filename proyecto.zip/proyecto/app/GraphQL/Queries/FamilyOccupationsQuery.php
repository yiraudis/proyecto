<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\FamilyOccupation;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class FamilyOccupationsQuery extends Query
{
    protected $attributes = [
        'name' => 'familyOccupations',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('familyOccupation'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return FamilyOccupation::where('estado_id',1)->get();
    }
}
