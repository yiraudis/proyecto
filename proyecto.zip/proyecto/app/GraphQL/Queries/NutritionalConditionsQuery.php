<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\NutritionalCondition;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class NutritionalConditionsQuery extends Query
{
    protected $attributes = [
        'name' => 'nutritionalConditions',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('nutritionalCondition'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return NutritionalCondition::where('estado_id',1)->get();
    }
}
