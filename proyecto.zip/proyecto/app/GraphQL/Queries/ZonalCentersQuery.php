<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\ZonalCenter;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class ZonalCentersQuery extends Query
{
    protected $attributes = [
        'name' => 'zonalCenters',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('zonalCenter'));
    }

    public function args(): array
    {
        return [
            'city_id' => [
                'type' => Type::int(),
                'rules' => ['nullable','exists:municipios,id']
            ]
        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return ZonalCenter::where(function($q) use($args){
            if (isset($args['city_id'])) {
                $q->where('municipio_id',$args['city_id']);
            }
        })->get();
    }
}
