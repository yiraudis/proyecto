<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\EthnicGroup;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class EthnicGroupsQuery extends Query
{
    protected $attributes = [
        'name' => 'ethnicGroups',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('ethnicGroup'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return EthnicGroup::all();
    }
}
