<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\House;
use App\Http\Controllers\Controller;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class HousesQuery extends Query
{
    protected $attributes = [
        'name' => 'houses',
        'description' => 'A query'
    ];

    public $controller = [];

    public function __construct()
    {
        $this->controller = new Controller;
    }

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('house'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return House::where('estado_id',$this->controller->active_status)->get();
    }
}
