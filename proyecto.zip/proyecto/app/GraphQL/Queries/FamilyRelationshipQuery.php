<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\FamilyRelationship;
use App\Http\Traits\Globals;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class FamilyRelationshipQuery extends Query
{
    use Globals;
    protected $attributes = [
        'name' => 'familyRelationship',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('familyRelationship'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return FamilyRelationship::where('estado_id',$this->active)->get();
    }
}
