<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\Http\Traits\Globals;
use App\Trend;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class TrendsQuery extends Query
{
    use Globals;
    protected $attributes = [
        'name' => 'trends',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('trend'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return Trend::where('estado_id',$this->active)->get();
    }
}
