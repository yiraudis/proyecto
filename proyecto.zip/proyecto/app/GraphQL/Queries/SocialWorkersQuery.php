<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\Http\Controllers\Controller;
use App\User;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class SocialWorkersQuery extends Query
{
    protected $attributes = [
        'name' => 'socialWorkers',
        'description' => 'A query'
    ];

    public $controller = [];

    public function __construct()
    {
        $this->controller = new Controller;
    }

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('user'));
    }

    public function args(): array
    {
        return [

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        return User::where('estado_id',$this->controller->active_status)->whereHas('roles', function($q){
            $q->whereName('SOCIAL_WORK');
        })->get();
    }
}
