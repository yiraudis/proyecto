<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\Children;
use App\User;
use App\Http\Controllers\Controller;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class NnaListQuery extends Query
{
    protected $attributes = [
        'name' => 'nnaList',
        'description' => 'A query'
    ];

    public $controller = [];

    public function __construct()
    {
        $this->controller = new Controller;
    }

    public function type(): Type
    {
        return (GraphQL::type('listNnaType'));
    }

    public function args(): array
    {
        return [

        ];
    }
    

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        $activos=Children::where('estado_id',$this->controller->active_status)->get();
        $inactivos=Children::where('estado_id',$this->controller->inactive_status)->get();
        return ['childrenActive'=>$activos,'childrenInactive'=>$inactivos];
    }
}
