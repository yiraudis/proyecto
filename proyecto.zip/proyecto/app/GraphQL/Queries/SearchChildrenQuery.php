<?php

declare(strict_types=1);

namespace App\GraphQL\Queries;

use App\Children;
use App\User;
use Closure;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Illuminate\Support\Facades\Auth;
use Rebing\GraphQL\Support\Facades\GraphQL;
use Rebing\GraphQL\Support\Query;
use Rebing\GraphQL\Support\SelectFields;

class SearchChildrenQuery extends Query
{
    protected $attributes = [
        'name' => 'SearchChildren',
        'description' => 'A query'
    ];

    public function type(): Type
    {
        return Type::listOf(GraphQL::type('user'));
    }

    public function args(): array
    {
        return [
            'search' => [
                'type' => Type::string(),
                'description' => "Buscar nna"
            ],
            'type' => [
                'type' => Type::int(),
                'description' => "1 = children, 2 = user",
                'rules' => ['required']
            ],

        ];
    }

    public function resolve($root, $args, $context, ResolveInfo $resolveInfo, Closure $getSelectFields)
    {
        $users = User::search($args['search'],$args['type'])->withCount('children')->limit(10)->get();
        if ($args['type'] == 1) { //nna
            return $users->where('children_count','>',0)->values();
        }
        return $users;
    }
}
