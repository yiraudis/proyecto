<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class LogPlatin extends Model
{
    protected $table = "log_platin";

    protected $guarded = [];

    protected $appends = ['fecha_creacion'];

    public function getFechaCreacionAttribute(){
        return Carbon::parse($this->created_at)->toDateTimeString();
    }

    public function area_trabajo(){
        return $this->belongsTo(AreaTrabajo::class,"area_trabajo_id");
    }
    public function categoria_platin(){
        return $this->belongsTo(CategoriaPlatin::class,"categoria_platin_id");
    }
    public function user(){
        return $this->belongsTo(User::class,"user_id");
    }
}
