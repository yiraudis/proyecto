<?php

namespace App;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class InformeEvolucion extends Model
{
    protected $table = "informe_evolucion";

    protected $guarded = [];

    protected $appends = ["fecha_entrega",'plazo','codigo','flujo_estados','fecha_finalizacion','fecha_creacion'];

    public $controller = [];
    public function __construct()
    {
        $this->controller = new Controller;
    }

    public function getFlujoEstadosAttribute(){
        return [
            "creado" => 3,
            "desarrollo" => 4,
            "psicologia" => 5,
            "social" => 6,
            "en_aprobacion" => 7,
            "finalizado" => 8,
            "en_ajuste" => 9,
        ];
    }

    public function getCodigoAttribute(){
        return str_pad($this->id, 5, "0", STR_PAD_LEFT);
    }

    public function getFechaEntregaAttribute(){
        return Carbon::parse($this->created_at)->addMonth()->toDateTimeString();
    }

    public function getFechaCreacionAttribute($value){
        return Carbon::parse($this->created_at)->toDateTimeString();
    }

    public function getFechaFinalizacionAttribute(){
        $log_finalizado = LogPlatinEstado::where('informe_evolucion_id',$this->id)
        ->where('estado_id',$this->controller->finalizado_status)->first();
        if(isset($log_finalizado)){
            return Carbon::parse( $log_finalizado->created_at)->toDateTimeString();
        }
        return "";
    }

    public function getPlazoAttribute(){
        $limite = Carbon::parse($this->created_at)->addMonth();
        $fecha_actual = Carbon::now();
        return $fecha_actual->diffInDays($limite);
    }

    public function estado(){
        return $this->belongsTo(Status::class,'estado_id');
    }

    public function nna(){
        return $this->belongsTo(Children::class,'nna_id');
    }

    public function log_platin(){
        return $this->hasMany(LogPlatin::class,"informe_evolucion_id");
    } 
}
