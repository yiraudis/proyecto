<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FamilyOccupation extends Model
{
    protected $table = "ocupaciones_familiares_nna";
    protected $guarded = [];
}
