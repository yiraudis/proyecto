<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Children extends Model
{
    protected $table = "nna";
    protected $guarded = [];

    protected $appends = ["contacto"];

    public function getContactoAttribute(){
        
        $result = DB::select("SELECT concat(u.primer_nombre, ' ', u.primer_apellido) fullname, p.nombre parentesco, u.direccion, u.telefono FROM nna 
        inner join familiares f on nna.id = f.nna_id
        inner join users u on u.id = f.familiar_id 
        inner join parentescos p on p.id = f.parentesco_id
        where nna.id = ?
        order by f.id desc limit 1", [$this->id]);
        
        if(count($result) > 0){
            return $result[0];
        }
        return null;
    }

    public function user(){
        return $this->belongsTo(User::class,'usuario_id');
    }

    public function scopeSearch($query,$search){
        $query->where('sim','like',"%$search%")
        ->orWhereHas('user',function($user) use($search){
            $user->where('primer_nombre','like',"%$search%")
            ->orWhere('segundo_nombre','like',"%$search%")
            ->orWhere('primer_apellido','like',"%$search%")
            ->orWhere('segundo_apellido','like',"%$search%");
            $user->orWhereHas('user_document_types', function($user_document_types) use($search){
                $user_document_types->where('identificacion','like',"%$search%");
            });
        });
    }

    public function location(){
        return $this->belongsTo(Location::class,'ubicacion_id');
    }

    public function psychologist(){
        return $this->belongsTo(User::class,'psicologo_id');
    }

    public function social_work(){
        return $this->belongsTo(User::class,'trabajador_social_id');
    }

    public function resolution_type(){
        return $this->belongsTo(ResolutionType::class,'tipo_resolucion_id');
    }
    public function nna_house(){
        return $this->hasOne(ChildrenHouse::class,'nna_id');
    }

    public function zonal_center(){
        return $this->belongsTo(ZonalCenter::class,'centro_zonal_id');
    }

    public function family_curator(){
        return $this->belongsTo(FamilyCurator::class,'comisaria_familiar_id');
    }

    public function neighborhood(){
        return $this->belongsTo(Neighborhood::class,'barrio_id');
    }

    public function reason_admission(){
        return $this->belongsTo(ReasonAdmission::class,'motivo_ingreso_id');
    }

    public function scholarship(){
        return $this->belongsTo(Scholarship::class,'escolaridad_id');
    }

    public function nutritional_condition(){
        return $this->belongsTo(NutritionalCondition::class,'estado_nutricional_id');
    }

    public function type_disability(){
        return $this->belongsTo(TypeDisability::class,'tipo_discapacidad_id');
    }

    public function type_family(){
        return $this->belongsTo(TypeFamily::class,'tipo_familia_id');
    }

    public function responsable(){
        return $this->belongsTo(Responsable::class,'responsable_nna_id');
    }

    public function family_background(){
        return $this->belongsTo(FamilyBackground::class,'antecedente_familiar_nna_id');
    }

    public function family_income(){
        return $this->belongsTo(FamilyIncome::class,'ingreso_familiar_nna_id');
    }

    public function family(){
        return $this->hasMany(Family::class,'nna_id');
    }

    public function children_house(){
        return $this->hasMany(ChildrenHouse::class,'nna_id')->where('estado_id',1);
    }
}
