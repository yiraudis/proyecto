<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Laravel\Passport\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use Notifiable, HasApiTokens, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $guarded = [];

    protected $appends = ["edad","fullname","identification","nacimiento"];

    public function getEdadAttribute(){
        return Carbon::parse($this->fecha_nacimiento)->age;
    }

    public function getIdentificationAttribute(){
        
        $result = DB::select('SELECT ti.nombre tipo, uti.identificacion FROM users u
        inner join usuario_tipo_identificacion uti on uti.usuario_id = u.id
        inner join tipos_identificacion ti on ti.id = uti.tipo_identificacion_id
        where u.id = ?
        order by uti.id desc
        limit 1', [$this->id]);
        if(count($result) > 0){
            return $result[0];
        }
        return null;
    }

    public function getNacimientoAttribute(){
        
        $result = DB::select('SELECT m.nombre municipio, d.nombre departamento, p.nombre pais, p.nacionalidad FROM users u 
            inner join municipios m on m.id = u.municipio_id
            inner join departamentos d on m.departamento_id = d.id
            inner join paises p on d.pais_id = p.id 
            where u.id = ?;', [$this->id]);
        if(count($result) > 0){
            return $result[0];
        }
        return null;
    }

    
    public function getFullnameAttribute(){
        $fullname = $this->primer_nombre;
        if(isset($this->segundo_nombre)){
            $fullname .= " $this->segundo_nombre";
        }
        if(isset($this->primer_apellido)){
            $fullname .= " $this->primer_apellido";
        }
        if(isset($this->segundo_apellido)){
            $fullname .= " $this->segundo_apellido";
        }
        return $fullname;
    }

    public function user_document_types(){
        return $this->hasMany(UserDocumentType::class,'usuario_id');
    }

    public function children(){
        return $this->hasMany(Children::class,'usuario_id')->orderBy('id','desc');
    }

    public function ethnic_group(){
        return $this->belongsTo(EthnicGroup::class,'grupo_etnico_id');
    }

    public function sexo(){
        return $this->belongsTo(Sex::class,'genero_id');
    }

    public function grupo_etnico(){
        return $this->belongsTo(EthnicGroup::class,'grupo_etnico_id');
    }

    public function ciudad(){
        return $this->belongsTo(City::class,'municipio_id');
    }

    public function scopeSearch($query,$search,$type){
        $query->where('primer_nombre','like',"%$search%")->orWhere('segundo_nombre','like',"%$search%")
        ->orWhere('primer_apellido','like',"%$search%")
        ->orWhere('segundo_apellido','like',"%$search%")
        ->orWhereHas('user_document_types', function($user_document_types) use($search){
            $user_document_types->where('identificacion','like',"%$search%");
        });
        if ($type == 1) { // nna
            $query->orWhereHas('children',function($children) use($search){
                $children->where('sim','like',"%$search%");
            });
        }
    }


}
