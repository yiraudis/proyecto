<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FamilyIncome extends Model
{
    protected $table = "ingresos_familiares_nna";
    protected $guarded = [];
}
