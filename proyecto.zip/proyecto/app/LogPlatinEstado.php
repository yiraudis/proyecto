<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class LogPlatinEstado extends Model
{
    protected $table = "log_platin_estado";

    protected $guarded = [];



}
