<?php

namespace App;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    protected $guarded = [];
    protected $table = "municipios";

    public $countroller = [];

    public function __construct()
    {
        $this->countroller = new Controller;
    }

    public function department(){
        return $this->belongsTo(Department::class,'departamento_id');
    }

    public function residence_locality(){
        return $this->hasMany(ResidenceLocality::class,'municipio_id')->where('estado_id',$this->countroller->active_status);
    }


}
