<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scholarship extends Model
{
    protected $table = "escolaridades_nna";
    protected $guarded = [];
}
