<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoriaPlatin extends Model
{
    protected $table = "categoria_platin";

    protected $guarded = [];
}
