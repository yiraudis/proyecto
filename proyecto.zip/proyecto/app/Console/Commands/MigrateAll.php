<?php

namespace App\Console\Commands;

use App\Http\Controllers\SeedController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateAll extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migrate:all';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migración de datos iniciales.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public $migrate;
    public function __construct()
    {
        parent::__construct();
        $this->migrate = new SeedController;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $status = false;
        $message = "Datos creados con éxito.";
        DB::beginTransaction();
        try {
            $this->migrate->runConfiInit();
            $this->info('0000001');
            $this->migrate->runServiceTypes();
            $this->migrate->runAreaTrabajo();
            $this->migrate->runCategoriaPlatin();
            $this->info('0000002');
            $this->migrate->runFrecuencias();
            $this->info('0000003');
            $this->migrate->runGadoEscolar();
            $this->info('0000004');
            $this->migrate->runFactorRiesgo();
            $this->info('0000005');
            $this->migrate->runCategoryMetas();
            $this->info('000001');
            $this->migrate->runCountries();
            $this->info('00001');
            $this->migrate->runDepartments();
            $this->info('0001');
            $this->migrate->runCities();
            $this->info('001');
            $this->migrate->runDocumentType();
            $this->info('01');
            $this->migrate->runGeneros();
            $this->migrate->runTrend();
            $this->migrate->runHousing();
            $this->info('0');
            $this->migrate->runUsers();
            $this->info('1');
            $this->migrate->runLocations();
            $this->info('2');
            $this->migrate->runEthnicGroup();
            $this->info('3');
            $this->migrate->runHouse();
            $this->info('4');
            $this->migrate->runResolutionType();
            $this->info('5');
            $this->migrate->runZonalCenter();
            $this->info('6');
            $this->migrate->runFamilyCurator();
            $this->info('7');
            $this->migrate->runResidenceLocality();
            $this->info('8');
            $this->migrate->runNeighborhood();
            $this->info('9');
            $this->migrate->runAdmission();
            $this->info('10');
            $this->migrate->runScholarship();
            $this->info('11');
            $this->migrate->runDiscapacidad();
            $this->info('12');
            $this->migrate->runNutritional();
            $this->info('13');
            $this->migrate->runFamily();
            $this->info('14');
            $this->migrate->runResponsable();
            $this->info('15');
            $this->migrate->runFamilyBackground();
            $this->info('16');
            $this->migrate->runFamilyIncome();
            $this->info('17');
            $this->migrate->runFamilyOcupation();
            $this->info('18');
            $this->migrate->runStatusCivil();
            $this->info('19');
            $this->migrate->runFamilyRelationship();


            $status = true;
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollback();
            $message = $th->getMessage();
        }

        if ($status) {
            $this->info($message);
        }else{
            $this->error($message);
        }

    }
}
