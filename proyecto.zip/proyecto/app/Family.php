<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Family extends Model
{
    protected $table = "familiares";
    protected $guarded = [];

    public function user(){
        return $this->belongsTo(User::class,'familiar_id');
    }

    public function parentesco(){
        return $this->belongsTo(FamilyRelationship::class,'parentesco_id');
    }
}
