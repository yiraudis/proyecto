<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PsicoIndividual extends Model
{
    protected $table = "ev_psico_individual";
    protected $guarded = [];
}
