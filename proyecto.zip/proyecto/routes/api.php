<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'evaluation', 'middleware' => 'auth:api'], function () {
    Route::get("/getComplement","EvaluationController@getComplement");
    Route::post("/saveSocialIngresoIndividual","EvaluationController@saveSocialIngresoIndividual");
    Route::post("/evaSocioFamiliarIngreso","EvaluationController@evaSocioFamiliarIngreso");
});
// ,'middleware' => 'auth:api'

Route::group(['prefix' => 'platin', 'middleware' => 'auth:api'], function () {
    Route::get('/list_platin', 'PlatinController@listPlatin');
    Route::get('/get_complement', 'PlatinController@getComplement');
    Route::get('/get_platin/{id}', 'PlatinController@platinById');
    Route::post('/save_description', 'PlatinController@saveDescription');
    Route::post('/finalizar', 'PlatinController@finalizar');
    Route::post('/', 'PlatinController@saveDescription');
});

Route::get('/platin/download/{id}', 'PlatinController@download');


Route::group(['prefix' => 'auth'], function () {
    Route::post('login', 'LoginController@login');
    Route::post('logout', 'LoginController@logout')->middleware('auth:api');
});
