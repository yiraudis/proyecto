<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateInformeEvolucionTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'informe_evolucion';
    /**
     * Run the migrations.
     * @table informe_evolucion
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nna_id');
            $table->unsignedInteger('responsable_id');
            $table->string('autoridad_administrativa')->nullable()->comment('Nombre de la autoridad administrativa');
            $table->text('motivo_ingreso')->nullable();
            $table->text('diagnostico_integral')->nullable();
            $table->text('atencion_individual')->nullable();
            $table->text('atencion_familiar')->nullable();
            $table->text('atencion_interinstitucional')->nullable();
            $table->text('observaciones')->nullable()->comment('evolucion = planteamiento de nuevas atenciones, platin = observaciones');
            $table->text('percepcion_calidad')->nullable();
            $table->integer('tipo')->comment('0 = platin, 1 = informe evolucion');
            $table->unsignedInteger('estado_id');
            $table->timestamps();


            $table->foreign('nna_id')
                ->references('id')->on('nna')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
