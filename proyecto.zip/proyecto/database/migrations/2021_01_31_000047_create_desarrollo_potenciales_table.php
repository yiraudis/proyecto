<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateDesarrolloPotencialesTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'desarrollo_potenciales';
    /**
     * Run the migrations.
     * @table desarrollo_potenciales
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('ev_social_individual_id');
            $table->text('institucion');
            $table->integer('tipo')->comment('1 = publica
2 = provada
3 = otro');
            $table->integer('anio');
            $table->unsignedInteger('grado_escolar_id');
            $table->integer('certifcado')->comment('1 = si
0 = no');
            $table->timestamps();


            $table->foreign('ev_social_individual_id')
                ->references('id')->on('ev_social_individual')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('grado_escolar_id')
                ->references('id')->on('grados_escolares')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
