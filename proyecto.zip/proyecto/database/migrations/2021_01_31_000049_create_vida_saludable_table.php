<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateVidaSaludableTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'vida_saludable';
    /**
     * Run the migrations.
     * @table vida_saludable
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('ev_social_individual_id');
            $table->unsignedInteger('tipo_servicio_id');
            $table->unsignedInteger('frecuencia_id');
            $table->unsignedInteger('estado_id');
            $table->timestamps();


            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('frecuencia_id')
                ->references('id')->on('frecuencias')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('ev_social_individual_id')
                ->references('id')->on('ev_social_individual')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
