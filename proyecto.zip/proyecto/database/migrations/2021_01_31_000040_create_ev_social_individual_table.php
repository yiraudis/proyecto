<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateEvSocialIndividualTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'ev_social_individual';
    /**
     * Run the migrations.
     * @table ev_social_individual
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nna_id');
            $table->dateTime('fecha_evaluacion');
            $table->text('vida_saludable');
            $table->text('desarrollo_potenciales');
            $table->text('motivo_ingreso')->nullable();
            $table->text('socio_economica');
            $table->text('observaciones_factores')->comment('observaciones factores de riesgo
');
            $table->text('dianamica_familiar')->nullable();
            $table->text('expectativas')->nullable()->comment('Expectativas de niño, niña o adolecente frente al proceso');
            $table->text('impresiones')->nullable()->comment('Impresion diagnostico social del niño,  niña o adolecente');
            $table->text('mapa_pertenencia')->nullable()->comment(' Mapa de pertenencia actual y participación social');
            $table->unsignedInteger('estado_id');
            $table->unsignedInteger('barrio_id')->nullable();
            $table->text('direccion')->nullable();
            $table->string('telefono', 45)->nullable();
            $table->unsignedInteger('user_id')->nullable();
            $table->timestamps();


            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('barrio_id')
                ->references('id')->on('barrios')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
