<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateEvEntrevistadoAgregadoTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'ev_entrevistado_agregado';
    /**
     * Run the migrations.
     * @table ev_entrevistado_agregado
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nna_id');
            $table->unsignedInteger('familiar_id')->comment('pivot de familiar');
            $table->integer('type')->default('1')->comment('1 = entrevistado , 2= agregado');
            $table->unsignedInteger('estado_id')->default('1');
            $table->string('model')->comment('desde que evaluación');
            $table->unsignedInteger('model_id');
            $table->timestamps();


            $table->foreign('nna_id')
                ->references('id')->on('nna')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('familiar_id')
                ->references('id')->on('familiares')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
