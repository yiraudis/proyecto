<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateEvPsicoIndividualTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'ev_psico_individual';
    /**
     * Run the migrations.
     * @table ev_psico_individual
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nna_id');
            $table->text('percepcion_ingreso')->nullable();
            $table->text('antecedentes')->nullable();
            $table->text('examen_mental')->nullable();
            $table->text('afectividad')->nullable();
            $table->text('percepcion_niño')->nullable();
            $table->text('prospectiva')->nullable();
            $table->text('adaptacion')->nullable();
            $table->text('resultado_prueba')->nullable();
            $table->text('lectura')->nullable();
            $table->dateTime('fecha_evaluacion');
            $table->unsignedInteger('estado_id');
            $table->unsignedInteger('user_id')->nullable();
            $table->timestamps();


            $table->foreign('nna_id')
                ->references('id')->on('nna')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
