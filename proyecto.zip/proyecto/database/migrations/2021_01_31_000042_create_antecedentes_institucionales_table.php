<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateAntecedentesInstitucionalesTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'antecedentes_institucionales';
    /**
     * Run the migrations.
     * @table antecedentes_institucionales
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('ev_social_individual_id');
            $table->text('institucion_bienestar');
            $table->dateTime('fecha_ingreso');
            $table->text('motivo_ingreso');
            $table->dateTime('fecha_egreso');
            $table->string('motivo_egreso', 45);
            $table->integer('adoptabilidad')->comment('1 = si 
0 = no');
            $table->string('numero_adoptabilidad')->nullable();
            $table->integer('vulnerabilidad')->comment('1 = si 
0 = no');
            $table->string('numero_vulnerablidad')->nullable();
            $table->unsignedInteger('estado_id');
            $table->timestamps();


            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('ev_social_individual_id')
                ->references('id')->on('ev_social_individual')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
