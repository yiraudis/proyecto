<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateEvSocioFamiliarTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'ev_socio_familiar';
    /**
     * Run the migrations.
     * @table ev_socio_familiar
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('nna_id');
            $table->text('motivo_ingreso')->nullable();
            $table->text('genograma')->nullable();
            $table->text('historia_vida')->nullable();
            $table->text('sistema_creencia')->nullable();
            $table->text('genereatividad')->nullable();
            $table->text('vulnerabilidad')->nullable();
            $table->text('dianamica_familiar')->nullable();
            $table->text('socio_economica')->nullable();
            $table->text('apoyo_familiar')->nullable();
            $table->text('apoyo_social')->nullable();
            $table->text('proyecto')->nullable();
            $table->text('mapa_actual')->nullable();
            $table->text('mapa_potencial')->nullable();
            $table->text('observacion_compromiso')->nullable();


            $table->text('lectura')->nullable();
            $table->unsignedInteger('estado_id');
            $table->dateTime('fecha_evaluacion');
            $table->unsignedInteger('user_id')->nullable();
            $table->timestamps();


            $table->foreign('nna_id')
                ->references('id')->on('nna')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
