<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateLogPlatinTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'log_platin';
    /**
     * Run the migrations.
     * @table log_platin
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('informe_evolucion_id');
            $table->unsignedInteger('area_trabajo_id');
            $table->unsignedInteger('categoria_platin_id');
            $table->timestamps();


            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('informe_evolucion_id')
                ->references('id')->on('informe_evolucion')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('area_trabajo_id')
                ->references('id')->on('area_trabajo')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('categoria_platin_id')
                ->references('id')->on('categoria_platin')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
