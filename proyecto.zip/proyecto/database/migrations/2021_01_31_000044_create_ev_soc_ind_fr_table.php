<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateEvSocIndFrTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'ev_soc_ind_fr';
    /**
     * Run the migrations.
     * @table ev_soc_ind_fr
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('ev_social_individual_id');
            $table->unsignedInteger('factor_riesgo_id');
            $table->text('cuales')->nullable()->comment('en caso de que el factor de riesgo se otro');
            $table->unsignedInteger('estado_id');
            $table->timestamps();


            $table->foreign('ev_social_individual_id')
                ->references('id')->on('ev_social_individual')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('factor_riesgo_id')
                ->references('id')->on('factores_riesgos')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('estado_id')
                ->references('id')->on('estados')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
