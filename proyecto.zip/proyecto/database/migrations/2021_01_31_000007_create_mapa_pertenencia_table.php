<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateMapaPertenenciaTable extends Migration
{
    /**
     * Schema table name to migrate
     * @var string
     */
    public $tableName = 'mapa_pertenencia';
    /**
     * Run the migrations.
     * @table mapa_pertenencia
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->tableName, function (Blueprint $table) {           
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('model')->comment('modelo de la evaluacion');
            $table->unsignedInteger('model_id')->comment('id de la evalueacion');
            $table->integer('nivel')->comment('niveles ');
            $table->string('componente')->comment('ejemplo: vida social, famialiar');
            $table->string('descripcion');
            $table->integer('tipo')->default('0')->comment('0 = actual  1 = potencial');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     public function down()
     {
       Schema::dropIfExists($this->tableName);
     }
}
