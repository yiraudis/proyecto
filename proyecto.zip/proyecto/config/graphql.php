<?php

declare(strict_types=1);

use App\CategoryGoals;
use App\GraphQL\Mutations\NewChildrenMutation;
use App\GraphQL\Mutations\PsicoIndivdualMutation;
use App\GraphQL\Mutations\PsicoIngresoFamiliarMutation;
use App\GraphQL\Queries\CategoryMetasQuery;
use App\GraphQL\Queries\CitiesQuery;
use App\GraphQL\Queries\CountriesQuery;
use App\GraphQL\Queries\DocumentTypesQuery;
use App\GraphQL\Queries\EthnicGroupsQuery;
use App\GraphQL\Queries\FamilyBackgroundQuery;
use App\GraphQL\Queries\FamilyCuratorsQuery;
use App\GraphQL\Queries\FamilyIncomeQuery;
use App\GraphQL\Queries\FamilyOccupationsQuery;
use App\GraphQL\Queries\FamilyRelationshipQuery;
use App\GraphQL\Queries\HousesQuery;
use App\GraphQL\Queries\HousingTypesQuery;
use App\GraphQL\Queries\LocationsQuery;
use App\GraphQL\Queries\NutritionalConditionsQuery;
use App\GraphQL\Queries\PsychologistsQuery;
use App\GraphQL\Queries\ReasonAdmissionsQuery;
use App\GraphQL\Queries\ResolutionTypesQuery;
use App\GraphQL\Queries\ResponsablesQuery;
use App\GraphQL\Queries\ScholarshipsQuery;
use App\GraphQL\Queries\SearchChildrenQuery;
use App\GraphQL\Queries\SexsQuery;
use App\GraphQL\Queries\SocialWorkersQuery;
use App\GraphQL\Queries\TrendsQuery;
use App\GraphQL\Queries\TypeDisabilitiesQuery;
use App\GraphQL\Queries\TypesFamilyQuery;
use App\GraphQL\Queries\ZonalCentersQuery;
use App\GraphQL\Queries\NnaListQuery;
use App\GraphQL\Types\ChildrenType;
use App\GraphQL\Types\CityType;
use App\GraphQL\Types\CountryType;
use App\GraphQL\Types\DepartmentType;
use App\GraphQL\Types\DocumentTypeType;
use App\GraphQL\Types\EthnicGroupType;
use App\GraphQL\Types\FamilyBackgroundType;
use App\GraphQL\Types\FamilyCuratorType;
use App\GraphQL\Types\FamilyIncomeType;
use App\GraphQL\Types\FamilyOccupationType;
use App\GraphQL\Types\FamilyRelationshipType;
use App\GraphQL\Types\FamilyType;
use App\GraphQL\Types\HouseType;
use App\GraphQL\Types\HousingTypeType;
use App\GraphQL\Types\LocationType;
use App\GraphQL\Types\LoginType;
use App\GraphQL\Types\NeighborhoodType;
use App\GraphQL\Types\NutritionialConditionType;
use App\GraphQL\Types\ReasonAdmissionType;
use App\GraphQL\Types\ResidenceLocalityType;
use App\GraphQL\Types\ResolutionTypeType;
use App\GraphQL\Types\ResponsableType;
use App\GraphQL\Types\ScholarshipType;
use App\GraphQL\Types\SexType;
use App\GraphQL\Types\StatusType;
use App\GraphQL\Types\TrendType;
use App\GraphQL\Types\TypeDisabilityType;
use App\GraphQL\Types\TypeFamilyType;
use App\GraphQL\Types\UserDocumentTypeType;
use App\GraphQL\Types\UserType;
use App\GraphQL\Types\ZonalCenterType;
use App\GraphQL\Types\ListnnaType;
use App\GraphQL\Types\ChildrenHouseType;


return [

    // The prefix for routes
    'prefix' => 'api/',

    // The routes to make GraphQL request. Either a string that will apply
    // to both query and mutation or an array containing the key 'query' and/or
    // 'mutation' with the according Route
    //
    // Example:
    //
    // Same route for both query and mutation
    //
    // 'routes' => 'path/to/query/{graphql_schema?}',
    //
    // or define each route
    //
    // 'routes' => [
    //     'query' => 'query/{graphql_schema?}',
    //     'mutation' => 'mutation/{graphql_schema?}',
    // ]
    //
    'routes' => '{graphql_schema?}',

    // The controller to use in GraphQL request. Either a string that will apply
    // to both query and mutation or an array containing the key 'query' and/or
    // 'mutation' with the according Controller and method
    //
    // Example:
    //
    // 'controllers' => [
    //     'query' => '\Rebing\GraphQL\GraphQLController@query',
    //     'mutation' => '\Rebing\GraphQL\GraphQLController@mutation'
    // ]
    //
    'controllers' => \Rebing\GraphQL\GraphQLController::class.'@query',

    // Any middleware for the graphql route group
    'middleware' => ['api'],

    // Additional route group attributes
    //
    // Example:
    //
    // 'route_group_attributes' => ['guard' => 'api']
    //
    'route_group_attributes' => [],

    // The name of the default schema used when no argument is provided
    // to GraphQL::schema() or when the route is used without the graphql_schema
    // parameter.
    'default_schema' => 'default',

    // The schemas for query and/or mutation. It expects an array of schemas to provide
    // both the 'query' fields and the 'mutation' fields.
    //
    // You can also provide a middleware that will only apply to the given schema
    //
    // Example:
    //
    //  'schema' => 'default',
    //
    //  'schemas' => [
    //      'default' => [
    //          'query' => [
    //              'users' => 'App\GraphQL\Query\UsersQuery'
    //          ],
    //          'mutation' => [
    //
    //          ]
    //      ],
    //      'user' => [
    //          'query' => [
    //              'profile' => 'App\GraphQL\Query\ProfileQuery'
    //          ],
    //          'mutation' => [
    //
    //          ],
    //          'middleware' => ['auth'],
    //      ],
    //      'user/me' => [
    //          'query' => [
    //              'profile' => 'App\GraphQL\Query\MyProfileQuery'
    //          ],
    //          'mutation' => [
    //
    //          ],
    //          'middleware' => ['auth'],
    //      ],
    //  ]
    //
    'schemas' => [
        'default' => [
            'query' => [
                'countries' => CountriesQuery::class,
                // 'department' => CountriesQuery::class,
                'cities' => CitiesQuery::class,
                'documentTypes' => DocumentTypesQuery::class,
                'sexs' => SexsQuery::class,
                'locations' => LocationsQuery::class,
                'ethnicGroups' => EthnicGroupsQuery::class,
                'resolutionTypes' => ResolutionTypesQuery::class,
                'zonalCenters' => ZonalCentersQuery::class,
                'familyCurators' => FamilyCuratorsQuery::class,
                'reasonAdmissions' => ReasonAdmissionsQuery::class,
                'scholarships' => ScholarshipsQuery::class,
                'typeDisabilities' => TypeDisabilitiesQuery::class,
                'nutritionialConditions' => NutritionalConditionsQuery::class,
                'TypesFamily' => TypesFamilyQuery::class,
                'responsables' => ResponsablesQuery::class,
                'familyBackground' => FamilyBackgroundQuery::class,
                'familyIncome' => FamilyIncomeQuery::class,
                'familyOccupations' => FamilyOccupationsQuery::class,
                'trends' => TrendsQuery::class,
                'housingTypes' => HousingTypesQuery::class,
                'familyRelationships'=> FamilyRelationshipQuery::class,
            ],
            'mutation' => [


            ],
            'middleware' => ['auth:api'],
            'method' => ['get', 'post'],
        ],
        'children' => [
            'query' => [
                'houses' => HousesQuery::class,
                'socialWorkers' => SocialWorkersQuery::class,
                'psychologists' => PsychologistsQuery::class,
                'nnaList' => NnaListQuery::class
            ],
            'mutation' => [
                'newChildren' => NewChildrenMutation::class
            ],
            'middleware' => ['auth:api'],
            'method' => ['get', 'post'],
        ],
        'evaluation' => [
            'query' => [
                'searchChildren' => SearchChildrenQuery::class,
                'categoryMeta' => CategoryMetasQuery::class
            ],
            'mutation' => [
                'psicoIndividual' => PsicoIndivdualMutation::class,
                'psicoIngresoFamiliar' => PsicoIngresoFamiliarMutation::class
            ],

            'middleware' => ['auth:api'],
            'method' => ['get', 'post'],
        ],
    ],

    // The types available in the application. You can then access it from the
    // facade like this: GraphQL::type('user')
    //
    // Example:
    //
    // 'types' => [
    //     'user' => 'App\GraphQL\Type\UserType'
    // ]
    //
    'types' => [
        'city' => CityType::class,
        'department' => DepartmentType::class,
        'country' => CountryType::class,
        'documentType' => DocumentTypeType::class,
        'status' => StatusType::class,
        'user' => UserType::class,
        'login' => LoginType::class,
        'sex' => SexType::class,
        'location' => LocationType::class,
        'ethnicGroup' => EthnicGroupType::class,
        'house' => HouseType::class,
        'resolutionType' => ResolutionTypeType::class,
        'zonalCenter' => ZonalCenterType::class,
        'familyCurator' => FamilyCuratorType::class,
        'residenceLocality' => ResidenceLocalityType::class,
        'neighborhood' => NeighborhoodType::class,
        'reasonAdmission' => ReasonAdmissionType::class,
        'scholarship' => ScholarshipType::class,
        'typeDisability' => TypeDisabilityType::class,
        'nutritionalCondition' => NutritionialConditionType::class,
        'typeFamily' => TypeFamilyType::class,
        'responsable' => ResponsableType::class,
        'familyBackground' => FamilyBackgroundType::class,
        'familyIncome' => FamilyIncomeType::class,
        'familyOccupation' => FamilyOccupationType::class,
        'children' => ChildrenType::class,
        'trend' => TrendType::class,
        'housingType' => HousingTypeType::class,
        'familyRelationship' => FamilyRelationshipType::class,
        'family' => FamilyType::class,
        'userDocumentType' => UserDocumentTypeType::class,
        'childrenHouseType' =>ChildrenHouseType::class,
        'listNnaType' => ListnnaType::class,
        'family' => FamilyType::class
    ],

    // The types will be loaded on demand. Default is to load all types on each request
    // Can increase performance on schemes with many types
    // Presupposes the config type key to match the type class name property
    'lazyload_types' => false,

    // This callable will be passed the Error object for each errors GraphQL catch.
    // The method should return an array representing the error.
    // Typically:
    // [
    //     'message' => '',
    //     'locations' => []
    // ]
    'error_formatter' => ['\Rebing\GraphQL\GraphQL', 'formatError'],

    /*
     * Custom Error Handling
     *
     * Expected handler signature is: function (array $errors, callable $formatter): array
     *
     * The default handler will pass exceptions to laravel Error Handling mechanism
     */
    'errors_handler' => ['\Rebing\GraphQL\GraphQL', 'handleErrors'],

    // You can set the key, which will be used to retrieve the dynamic variables
    'params_key' => 'variables',

    /*
     * Options to limit the query complexity and depth. See the doc
     * @ https://webonyx.github.io/graphql-php/security
     * for details. Disabled by default.
     */
    'security' => [
        'query_max_complexity' => null,
        'query_max_depth' => null,
        'disable_introspection' => false,
    ],

    /*
     * You can define your own pagination type.
     * Reference \Rebing\GraphQL\Support\PaginationType::class
     */
    'pagination_type' => \Rebing\GraphQL\Support\PaginationType::class,

    /*
     * Config for GraphiQL (see (https://github.com/graphql/graphiql).
     */
    'graphiql' => [
        'prefix' => '/graphiql',
        'controller' => \Rebing\GraphQL\GraphQLController::class.'@graphiql',
        'middleware' => [],
        'view' => 'graphql::graphiql',
        'display' => env('ENABLE_GRAPHIQL', true),
    ],

    /*
     * Overrides the default field resolver
     * See http://webonyx.github.io/graphql-php/data-fetching/#default-field-resolver
     *
     * Example:
     *
     * ```php
     * 'defaultFieldResolver' => function ($root, $args, $context, $info) {
     * },
     * ```
     * or
     * ```php
     * 'defaultFieldResolver' => [SomeKlass::class, 'someMethod'],
     * ```
     */
    'defaultFieldResolver' => null,

    /*
     * Any headers that will be added to the response returned by the default controller
     */
    'headers' => [],

    /*
     * Any JSON encoding options when returning a response from the default controller
     * See http://php.net/manual/function.json-encode.php for the full list of options
     */
    'json_encoding_options' => 0,
];
